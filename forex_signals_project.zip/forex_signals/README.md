# Forex Signals

A personal Android app that watches USD/JPY and EUR/USD, runs 24 technical
trading strategies against real historical and live price data, and shows
you BUY/SELL signals with honestly-calculated historical win rates.

**This app never places a trade, never connects to a broker, and never
moves money.** It is a signal/analysis tool only — what you do with a
signal is entirely up to you.

This document is written for someone who is not an experienced programmer.
If you get stuck, check **TROUBLESHOOTING.md** — it lists the exact error
messages you might see and what to do about them.

---

## 1. What you need before you start

- A computer (Windows, Mac, or Linux) with internet access.
- About 15 GB of free disk space (Android build tools are large).
- An Android phone, OR Android Studio's built-in phone simulator.
- Optional: a free or paid API key from [Twelve Data](https://twelvedata.com)
  if you want **live** prices instead of the built-in demo data. You can
  skip this entirely and use Demo mode.

## 2. Install the one-time tools

1. Install **Android Studio**: <https://developer.android.com/studio>
   Open it once and let it finish its own setup wizard (this installs the
   Android SDK for you).
2. Install **Flutter**: <https://docs.flutter.dev/get-started/install>
   Follow the instructions for your operating system.
3. Open a terminal (Command Prompt / PowerShell / Terminal) and run:
   ```
   flutter doctor
   ```
   Fix anything it marks with a red ✗. It's normal for this to take a
   few tries — it's telling you exactly what's missing.

## 3. Open this project

1. Unzip this project folder somewhere on your computer.
2. In a terminal, go into the folder:
   ```
   cd forex_signals
   ```
3. Download the app's dependencies:
   ```
   flutter pub get
   ```
   This needs internet access and may take a few minutes the first time.

## 4. Run it in Demo mode (no API key needed)

With a phone plugged in (with USB debugging enabled — Android will prompt
you) or a simulator running:

```
flutter run
```

The app starts in **Demo mode** by default: realistic-looking but
synthetic candles, clearly labelled "DEMO" everywhere they appear. This
lets you try every feature — charts, strategies, signals, backtesting —
without any API key.

## 5. Switch to live prices (optional)

See **API_SETUP.md** for the exact steps. In short: get a free API key from
Twelve Data, open the app's Settings, switch to "Live", and paste in your
key.

## 6. Build an installable APK

See **BUILD.md** for exact commands for a debug build, a release build, and
an Android App Bundle (for the Play Store). The short version:

```
flutter build apk --debug
flutter build apk --release
```

## 7. How background monitoring works

See **ARCHITECTURE.md** for the full explanation, and TROUBLESHOOTING.md
if your phone's battery saver keeps stopping it. In short: the app runs an
Android **foreground service** (the same mechanism music players and
fitness trackers use) with a permanent notification showing it's active,
which is the most reliable way Android allows an app to keep working in
the background. Android itself does **not** guarantee any app can run
forever in the background — some phone brands (Samsung, Xiaomi, Huawei,
and others) are more aggressive than stock Android about killing
background apps to save power, and TROUBLESHOOTING.md has the manufacturer-
specific steps to stop that happening to this app.

## 8. What's actually in this app

| Document | What it covers |
|---|---|
| `SETUP.md` | Dependencies, project structure, first-run checklist |
| `BUILD.md` | Exact build/test commands, signing a release APK |
| `ARCHITECTURE.md` | How the code is organized and why |
| `STRATEGIES.md` | All 24 strategies explained, and how win rates are computed |
| `API_SETUP.md` | Getting and entering a Twelve Data API key |
| `TROUBLESHOOTING.md` | Common problems and exact fixes |

## 9. The four tabs

- **USD/JPY** and **EUR/USD** — candlestick charts with zoom, pan, a
  press-and-hold crosshair, timeframe switching, and overlays for whichever
  strategies you've turned on.
- **Signals** — Current (active) and History (resolved) signals from
  **every** strategy, regardless of which ones are turned on for the
  charts.
- **Strategies** — turn strategies on/off for the *charts only* (it never
  affects which strategies generate signals), see a full explanation of
  each one, and tune its parameters.

## 10. Known limitations (read this — it matters)

- **This project was assembled and reviewed without a Flutter/Android
  toolchain available in that environment.** Every file is real, complete
  source code — nothing is a stub or placeholder — but `flutter pub get`,
  `flutter analyze`, `flutter test`, and `flutter build` have not been run
  against it by the tool that generated it. A GitHub Actions workflow
  (`.github/workflows/build_and_test.yml`) is included specifically so you
  get a real, independently-verified build and test run the first time you
  push this to a repository — see BUILD.md, "Automatic build verification."
  Run the commands in BUILD.md yourself (or push to GitHub and watch the
  Actions tab) as your first step, and check TROUBLESHOOTING.md for the
  handful of places most likely to need a small fix (a dependency version
  bump, a plugin API signature change).
- Oscillator-style indicators (RSI, MACD, Stochastic, ADX, momentum) show
  as a compact value badge above the chart rather than a separate stacked
  sub-panel — see ARCHITECTURE.md, "Known limitations."
- Backtests cap at the most recent several thousand candles per run for
  performance reasons on a phone; see STRATEGIES.md for the exact number
  and why.
- A debug APK is always buildable. A *release* APK builds too, but is
  signed with the debug key unless you create your own signing key — see
  BUILD.md.
