# Strategies

All 24 strategies are real, independent calculations against real OHLC
data — none are a name with placeholder logic. Full detail for each
(buy/sell/neutral conditions, suitable market conditions, weaknesses,
usual timeframes) is also available in-app: Strategies tab → tap the (i)
next to any strategy.

Every strategy implements the same interface (`strategies/strategy.dart`)
and returns `BUY`, `SELL`, or `NEUTRAL` plus the indicator values and a
plain-English reason behind that candle's result.

| # | Strategy | Core indicator(s) | Fires on |
|---|---|---|---|
| 1 | SMA Crossover | SMA fast/slow | Fast SMA crosses slow SMA |
| 2 | EMA Crossover | EMA fast/slow | Fast EMA crosses slow EMA |
| 3 | MACD | MACD line + signal | MACD crosses its signal line |
| 4 | RSI Overbought/Oversold | RSI(14) | RSI recovers back through 30/70 |
| 5 | RSI Divergence | RSI + price swings | Price/RSI swing disagreement |
| 6 | Stochastic Oscillator | %K/%D | %K/%D cross inside 20/80 zone |
| 7 | Stochastic RSI | RSI → stochastic | Same, applied to RSI not price |
| 8 | Bollinger Bands | SMA ± std dev | Price re-enters after breaching a band |
| 9 | Bollinger Band Squeeze | Band width | Squeeze then breakout |
| 10 | ATR Breakout | ATR(14) | Move > ATR × multiple in one candle |
| 11 | Donchian Channel Breakout | Rolling high/low | Close breaks the N-period range |
| 12 | Ichimoku Cloud | Tenkan/Kijun/Cloud | Price breaks cloud + TK alignment |
| 13 | ADX + DI | +DI/-DI + ADX | DI cross while ADX confirms a trend |
| 14 | Parabolic SAR | PSAR | Dot flips to the other side of price |
| 15 | Supertrend | ATR-based bands | Line flips to the other side |
| 16 | VWAP | Session VWAP | Price crosses session VWAP |
| 17 | EMA + RSI Confirmation | EMA cross + RSI | EMA cross agreeing with RSI > / < 50 |
| 18 | MACD + RSI Confirmation | MACD cross + RSI | MACD cross agreeing with RSI > / < 50 |
| 19 | EMA + MACD Trend Confirmation | EMA trend filter + MACD hist | Histogram crosses zero with the EMA trend |
| 20 | Support/Resistance Breakout | Swing highs/lows | Close breaks the latest swing level |
| 21 | Pivot Point Strategy | Classic daily pivot | Price crosses the daily PP |
| 22 | Moving Average + ADX Trend | EMA cross + ADX | EMA cross while ADX confirms trend strength |
| 23 | Mean Reversion | Z-score vs SMA | Price > N std devs from its own average |
| 24 | Momentum Breakout | Rate of Change | ROC crosses a % threshold |

All periods/thresholds shown are configurable defaults (Strategies → tap a
strategy → Parameters), with a reset-to-default option.

## How historical win rate is calculated

Every strategy's "Historical Win Rate" comes from `backtesting/backtest_engine.dart`
replaying it **causally** — bar by bar, only ever looking at candles up to
and including the one being evaluated, exactly like the live Signal Engine
does. For every BUY/SELL the strategy would have produced:

1. A take-profit and stop-loss level are computed the same way a live
   signal's are (see "TP/SL methodology" below).
2. The candles *after* that signal are scanned for whichever level is
   reached first.
3. TP first → **WIN**. SL first → **LOSS**. Neither, within the evaluation
   window → **UNRESOLVED**, excluded from the win-rate percentage (but
   still shown separately, so a low "decided" sample size is visible rather
   than hidden).

**Win rate = winning trades ÷ (winning + losing trades), as a percentage.**
Also tracked: total trades, profit factor (gross profit ÷ gross loss), max
drawdown, and average winning/losing trade size — see `models/backtest_result.dart`.

This is a backtest of the past. It is **not** a predictive probability for
any specific current signal — the app always labels it "Historical Win
Rate," never "chance this trade wins," for exactly that reason.

### A documented, deliberate simplifying assumption

OHLC candles don't record the order prices moved *within* the candle. If a
single candle's range contains **both** the TP and SL level (rare, but
possible on a wide-range candle), there's no way to know from OHLC alone
which was actually touched first. This app resolves that by assuming
whichever level sits closer to that candle's *open* was reached first — a
standard, conservative convention also used by other OHLC-based
backtesters, applied identically for backtesting and live resolution (see
`backtesting/tpsl_rules.dart`). It is disclosed here rather than silently
picked.

### Backtest size cap

A full causal replay is ~O(n²) in candle count (each step re-evaluates the
strategy on a window that's grown by one candle, which is also exactly
what guarantees no future data ever leaks into a decision). To keep a
single backtest run's cost predictable on a phone regardless of timeframe,
`BacktestEngine` analyzes at most the most recent **3,000 candles**
(hard ceiling 6,000) per run. For fine timeframes (1M/5M) requested over a
long date range, this means the *actual* analyzed window is shorter than
requested — `BacktestResult.startDate`/`endDate` always reflect the real
analyzed range, never the nominally-requested one, so nothing is
misrepresented.

## TP/SL methodology

Configurable in Settings:

- **ATR multiple (default)**: TP/SL are placed `atrMultiple × ATR(14)`
  away from the entry price, so they automatically adapt to each pair's
  current volatility instead of using one fixed pip count for every
  market condition. Default multiple: 1.5×.
- **Fixed pips**: a constant distance (default 30 pips), using each pair's
  conventional pip size (0.01 for USD/JPY, 0.0001 for EUR/USD).

If ATR isn't available yet (very early in a series), the app automatically
falls back to the fixed-pips method rather than leaving a signal without
levels.

## Signal resolution rules

A signal starts **ACTIVE**. Every sync cycle, `signals/signal_resolver.dart`
checks newly-arrived candles against its TP/SL using the exact rule above.
It becomes:

- **RESOLVED / WIN** — target reached first.
- **RESOLVED / LOSS** — stop-loss reached first.
- **EXPIRED / UNRESOLVED** — the configured evaluation window (default 50
  candles; Settings → Evaluation window) elapses with neither level
  touched.

## Signal deduplication

A signal's identity is the tuple **(pair, timeframe, strategy, candle
timestamp, direction)** — see `core/id_utils.dart`. The database's own
primary key on that identity is the entire deduplication mechanism: a
repeated refresh while the same candle is still the latest one, with the
same resulting direction, can never create a second row. A new row only
ever appears when a new candle closes, or the same candle's result
genuinely flips direction on a late data correction. Every (pair,
timeframe) combination is independent by construction, since both are part
of the identity.

## Demo vs. live data

Every candle and every signal carries an `isDemo` flag. Demo candles come
from a deterministic function of wall-clock time (not a store-and-replay
random walk), so backtests on demo data are real, reproducible
computations over a fixed synthetic series — never a different fabricated
number on each run. Demo data is labelled "DEMO" everywhere it's shown and
is never silently mixed with live statistics.
