# Troubleshooting

## Most likely build issues, and why

This project was written without access to a Flutter/Android toolchain to
compile against (see BUILD.md's honesty note). These are the specific
places most likely to need a small fix the first time you build, in order
of likelihood:

### 1. "Gradle wrapper jar not found"

Expected — see BUILD.md, "Gradle wrapper JAR." Either let Android Studio
regenerate it, or run `gradle wrapper --gradle-version 8.13` once from
`android/`.

### 2. A `flutter_foreground_task` method signature mismatch in `services/background_service.dart`

This is the single fastest-moving dependency in the project. The
`TaskHandler` overrides (`onStart`, `onRepeatEvent`, `onDestroy`,
`onNotificationButtonPressed`, `onNotificationPressed`,
`onNotificationDismissed`) match the package's published API at the time
of writing. If `flutter analyze` or `flutter build` reports a signature
mismatch:

1. Find the installed package's source: `flutter pub deps` lists its
   resolved version and path (usually under your pub cache, e.g.
   `~/.pub-cache/hosted/pub.dev/flutter_foreground_task-<version>/lib/`).
2. Open `task_handler.dart` in that folder and compare its abstract method
   signatures to the overrides in `background_service.dart`.
3. Adjust parameter names/types to match — the *behavior* (what each
   method does) doesn't need to change, only the signature.

### 3. AGP / Gradle / Kotlin version mismatch

If Gradle sync reports an incompatible combination: check
<https://developer.android.com/build/releases/gradle-plugin> for the AGP
version actually resolved and the Gradle version it requires, then update
`android/gradle/wrapper/gradle-wrapper.properties`. BUILD.md's "Tool
versions" table explains the reasoning behind the versions pinned here.

### 4. `flutter_local_notifications` core library desugaring error

The error message is explicit ("Dependency ... requires core library
desugaring to be enabled"). This is already turned on in
`android/app/build.gradle.kts` (`isCoreLibraryDesugaringEnabled = true`
plus the `desugar_jdk_libs` dependency) — if you still see it, the
resolved plugin version may need a newer `desugar_jdk_libs` release; bump
the version in the `dependencies` block.

### 5. Minor `unused_import` / lint warnings

Possible in a project this size written without a live analyzer. These
never block a build (only `flutter analyze --fatal-infos` would fail on
them, which nothing here invokes) — clean them up at your leisure.

### 6. A package version `flutter pub get` resolves no longer exists / is yanked

Every dependency in `pubspec.yaml` uses a `^` (caret) constraint from a
version confirmed to exist at the time of writing — if pub.dev's resolver
can't find a match, loosen the constraint (e.g. `^11.0.3` → `>=11.0.0
<12.0.0`) and try again.

## Background monitoring stops on its own

Android does **not** guarantee unrestricted background execution for any
app — this is a real platform constraint, not a bug in this project. A
foreground service with a visible notification (what this app uses) is
the most reliable mechanism available, but manufacturer-specific battery
managers can still override it:

- **In this app**: Settings → "Ignore battery optimization" → Request.
  This asks Android's own standard battery-optimization exemption.
- **Samsung**: Settings → Apps → Forex Signals → Battery → set to
  "Unrestricted." Also check Settings → Battery → Background usage limits
  and remove the app from any "sleeping apps" list.
- **Xiaomi (MIUI)**: Settings → Apps → Manage apps → Forex Signals →
  Battery saver → "No restrictions." Also enable Autostart for the app.
- **Huawei**: Settings → Battery → App launch → Forex Signals → switch off
  "Manage automatically" and enable all three toggles (auto-launch,
  secondary launch, run in background).
- **OnePlus (OxygenOS)**: Settings → Battery → Battery optimization →
  Forex Signals → "Don't optimize." Also check Advanced Optimization isn't
  separately re-restricting it.
- **Any device**: if the notification showing "MONITORING" / the last
  update time disappears or stops updating for a long time while the
  screen is off, the OS killed the service — reopen the app and turn
  background monitoring back on.

There is no code-only fix for an OEM battery manager that ignores standard
Android APIs — only the device-settings steps above.

## "No internet connection" / stuck on OFFLINE in Demo mode

Demo mode never needs the network itself, but the app still checks real
device connectivity before syncing (so the behavior matches what Live mode
will do). If you're genuinely offline, this is correct, expected behavior
— the chart/signals should still show the last cached data with a "Last
updated" timestamp (spec section 20), not live-looking data.

## "API key was rejected"

Double-check you copied the whole key with no leading/trailing space, and
that your Twelve Data account is active. See API_SETUP.md.

## "API rate limit reached" happens often

Expected on a free plan with a short refresh interval across two pairs and
several timeframes. Raise the refresh interval or reduce the number of
background timeframes in Settings — see API_SETUP.md, "Rate limits."

## Tests fail with a `MissingPluginException`

`shared_preferences`, `flutter_secure_storage`, `connectivity_plus`,
`flutter_local_notifications`, `flutter_foreground_task`, and
`package_info_plus` all talk to real Android platform code that doesn't
exist in a plain `flutter test` run. Every test in `test/` and
`integration_test/` is deliberately written to avoid touching those
plugins directly:

- Database tests use `sqflite_common_ffi` (a real SQLite engine, no
  platform channel) — see `test/test_utils/db_test_utils.dart`.
- The one widget test suite that exercises real screens
  (`test/widget/app_navigation_test.dart`) uses
  `ConnectivityService.debugIsOnlineOverride` instead of the real
  `connectivity_plus` channel, and deliberately never navigates into the
  Settings screen (the one screen that touches secure storage and
  `package_info_plus`).

If you add a new test that touches the Settings screen or a background
service path, it will need its own fake/mock for whichever plugin it
hits — that's expected, not a sign something here is broken.

## General diagnostic steps

1. `flutter doctor -v` — fixes most environment-level problems.
2. `flutter clean && flutter pub get` — clears stale build caches, often
   fixes "weird" Gradle errors after a dependency version change.
3. Settings → "Export diagnostic logs" inside the app shows recent
   `AppLogger` output (API failures, sync status, signal generation,
   background service status) without needing `adb logcat`.
4. `adb logcat *:E` while reproducing a crash, if you have a device
   connected — filters to error-level only.
