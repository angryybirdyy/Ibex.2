pluginManagement {
    val flutterSdkPath = run {
        val properties = java.util.Properties()
        file("local.properties").inputStream().use { properties.load(it) }
        val flutterSdkPath = properties.getProperty("flutter.sdk")
        require(flutterSdkPath != null) { "flutter.sdk not set in local.properties. Run 'flutter pub get' from the project root once, which regenerates this file, or add it yourself as described in SETUP.md." }
        flutterSdkPath
    }

    includeBuild("$flutterSdkPath/packages/flutter_tools/gradle")

    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

plugins {
    id("dev.flutter.flutter-plugin-loader") version "1.0.0"
    // Pinned versions — see BUILD.md "Tool versions" for the compatibility
    // reasoning (AGP 8.11.1 requires Gradle >= 8.13, matched in
    // gradle/wrapper/gradle-wrapper.properties; Kotlin 2.2.20 matches
    // flutter_foreground_task's minimum at the time this was written).
    id("com.android.application") version "8.11.1" apply false
    id("org.jetbrains.kotlin.android") version "2.2.20" apply false
}

include(":app")
