# Executed only if isMinifyEnabled is ever switched to true (see BUILD.md's
# "Shrinking a release build" section for how and why you'd do that).

# Twelve Data responses are parsed with dart:convert on the Dart side, so no
# Gson/Moshi reflection rules are needed there. Keep flutter_local_notifications'
# and flutter_foreground_task's plugin classes, since both are referenced via
# reflection from generated Flutter plugin registration code.
-keep class com.dexterous.** { *; }
-keep class com.pravera.flutter_foreground_task.** { *; }
