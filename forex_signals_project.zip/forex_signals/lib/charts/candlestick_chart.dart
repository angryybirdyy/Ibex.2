import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../core/enums.dart';
import '../core/market_types.dart';
import '../core/time_utils.dart';
import '../models/candle.dart';

/// One overlay line drawn on top of the candles (an EMA, a Bollinger band,
/// a Supertrend line…), aligned 1:1 with the chart's candle series by
/// index. `null` entries (warm-up period) simply break the line.
class ChartOverlaySeries {
  const ChartOverlaySeries({required this.label, required this.color, required this.values, this.dashed = false});
  final String label;
  final Color color;
  final List<double?> values;
  final bool dashed;
}

/// A shaded band overlay (Bollinger Bands, Ichimoku cloud, Donchian
/// channel): an upper and lower line with the area between tinted.
class ChartBandOverlay {
  const ChartBandOverlay({
    required this.label,
    required this.color,
    required this.upper,
    required this.lower,
  });
  final String label;
  final Color color;
  final List<double?> upper;
  final List<double?> lower;
}

class ChartMarker {
  const ChartMarker({required this.candleIndex, required this.direction, required this.price});
  final int candleIndex;
  final SignalDirection direction;
  final double price;
}

/// Professional candlestick chart with pinch-zoom, drag-to-pan, a
/// press-and-hold crosshair, and price/time axes (spec section 5/6).
/// Strategy overlays and signal markers are passed in by the screen that
/// owns the strategy-visibility toggles — this widget has no idea what a
/// "strategy" is, which is what keeps the required separation between
/// "what's drawn" and "what the Signal Engine calculates" clean (spec
/// sections 5/44): the screen decides what list of overlays to hand this
/// widget, and this widget just draws whatever it's given.
class CandlestickChart extends StatefulWidget {
  const CandlestickChart({
    super.key,
    required this.series,
    required this.pair,
    required this.timeframe,
    this.overlays = const [],
    this.bandOverlays = const [],
    this.markers = const [],
    this.initialVisibleCandles = 90,
  });

  final CandleSeries series;
  final CurrencyPair pair;
  final Timeframe timeframe;
  final List<ChartOverlaySeries> overlays;
  final List<ChartBandOverlay> bandOverlays;
  final List<ChartMarker> markers;
  final int initialVisibleCandles;

  @override
  State<CandlestickChart> createState() => _CandlestickChartState();
}

class _CandlestickChartState extends State<CandlestickChart> {
  late int _visibleCount;
  late int _endIndex; // exclusive — window is [startIndex, endIndex)
  double? _crosshairLocalX;

  int _initialVisibleCountOnGesture = 0;
  int _initialEndIndexOnGesture = 0;
  double _lastCandleWidth = 1;

  @override
  void initState() {
    super.initState();
    _visibleCount = widget.initialVisibleCandles.clamp(10, _maxVisible);
    _endIndex = widget.series.length;
  }

  @override
  void didUpdateWidget(covariant CandlestickChart oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.series.length != widget.series.length) {
      // New candles arrived — keep showing "the latest" unless the user was
      // scrolled back into history, in which case leave their scroll alone.
      final wasAtLatest = _endIndex >= oldWidget.series.length;
      _visibleCount = _visibleCount.clamp(10, _maxVisible);
      if (wasAtLatest) _endIndex = widget.series.length;
    }
  }

  int get _maxVisible => widget.series.length.clamp(10, 1 << 30);
  int get _startIndex => (_endIndex - _visibleCount).clamp(0, widget.series.length);

  void _onScaleStart(ScaleStartDetails details) {
    _initialVisibleCountOnGesture = _visibleCount;
    _initialEndIndexOnGesture = _endIndex;
  }

  void _onScaleUpdate(ScaleUpdateDetails details) {
    setState(() {
      if (details.scale != 1.0) {
        final newVisible = (_initialVisibleCountOnGesture / details.scale).round();
        _visibleCount = newVisible.clamp(10, _maxVisible);
      }
      if (_lastCandleWidth > 0) {
        final panCandles = -details.focalPointDelta.dx / _lastCandleWidth;
        _endIndex = (_endIndex + panCandles.round()).clamp(_visibleCount, widget.series.length);
      }
    });
  }

  void _updateCrosshair(Offset localPosition) {
    setState(() => _crosshairLocalX = localPosition.dx);
  }

  void _clearCrosshair() => setState(() => _crosshairLocalX = null);

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    if (widget.series.isEmpty) {
      return const Center(child: Text('No candle data yet.'));
    }
    return LayoutBuilder(builder: (context, constraints) {
      return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onScaleStart: _onScaleStart,
        onScaleUpdate: _onScaleUpdate,
        onLongPressStart: (d) => _updateCrosshair(d.localPosition),
        onLongPressMoveUpdate: (d) => _updateCrosshair(d.localPosition),
        onLongPressEnd: (_) => _clearCrosshair(),
        child: CustomPaint(
          size: Size(constraints.maxWidth, constraints.maxHeight),
          painter: _CandlestickPainter(
            series: widget.series,
            pair: widget.pair,
            timeframe: widget.timeframe,
            overlays: widget.overlays,
            bandOverlays: widget.bandOverlays,
            markers: widget.markers,
            startIndex: _startIndex,
            endIndex: _endIndex,
            crosshairLocalX: _crosshairLocalX,
            isDark: isDark,
            onCandleWidthComputed: (w) => _lastCandleWidth = w,
          ),
        ),
      );
    });
  }
}

class _CandlestickPainter extends CustomPainter {
  _CandlestickPainter({
    required this.series,
    required this.pair,
    required this.timeframe,
    required this.overlays,
    required this.bandOverlays,
    required this.markers,
    required this.startIndex,
    required this.endIndex,
    required this.crosshairLocalX,
    required this.isDark,
    required this.onCandleWidthComputed,
  });

  final CandleSeries series;
  final CurrencyPair pair;
  final Timeframe timeframe;
  final List<ChartOverlaySeries> overlays;
  final List<ChartBandOverlay> bandOverlays;
  final List<ChartMarker> markers;
  final int startIndex;
  final int endIndex;
  final double? crosshairLocalX;
  final bool isDark;
  final ValueChanged<double> onCandleWidthComputed;

  static const double _priceAxisWidth = 60;
  static const double _timeAxisHeight = 22;

  @override
  void paint(Canvas canvas, Size size) {
    final visibleCount = (endIndex - startIndex).clamp(1, series.length);
    final plotWidth = size.width - _priceAxisWidth;
    final plotHeight = size.height - _timeAxisHeight;
    final candleWidth = plotWidth / visibleCount;
    onCandleWidthComputed(candleWidth);

    final borderColor = isDark ? AppColors.darkBorder : AppColors.lightBorder;
    final textColor = isDark ? AppColors.darkTextSecondary : AppColors.lightTextSecondary;

    // --- Price range across visible candles AND visible overlay values,
    // so an overlay (e.g. a wide Bollinger band) is never clipped.
    double minPrice = double.infinity, maxPrice = -double.infinity;
    for (int i = startIndex; i < endIndex; i++) {
      final c = series[i];
      if (c.low < minPrice) minPrice = c.low;
      if (c.high > maxPrice) maxPrice = c.high;
    }
    void considerValue(double? v) {
      if (v == null) return;
      if (v < minPrice) minPrice = v;
      if (v > maxPrice) maxPrice = v;
    }

    for (final o in overlays) {
      for (int i = startIndex; i < endIndex && i < o.values.length; i++) {
        considerValue(o.values[i]);
      }
    }
    for (final b in bandOverlays) {
      for (int i = startIndex; i < endIndex; i++) {
        if (i < b.upper.length) considerValue(b.upper[i]);
        if (i < b.lower.length) considerValue(b.lower[i]);
      }
    }
    if (minPrice == double.infinity) {
      minPrice = 0;
      maxPrice = 1;
    }
    final padding = (maxPrice - minPrice) * 0.08 + (maxPrice == minPrice ? 0.001 : 0);
    minPrice -= padding;
    maxPrice += padding;
    final priceRange = (maxPrice - minPrice) == 0 ? 1 : (maxPrice - minPrice);

    double yFor(double price) => plotHeight - ((price - minPrice) / priceRange) * plotHeight;
    double xForIndex(int i) => (i - startIndex) * candleWidth + candleWidth / 2;

    // --- Grid + price axis
    final gridPaint = Paint()
      ..color = borderColor.withValues(alpha: 0.5)
      ..strokeWidth = 1;
    const gridLines = 5;
    for (int g = 0; g <= gridLines; g++) {
      final y = plotHeight * g / gridLines;
      canvas.drawLine(Offset(0, y), Offset(plotWidth, y), gridPaint);
      final price = maxPrice - (priceRange * g / gridLines);
      _drawText(canvas, pair.formatPrice(price), Offset(plotWidth + 6, y - 6), textColor, 10);
    }

    // --- Band overlays (draw before candles so bands sit behind price action)
    for (final band in bandOverlays) {
      final fillPaint = Paint()..color = band.color.withValues(alpha: 0.10);
      final path = Path();
      bool started = false;
      for (int i = startIndex; i < endIndex; i++) {
        final u = i < band.upper.length ? band.upper[i] : null;
        if (u == null) continue;
        final x = xForIndex(i);
        if (!started) {
          path.moveTo(x, yFor(u));
          started = true;
        } else {
          path.lineTo(x, yFor(u));
        }
      }
      for (int i = endIndex - 1; i >= startIndex; i--) {
        final l = i < band.lower.length ? band.lower[i] : null;
        if (l == null) continue;
        path.lineTo(xForIndex(i), yFor(l));
      }
      path.close();
      if (started) canvas.drawPath(path, fillPaint);
      _drawLine(canvas, band.upper, startIndex, endIndex, xForIndex, yFor, band.color, false);
      _drawLine(canvas, band.lower, startIndex, endIndex, xForIndex, yFor, band.color, false);
    }

    // --- Candles
    for (int i = startIndex; i < endIndex; i++) {
      final c = series[i];
      final x = xForIndex(i);
      final isUp = c.close >= c.open;
      final color = isUp ? AppColors.bullish : AppColors.bearish;
      final wickPaint = Paint()
        ..color = color
        ..strokeWidth = 1.2;
      canvas.drawLine(Offset(x, yFor(c.high)), Offset(x, yFor(c.low)), wickPaint);

      final bodyTop = yFor(isUp ? c.close : c.open);
      final bodyBottom = yFor(isUp ? c.open : c.close);
      final bodyWidth = candleWidth * 0.62;
      final rect = Rect.fromLTRB(x - bodyWidth / 2, bodyTop, x + bodyWidth / 2,
          bodyBottom == bodyTop ? bodyTop + 1 : bodyBottom);
      canvas.drawRect(rect, Paint()..color = color);
    }

    // --- Line overlays (EMA, Supertrend, VWAP, Pivot…)
    for (final o in overlays) {
      _drawLine(canvas, o.values, startIndex, endIndex, xForIndex, yFor, o.color, o.dashed);
    }

    // --- Signal markers
    for (final m in markers) {
      if (m.candleIndex < startIndex || m.candleIndex >= endIndex) continue;
      final x = xForIndex(m.candleIndex);
      final isBuy = m.direction == SignalDirection.buy;
      final y = yFor(m.price) + (isBuy ? 14 : -14);
      final color = isBuy ? AppColors.bullish : AppColors.bearish;
      _drawTriangleMarker(canvas, Offset(x, y), color, pointingUp: isBuy);
    }

    // --- Time axis
    final labelCount = (plotWidth / 90).floor().clamp(2, 6);
    for (int k = 0; k <= labelCount; k++) {
      final idx = startIndex + ((visibleCount - 1) * k / labelCount).round();
      if (idx < 0 || idx >= series.length) continue;
      final x = xForIndex(idx);
      _drawText(canvas, formatLocalTime(series[idx].timestamp), Offset(x - 18, plotHeight + 4), textColor, 10);
    }

    // --- Crosshair
    if (crosshairLocalX != null) {
      final clampedX = crosshairLocalX!.clamp(0, plotWidth);
      final idx = (startIndex + (clampedX / candleWidth)).floor().clamp(startIndex, endIndex - 1);
      final c = series[idx];
      final crossPaint = Paint()
        ..color = textColor
        ..strokeWidth = 1;
      canvas.drawLine(Offset(clampedX, 0), Offset(clampedX, plotHeight), crossPaint);
      final y = yFor(c.close);
      canvas.drawLine(Offset(0, y), Offset(plotWidth, y), crossPaint);

      final info = 'O ${pair.formatPrice(c.open)}  H ${pair.formatPrice(c.high)}  '
          'L ${pair.formatPrice(c.low)}  C ${pair.formatPrice(c.close)}\n${formatLocal(c.timestamp)}';
      _drawInfoBox(canvas, info, const Offset(8, 8), isDark);
    }

    // --- Frame
    canvas.drawRect(Rect.fromLTWH(0, 0, plotWidth, plotHeight), Paint()
      ..color = borderColor
      ..style = PaintingStyle.stroke);
  }

  void _drawLine(
    Canvas canvas,
    List<double?> values,
    int start,
    int end,
    double Function(int) xFor,
    double Function(double) yFor,
    Color color,
    bool dashed,
  ) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1.6
      ..style = PaintingStyle.stroke;

    if (!dashed) {
      final path = Path();
      bool started = false;
      for (int i = start; i < end && i < values.length; i++) {
        final v = values[i];
        if (v == null) {
          started = false;
          continue;
        }
        final x = xFor(i), y = yFor(v);
        if (!started) {
          path.moveTo(x, y);
          started = true;
        } else {
          path.lineTo(x, y);
        }
      }
      canvas.drawPath(path, paint);
      return;
    }

    // Dashed: draw short segments with gaps between consecutive points
    // rather than a continuous path, so a "slow" line reads as visually
    // distinct from a "fast" line of the same color at a glance.
    const dashLen = 5.0, gapLen = 3.0;
    Offset? prev;
    for (int i = start; i < end && i < values.length; i++) {
      final v = values[i];
      if (v == null) {
        prev = null;
        continue;
      }
      final cur = Offset(xFor(i), yFor(v));
      if (prev != null) {
        final total = (cur - prev).distance;
        if (total > 0) {
          final dir = (cur - prev) / total;
          double travelled = 0;
          bool draw = true;
          while (travelled < total) {
            final segLen = (draw ? dashLen : gapLen).clamp(0, total - travelled);
            final segStart = prev + dir * travelled;
            final segEnd = prev + dir * (travelled + segLen);
            if (draw) canvas.drawLine(segStart, segEnd, paint);
            travelled += segLen;
            draw = !draw;
          }
        }
      }
      prev = cur;
    }
  }

  void _drawTriangleMarker(Canvas canvas, Offset center, Color color, {required bool pointingUp}) {
    final paint = Paint()..color = color;
    final path = Path();
    const s = 6.0;
    if (pointingUp) {
      path.moveTo(center.dx, center.dy - s);
      path.lineTo(center.dx - s, center.dy + s);
      path.lineTo(center.dx + s, center.dy + s);
    } else {
      path.moveTo(center.dx, center.dy + s);
      path.lineTo(center.dx - s, center.dy - s);
      path.lineTo(center.dx + s, center.dy - s);
    }
    path.close();
    canvas.drawPath(path, paint);
  }

  void _drawText(Canvas canvas, String text, Offset offset, Color color, double fontSize) {
    final painter = TextPainter(
      text: TextSpan(text: text, style: TextStyle(color: color, fontSize: fontSize)),
      textDirection: ui.TextDirection.ltr,
    )..layout();
    painter.paint(canvas, offset);
  }

  void _drawInfoBox(Canvas canvas, String text, Offset offset, bool isDark) {
    final painter = TextPainter(
      text: TextSpan(
        text: text,
        style: TextStyle(
          color: isDark ? AppColors.darkTextPrimary : AppColors.lightTextPrimary,
          fontSize: 10.5,
          fontFeatures: const [ui.FontFeature.tabularFigures()],
        ),
      ),
      textDirection: ui.TextDirection.ltr,
    )..layout();
    final bgRect = Rect.fromLTWH(offset.dx - 4, offset.dy - 2, painter.width + 8, painter.height + 4);
    canvas.drawRRect(
      RRect.fromRectAndRadius(bgRect, const Radius.circular(4)),
      Paint()..color = (isDark ? AppColors.darkSurfaceRaised : AppColors.lightSurface).withValues(alpha: 0.92),
    );
    painter.paint(canvas, offset);
  }

  @override
  bool shouldRepaint(covariant _CandlestickPainter oldDelegate) {
    return oldDelegate.series != series ||
        oldDelegate.startIndex != startIndex ||
        oldDelegate.endIndex != endIndex ||
        oldDelegate.overlays != overlays ||
        oldDelegate.bandOverlays != bandOverlays ||
        oldDelegate.markers != markers ||
        oldDelegate.crosshairLocalX != crosshairLocalX;
  }
}
