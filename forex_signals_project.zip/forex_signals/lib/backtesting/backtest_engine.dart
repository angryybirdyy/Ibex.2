import '../core/enums.dart';
import '../core/market_types.dart';
import '../indicators/atr.dart';
import '../models/backtest_result.dart';
import '../models/candle.dart';
import '../strategies/strategy.dart';
import 'tpsl_rules.dart';

/// Replays a [Strategy] bar-by-bar over real historical candles and scores
/// every signal it would have produced against the same TP/SL rules used
/// live (spec sections 12/22). This is the *only* place win rates come
/// from — nothing in the UI is allowed to display a win rate that didn't
/// come out of a [BacktestResult] built here.
///
/// **Performance note (documented, not hidden):** to stay causal — a
/// strategy must never see a candle from its own future — each step re-runs
/// `strategy.evaluateSafe` on a growing window `[0, i]`. Since the 24
/// strategies are plain, stateless functions of the candles they're given
/// (by design, so the exact same class works for both live signals and this
/// backtest), that makes one full backtest run roughly O(n²) in candle
/// count. [maxCandles] bounds this to a fixed, predictable cost regardless
/// of timeframe: a request for more history than the cap allows is honored
/// with the most recent [maxCandles] candles rather than silently the whole
/// range, and the *actual* analyzed start/end dates on the returned
/// [BacktestResult] always reflect what was really used.
class BacktestEngine {
  BacktestEngine._();

  static const int defaultMaxCandles = 3000;
  static const int hardMaxCandles = 6000;

  static Future<BacktestResult> run({
    required Strategy strategy,
    required CurrencyPair pair,
    required Timeframe timeframe,
    required CandleSeries fullHistory,
    Map<String, num>? strategyParams,
    required TpSlMethod tpSlMethod,
    required double atrMultiple,
    required double fixedPips,
    required int evaluationWindowCandles,
    int? maxCandles,
  }) async {
    final cap = (maxCandles ?? defaultMaxCandles).clamp(100, hardMaxCandles);
    final allCandles = fullHistory.candles;
    final usable = allCandles.length > cap ? allCandles.sublist(allCandles.length - cap) : allCandles;
    final now = DateTime.now().toUtc();

    if (usable.length < strategy.minCandles + 5) {
      // Not enough history to run even once — return an honest empty
      // result rather than fabricating trades or throwing.
      return BacktestResult(
        strategyId: strategy.id,
        pairCode: pair.code,
        timeframeLabel: timeframe.label,
        startDate: now,
        endDate: now,
        trades: const [],
        computedAt: now,
      );
    }

    final series = CandleSeries(usable);
    final atrSeries = Atr.compute(series, period: 14);
    final trades = <BacktestTrade>[];

    for (int i = strategy.minCandles; i < series.length; i++) {
      final causalWindow = CandleSeries(series.candles.sublist(0, i + 1));
      final result = strategy.evaluateSafe(causalWindow, overrides: strategyParams);
      if (result.direction == StrategyDirection.neutral) continue;

      final direction =
          result.direction == StrategyDirection.buy ? SignalDirection.buy : SignalDirection.sell;
      final levels = computeTpSl(
        direction: direction,
        entryPrice: result.entryPriceRef,
        pair: pair,
        method: tpSlMethod,
        atrValue: atrSeries[i],
        atrMultiple: atrMultiple,
        fixedPips: fixedPips,
      );

      final windowEnd = (i + 1 + evaluationWindowCandles).clamp(0, series.length);
      final future = series.candles.sublist(i + 1, windowEnd);
      final outcome = evaluateSignalOutcome(
        direction: direction,
        target: levels.target,
        stopLoss: levels.stopLoss,
        futureCandles: future,
      );

      trades.add(BacktestTrade(
        direction: direction,
        entryTime: result.timestamp,
        entryPrice: result.entryPriceRef,
        targetPrice: levels.target,
        stopLossPrice: levels.stopLoss,
        result: outcome.result,
        exitTime: outcome.exitTime,
        exitPrice: outcome.exitPrice,
      ));
    }

    return BacktestResult(
      strategyId: strategy.id,
      pairCode: pair.code,
      timeframeLabel: timeframe.label,
      startDate: series.candles.first.timestamp,
      endDate: series.candles.last.timestamp,
      trades: trades,
      computedAt: now,
    );
  }

  /// Runs every strategy in [strategies] against the same history —used by
  /// "recalculate all win rates" in Settings > Database management.
  static Future<List<BacktestResult>> runAll({
    required List<Strategy> strategies,
    required CurrencyPair pair,
    required Timeframe timeframe,
    required CandleSeries fullHistory,
    required TpSlMethod tpSlMethod,
    required double atrMultiple,
    required double fixedPips,
    required int evaluationWindowCandles,
    int? maxCandles,
  }) async {
    final results = <BacktestResult>[];
    for (final strategy in strategies) {
      results.add(await run(
        strategy: strategy,
        pair: pair,
        timeframe: timeframe,
        fullHistory: fullHistory,
        tpSlMethod: tpSlMethod,
        atrMultiple: atrMultiple,
        fixedPips: fixedPips,
        evaluationWindowCandles: evaluationWindowCandles,
        maxCandles: maxCandles,
      ));
    }
    return results;
  }
}
