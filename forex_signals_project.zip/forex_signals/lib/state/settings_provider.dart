import 'package:flutter/foundation.dart';

import '../core/enums.dart';
import '../models/app_settings.dart';
import '../services/settings_repository.dart';
import 'app_services.dart';

/// UI-facing settings state (spec section 29). Every mutation persists via
/// [SettingsRepository] and pushes the new value into [AppServices] so the
/// Signal Engine picks it up on its very next cycle.
class SettingsProvider extends ChangeNotifier {
  SettingsProvider(this._appServices) : _settings = _appServices.settings;

  final AppServices _appServices;
  AppSettings _settings;

  AppSettings get settings => _settings;

  Future<void> _apply(AppSettings updated) async {
    _settings = updated;
    _appServices.updateSettings(updated);
    notifyListeners();
    await SettingsRepository.instance.save(updated);
  }

  Future<void> setDataMode(DataMode mode) => _apply(_settings.copyWith(dataMode: mode));
  Future<void> setRefreshIntervalMinutes(int minutes) =>
      _apply(_settings.copyWith(refreshIntervalMinutes: minutes));
  Future<void> setBackgroundMonitoringEnabled(bool enabled) =>
      _apply(_settings.copyWith(backgroundMonitoringEnabled: enabled));
  Future<void> setNotificationsEnabled(bool enabled) =>
      _apply(_settings.copyWith(notificationsEnabled: enabled));
  Future<void> setDarkMode(bool enabled) => _apply(_settings.copyWith(darkMode: enabled));
  Future<void> setDefaultTimeframeLabel(String label) =>
      _apply(_settings.copyWith(defaultTimeframeLabel: label));
  Future<void> setBacktestMonths(int months) => _apply(_settings.copyWith(backtestMonths: months));
  Future<void> setTpSlMethod(TpSlMethod method) => _apply(_settings.copyWith(tpSlMethod: method));
  Future<void> setAtrMultiple(double value) => _apply(_settings.copyWith(atrMultiple: value));
  Future<void> setFixedPips(double value) => _apply(_settings.copyWith(fixedPips: value));
  Future<void> setEvaluationWindowCandles(int value) =>
      _apply(_settings.copyWith(evaluationWindowCandles: value));
  Future<void> setBackgroundTimeframeLabels(List<String> labels) =>
      _apply(_settings.copyWith(backgroundTimeframeLabels: labels));
  Future<void> markFirstRunComplete() => _apply(_settings.copyWith(hasCompletedFirstRun: true));
}
