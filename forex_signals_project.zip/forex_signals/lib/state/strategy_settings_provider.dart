import 'package:flutter/foundation.dart';

import '../database/strategy_settings_dao.dart';
import '../strategies/strategy_registry.dart';

/// Backs the Strategies screen's toggles and parameter editors (spec
/// sections 9/23).
///
/// [chartEnabled] controls *only* what `screens/chart/chart_screen.dart`
/// draws as overlays — it is never read by `signals/signal_engine.dart`,
/// which always iterates `StrategyRegistry.all` directly. That separation
/// is the whole point of spec sections 9/44 and is enforced simply by the
/// fact that the Signal Engine's constructor never even receives a
/// reference to this class.
class StrategySettingsProvider extends ChangeNotifier {
  StrategySettingsProvider(this._dao);
  final StrategySettingsDao _dao;

  Map<String, bool> _chartEnabled = {};
  final Map<String, Map<String, num>> _paramOverrides = {};
  bool _loaded = false;

  bool get isLoaded => _loaded;

  bool isChartEnabled(String strategyId) => _chartEnabled[strategyId] ?? true;

  Map<String, num> paramsFor(String strategyId) {
    final strategy = StrategyRegistry.byId(strategyId);
    final overrides = _paramOverrides[strategyId];
    return strategy.mergeParams(overrides);
  }

  Future<void> load() async {
    _chartEnabled = await _dao.getAllChartEnabled();
    for (final strategy in StrategyRegistry.all) {
      _paramOverrides[strategy.id] = await _dao.getParamOverrides(strategy.id);
    }
    _loaded = true;
    notifyListeners();
  }

  Future<void> setChartEnabled(String strategyId, bool enabled) async {
    _chartEnabled[strategyId] = enabled;
    notifyListeners();
    await _dao.setChartEnabled(strategyId, enabled);
  }

  Future<void> selectAll() async {
    final ids = StrategyRegistry.all.map((s) => s.id);
    for (final id in ids) {
      _chartEnabled[id] = true;
    }
    notifyListeners();
    await _dao.setAllChartEnabled(ids, true);
  }

  Future<void> deselectAll() async {
    final ids = StrategyRegistry.all.map((s) => s.id);
    for (final id in ids) {
      _chartEnabled[id] = false;
    }
    notifyListeners();
    await _dao.setAllChartEnabled(ids, false);
  }

  Future<void> resetToDefault() async {
    _chartEnabled = {for (final s in StrategyRegistry.all) s.id: true};
    _paramOverrides.clear();
    notifyListeners();
    await _dao.clearAllSelections();
    await _dao.resetAllParams();
  }

  Future<void> setParam(String strategyId, String key, num value) async {
    final current = Map<String, num>.from(_paramOverrides[strategyId] ?? {});
    current[key] = value;
    _paramOverrides[strategyId] = current;
    notifyListeners();
    await _dao.setParam(strategyId, key, value);
  }

  Future<void> resetParams(String strategyId) async {
    _paramOverrides[strategyId] = {};
    notifyListeners();
    await _dao.resetParams(strategyId);
  }
}
