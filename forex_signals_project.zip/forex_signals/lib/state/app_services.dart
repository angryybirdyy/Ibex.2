import '../data/market_data_repository.dart';
import '../data/provider_factory.dart';
import '../database/app_database.dart';
import '../database/backtest_dao.dart';
import '../database/candle_dao.dart';
import '../database/signal_dao.dart';
import '../database/strategy_settings_dao.dart';
import '../database/sync_state_dao.dart';
import '../models/app_settings.dart';
import '../services/settings_repository.dart';
import '../signals/signal_engine.dart';

/// Every long-lived, non-UI object the app needs, built once in `main.dart`
/// and handed down via a single `Provider.value` at the widget tree's root
/// (see `app.dart`'s `ForexSignalsRoot`). This is the composition root
/// referenced throughout ARCHITECTURE.md's layer diagram — screens and
/// per-screen `ChangeNotifier`s depend on this, never on `sqflite`/`http`
/// directly, which is what keeps them testable with fakes.
class AppServices {
  AppServices._({
    required this.appDatabase,
    required this.candleDao,
    required this.signalDao,
    required this.backtestDao,
    required this.strategySettingsDao,
    required this.syncStateDao,
    required this.repository,
    required this.signalEngine,
    required AppSettings initialSettings,
  }) : _settings = initialSettings;

  /// Public equivalent of the private constructor above, for tests that
  /// need a real [AppServices] wired to fakes/in-memory dependencies
  /// (demo provider, ffi SQLite) without going through
  /// [bootstrap]'s platform-channel-dependent startup sequence. Production
  /// code always uses [bootstrap] instead.
  AppServices.forTesting({
    required this.appDatabase,
    required this.candleDao,
    required this.signalDao,
    required this.backtestDao,
    required this.strategySettingsDao,
    required this.syncStateDao,
    required this.repository,
    required this.signalEngine,
    required AppSettings initialSettings,
  }) : _settings = initialSettings;

  final AppDatabase appDatabase;
  final CandleDao candleDao;
  final SignalDao signalDao;
  final BacktestDao backtestDao;
  final StrategySettingsDao strategySettingsDao;
  final SyncStateDao syncStateDao;
  final MarketDataRepository repository;
  final SignalEngine signalEngine;

  AppSettings _settings;
  AppSettings get settings => _settings;

  /// Called by `SettingsProvider` after every change so the next signal
  /// cycle (and anything else reading `getSettings()`) sees it immediately,
  /// without every consumer needing its own copy of `AppSettings`.
  void updateSettings(AppSettings settings) {
    _settings = settings;
  }

  static Future<AppServices> bootstrap() async {
    final db = await AppDatabase.open();
    final candleDao = CandleDao(db);
    final signalDao = SignalDao(db);
    final backtestDao = BacktestDao(db);
    final strategySettingsDao = StrategySettingsDao(db);
    final syncStateDao = SyncStateDao(db);
    final settings = await SettingsRepository.instance.load();

    late final AppServices services;
    final repository = MarketDataRepository(
      candleDao: candleDao,
      syncStateDao: syncStateDao,
      providerGetter: () => ProviderFactory.create(services.settings.dataMode),
    );

    final engine = SignalEngine(
      getSeries: (pair, tf, {limit = 300}) => repository.getSeries(pair, tf, limit: limit),
      syncPairTimeframe: (pair, tf, {outputSize = 300}) =>
          repository.syncPairTimeframe(pair, tf, outputSize: outputSize),
      candleDao: candleDao,
      signalDao: signalDao,
      backtestDao: backtestDao,
      strategySettingsDao: strategySettingsDao,
      getSettings: () => services.settings,
    );

    services = AppServices._(
      appDatabase: db,
      candleDao: candleDao,
      signalDao: signalDao,
      backtestDao: backtestDao,
      strategySettingsDao: strategySettingsDao,
      syncStateDao: syncStateDao,
      repository: repository,
      signalEngine: engine,
      initialSettings: settings,
    );
    return services;
  }
}
