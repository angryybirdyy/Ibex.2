import 'package:flutter/foundation.dart';

import '../core/failures.dart';
import '../core/market_types.dart';
import '../models/candle.dart';
import '../models/signal.dart';
import 'app_services.dart';

/// Owns everything one chart tab (USD/JPY or EUR/USD) needs (spec sections
/// 5/6). One instance is created per tab and kept alive for the tab's
/// lifetime via `IndexedStack` in `screens/root_shell.dart`, which is what
/// satisfies "each tab should preserve its state when switching" —
/// switching tabs never disposes this provider, so the selected timeframe,
/// scroll position, and cached candles all survive.
class ChartDataProvider extends ChangeNotifier {
  ChartDataProvider({required AppServices appServices, required this.pair, Timeframe? initialTimeframe})
      : _appServices = appServices,
        selectedTimeframe = initialTimeframe ?? Timeframe.m15;

  final AppServices _appServices;
  final CurrencyPair pair;

  Timeframe selectedTimeframe;
  CandleSeries series = CandleSeries(const []);

  /// Signals for this exact (pair, timeframe), used only to place buy/sell
  /// markers on the chart — the Signals *tab* is the source of truth for
  /// browsing/filtering signals; this is purely a rendering convenience.
  List<Signal> markerSignals = const [];

  bool isLoading = false;
  bool isOffline = false;
  AppFailure? lastError;
  DateTime? lastUpdatedUtc;

  Future<void> loadInitial() async {
    await _loadFromCache();
    await refresh();
  }

  Future<void> _loadFromCache() async {
    series = await _appServices.repository.getSeries(pair, selectedTimeframe, limit: 500);
    markerSignals = await _appServices.signalDao.query(pair: pair.code, timeframe: selectedTimeframe.label, limit: 300);
    notifyListeners();
  }

  Future<void> changeTimeframe(Timeframe tf) async {
    if (tf == selectedTimeframe) return;
    selectedTimeframe = tf;
    isLoading = true;
    notifyListeners();
    await _loadFromCache();
    await refresh();
  }

  Future<void> refresh() async {
    isLoading = true;
    notifyListeners();
    final failure = await _appServices.repository.syncPairTimeframe(pair, selectedTimeframe);
    lastError = failure;
    isOffline = failure is NoConnectionFailure;
    if (failure == null) {
      lastUpdatedUtc = DateTime.now().toUtc();
    } else {
      // Keep whatever was already cached/displayed (spec section 20) — we
      // still re-read from cache below in case another sync (e.g. the
      // background service) updated it since we last read.
      final syncState = await _appServices.repository.getSyncState(pair, selectedTimeframe);
      lastUpdatedUtc = syncState.lastSyncedAt;
    }
    series = await _appServices.repository.getSeries(pair, selectedTimeframe, limit: 500);
    markerSignals = await _appServices.signalDao.query(pair: pair.code, timeframe: selectedTimeframe.label, limit: 300);
    isLoading = false;
    notifyListeners();
  }
}
