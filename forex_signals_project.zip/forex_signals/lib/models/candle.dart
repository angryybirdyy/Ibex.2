import '../core/time_utils.dart';

/// One OHLC(V) bar. [timestamp] is always UTC and always the *start* of the
/// bar (see `core/time_utils.dart#floorToCandle`).
class Candle {
  const Candle({
    required this.timestamp,
    required this.open,
    required this.high,
    required this.low,
    required this.close,
    this.volume = 0,
    this.isDemo = false,
  });

  final DateTime timestamp; // UTC, floored to interval start
  final double open;
  final double high;
  final double low;
  final double close;
  final double volume;

  /// True when this candle came from the demo/mock provider. Persisted so
  /// that demo data already in the local cache is never silently displayed
  /// as if it were live (spec section 41).
  final bool isDemo;

  Candle copyWith({
    DateTime? timestamp,
    double? open,
    double? high,
    double? low,
    double? close,
    double? volume,
    bool? isDemo,
  }) {
    return Candle(
      timestamp: timestamp ?? this.timestamp,
      open: open ?? this.open,
      high: high ?? this.high,
      low: low ?? this.low,
      close: close ?? this.close,
      volume: volume ?? this.volume,
      isDemo: isDemo ?? this.isDemo,
    );
  }

  Map<String, Object?> toMap(String pairCode, String timeframeLabel) => {
        'pair': pairCode,
        'timeframe': timeframeLabel,
        'ts': toStorageString(timestamp),
        'open': open,
        'high': high,
        'low': low,
        'close': close,
        'volume': volume,
        'is_demo': isDemo ? 1 : 0,
      };

  static Candle fromMap(Map<String, Object?> map) => Candle(
        timestamp: fromStorageString(map['ts'] as String),
        open: (map['open'] as num).toDouble(),
        high: (map['high'] as num).toDouble(),
        low: (map['low'] as num).toDouble(),
        close: (map['close'] as num).toDouble(),
        volume: (map['volume'] as num?)?.toDouble() ?? 0,
        isDemo: (map['is_demo'] as int? ?? 0) == 1,
      );

  @override
  String toString() =>
      'Candle(${timestamp.toIso8601String()} O:$open H:$high L:$low C:$close)';
}

/// A read-only, indexable window of candles in chronological order (oldest
/// first). Indicators operate on this rather than a raw `List<Candle>` so
/// that "not enough data" is a single, consistent check
/// ([CandleSeries.length]) everywhere.
class CandleSeries {
  CandleSeries(List<Candle> candles) : candles = List.unmodifiable(candles);

  final List<Candle> candles;

  int get length => candles.length;
  bool get isEmpty => candles.isEmpty;
  Candle operator [](int i) => candles[i];
  Candle get last => candles.last;
  List<double> get closes => candles.map((c) => c.close).toList(growable: false);
  List<double> get highs => candles.map((c) => c.high).toList(growable: false);
  List<double> get lows => candles.map((c) => c.low).toList(growable: false);
  List<double> get opens => candles.map((c) => c.open).toList(growable: false);
  List<double> get volumes => candles.map((c) => c.volume).toList(growable: false);

  /// A causal sub-window covering indices `[0, uptoExclusive)`. Used by the
  /// backtesting engine to replay history bar-by-bar without ever letting a
  /// strategy see future candles.
  CandleSeries upTo(int uptoExclusive) =>
      CandleSeries(candles.sublist(0, uptoExclusive));
}
