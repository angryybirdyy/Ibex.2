/// Static, human-authored description of one strategy, shown in the
/// Strategies > (i) info modal (spec section 8). This is prose, not
/// calculation logic — the calculation itself lives in the matching class
/// under `strategies/`.
class StrategyMeta {
  const StrategyMeta({
    required this.id,
    required this.name,
    required this.shortExplanation,
    required this.indicatorsUsed,
    required this.calculationLogic,
    required this.buyConditions,
    required this.sellConditions,
    required this.neutralConditions,
    required this.suitableMarketConditions,
    required this.typicalWeaknesses,
    required this.usualTimeframes,
  });

  /// Stable identifier, e.g. `'sma_crossover'`. Used as the DB key for
  /// selection/params and must never change once shipped (renaming would
  /// silently orphan a user's saved toggle state).
  final String id;
  final String name;
  final String shortExplanation;
  final List<String> indicatorsUsed;
  final String calculationLogic;
  final String buyConditions;
  final String sellConditions;
  final String neutralConditions;
  final String suitableMarketConditions;
  final String typicalWeaknesses;
  final String usualTimeframes;

  /// Shared, honest explanation of how win-rate is computed — identical for
  /// every strategy because the *methodology* is shared (see
  /// `backtesting/backtest_engine.dart`); only the entry/exit *signals*
  /// differ per strategy. Kept as one function so the wording can't drift
  /// out of sync with the real implementation.
  static String winRateMethodology() =>
      'This strategy is replayed candle-by-candle over downloaded historical '
      'data. Every time it would have fired a BUY or SELL, the app checks '
      'whether the configured take-profit level was reached before the '
      'stop-loss level within the evaluation window. Win rate = winning '
      'trades ÷ (winning + losing trades); unresolved trades (window expired '
      'with neither level hit) are tracked separately and excluded from the '
      'percentage. This is a backtest of the past, not a prediction — see '
      '"Historical Win Rate" vs "Current Signal" in the app for why the two '
      'are not the same thing.';
}

/// One configurable numeric parameter (spec section 23), e.g. RSI period.
class StrategyParamSpec {
  const StrategyParamSpec({
    required this.key,
    required this.label,
    required this.defaultValue,
    required this.min,
    required this.max,
    this.step = 1,
    this.isInteger = true,
  });

  final String key;
  final String label;
  final num defaultValue;
  final num min;
  final num max;
  final num step;
  final bool isInteger;
}
