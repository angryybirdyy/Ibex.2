import '../core/enums.dart';
import '../core/time_utils.dart';

/// One simulated trade produced during a backtest run. Not usually shown
/// individually in the UI, but kept so [BacktestResult] stats are always
/// reproducible/auditable from the underlying trades rather than being
/// stored as opaque pre-aggregated numbers.
class BacktestTrade {
  const BacktestTrade({
    required this.direction,
    required this.entryTime,
    required this.entryPrice,
    required this.targetPrice,
    required this.stopLossPrice,
    required this.result,
    this.exitTime,
    this.exitPrice,
  });

  final SignalDirection direction;
  final DateTime entryTime;
  final double entryPrice;
  final double targetPrice;
  final double stopLossPrice;
  final SignalResultType result;
  final DateTime? exitTime;
  final double? exitPrice;

  /// Signed return in price units (positive = profit), or null if
  /// unresolved. Used for profit factor / average win / average loss.
  double? get returnAmount {
    if (exitPrice == null) return null;
    final raw = direction == SignalDirection.buy
        ? exitPrice! - entryPrice
        : entryPrice - exitPrice!;
    return raw;
  }
}

/// Aggregate statistics for one (strategy, pair, timeframe, date-range)
/// backtest run (spec section 12/22). Every field here is computed from
/// [trades] — nothing is a hard-coded or estimated figure.
class BacktestResult {
  BacktestResult({
    required this.strategyId,
    required this.pairCode,
    required this.timeframeLabel,
    required this.startDate,
    required this.endDate,
    required this.trades,
    required this.computedAt,
  });

  final String strategyId;
  final String pairCode;
  final String timeframeLabel;
  final DateTime startDate;
  final DateTime endDate;
  final List<BacktestTrade> trades;
  final DateTime computedAt;

  int get totalTrades => trades.length;
  int get winningTrades => trades.where((t) => t.result == SignalResultType.win).length;
  int get losingTrades => trades.where((t) => t.result == SignalResultType.loss).length;
  int get unresolvedTrades =>
      trades.where((t) => t.result == SignalResultType.unresolved).length;

  int get _decidedTrades => winningTrades + losingTrades;

  /// Null (not zero) when there are no decided trades yet, so the UI can
  /// show "insufficient data" instead of a misleading 0.0%.
  double? get winRate =>
      _decidedTrades == 0 ? null : winningTrades / _decidedTrades * 100.0;

  double get grossProfit => trades
      .where((t) => t.result == SignalResultType.win)
      .fold(0.0, (sum, t) => sum + (t.returnAmount ?? 0).abs());

  double get grossLoss => trades
      .where((t) => t.result == SignalResultType.loss)
      .fold(0.0, (sum, t) => sum + (t.returnAmount ?? 0).abs());

  /// Null when there are no losing trades to divide by (undefined, not
  /// infinite — displayed as "—" rather than a fabricated large number).
  double? get profitFactor => grossLoss == 0 ? null : grossProfit / grossLoss;

  double? get averageReturnPerTrade {
    final decided = trades.where((t) => t.returnAmount != null).toList();
    if (decided.isEmpty) return null;
    final sum = decided.fold(0.0, (s, t) => s + t.returnAmount!);
    return sum / decided.length;
  }

  double? get averageWinningTrade {
    final wins = trades
        .where((t) => t.result == SignalResultType.win)
        .map((t) => t.returnAmount!.abs())
        .toList();
    if (wins.isEmpty) return null;
    return wins.reduce((a, b) => a + b) / wins.length;
  }

  double? get averageLosingTrade {
    final losses = trades
        .where((t) => t.result == SignalResultType.loss)
        .map((t) => t.returnAmount!.abs())
        .toList();
    if (losses.isEmpty) return null;
    return losses.reduce((a, b) => a + b) / losses.length;
  }

  /// Max drawdown across the *equity curve implied by trade sequence*
  /// (sum of returns in chronological order), expressed in price units.
  double get maxDrawdown {
    double equity = 0, peak = 0, maxDd = 0;
    for (final t in trades) {
      final r = t.returnAmount;
      if (r == null) continue;
      equity += r;
      if (equity > peak) peak = equity;
      final dd = peak - equity;
      if (dd > maxDd) maxDd = dd;
    }
    return maxDd;
  }

  Map<String, Object?> toMap() => {
        'run_id':
            '$strategyId|$pairCode|$timeframeLabel|${startDate.millisecondsSinceEpoch}|${endDate.millisecondsSinceEpoch}',
        'strategy_id': strategyId,
        'pair': pairCode,
        'timeframe': timeframeLabel,
        'start_date': toStorageString(startDate),
        'end_date': toStorageString(endDate),
        'total_trades': totalTrades,
        'winning_trades': winningTrades,
        'losing_trades': losingTrades,
        'unresolved_trades': unresolvedTrades,
        'win_rate': winRate,
        'profit_factor': profitFactor,
        'avg_return': averageReturnPerTrade,
        'max_drawdown': maxDrawdown,
        'avg_win': averageWinningTrade,
        'avg_loss': averageLosingTrade,
        'computed_at': toStorageString(computedAt),
      };
}
