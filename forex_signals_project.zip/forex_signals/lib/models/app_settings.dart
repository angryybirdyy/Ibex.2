import '../core/enums.dart';
import '../core/market_types.dart';

/// All user-configurable, non-secret settings (spec section 29). The API
/// key itself is never part of this model — it lives only in
/// `services/api_key_store.dart` (Android secure storage), and is never
/// logged or serialized alongside these fields.
class AppSettings {
  const AppSettings({
    this.dataMode = DataMode.demo,
    this.refreshIntervalMinutes = 5,
    this.backgroundMonitoringEnabled = false,
    this.notificationsEnabled = true,
    this.darkMode = true,
    this.defaultTimeframeLabel = '15M',
    this.backtestMonths = 12,
    this.tpSlMethod = TpSlMethod.atrMultiple,
    this.atrMultiple = 1.5,
    this.fixedPips = 30,
    this.evaluationWindowCandles = 50,
    this.hasCompletedFirstRun = false,
    List<String>? backgroundTimeframeLabels,
  }) : backgroundTimeframeLabels = backgroundTimeframeLabels ??
            Timeframe.defaultBackgroundSet.map((t) => t.label).toList();

  final DataMode dataMode;

  /// How often the background sync loop and foreground UI poll for new
  /// candles, in minutes. Bounded in Settings UI to respect provider rate
  /// limits (spec section 30).
  final int refreshIntervalMinutes;

  final bool backgroundMonitoringEnabled;
  final bool notificationsEnabled;
  final bool darkMode;
  final String defaultTimeframeLabel;

  /// How many months of history a backtest run covers by default.
  final int backtestMonths;

  final TpSlMethod tpSlMethod;

  /// Used when [tpSlMethod] is [TpSlMethod.atrMultiple]: TP/SL are placed
  /// this many multiples of ATR(14) away from entry.
  final double atrMultiple;

  /// Used when [tpSlMethod] is [TpSlMethod.fixedPips].
  final double fixedPips;

  /// How many candles a signal is allowed to remain ACTIVE before it's
  /// marked EXPIRED/UNRESOLVED (spec section 13).
  final int evaluationWindowCandles;

  final bool hasCompletedFirstRun;

  /// Which timeframes the *background* cycle syncs and evaluates for each
  /// pair, independent of what's currently shown on a chart. Defaults to a
  /// rate-limit-friendly subset (spec section 30); the user can widen this
  /// in Settings once they understand their provider's request budget.
  final List<String> backgroundTimeframeLabels;

  AppSettings copyWith({
    DataMode? dataMode,
    int? refreshIntervalMinutes,
    bool? backgroundMonitoringEnabled,
    bool? notificationsEnabled,
    bool? darkMode,
    String? defaultTimeframeLabel,
    int? backtestMonths,
    TpSlMethod? tpSlMethod,
    double? atrMultiple,
    double? fixedPips,
    int? evaluationWindowCandles,
    bool? hasCompletedFirstRun,
    List<String>? backgroundTimeframeLabels,
  }) {
    return AppSettings(
      dataMode: dataMode ?? this.dataMode,
      refreshIntervalMinutes: refreshIntervalMinutes ?? this.refreshIntervalMinutes,
      backgroundMonitoringEnabled:
          backgroundMonitoringEnabled ?? this.backgroundMonitoringEnabled,
      notificationsEnabled: notificationsEnabled ?? this.notificationsEnabled,
      darkMode: darkMode ?? this.darkMode,
      defaultTimeframeLabel: defaultTimeframeLabel ?? this.defaultTimeframeLabel,
      backtestMonths: backtestMonths ?? this.backtestMonths,
      tpSlMethod: tpSlMethod ?? this.tpSlMethod,
      atrMultiple: atrMultiple ?? this.atrMultiple,
      fixedPips: fixedPips ?? this.fixedPips,
      evaluationWindowCandles: evaluationWindowCandles ?? this.evaluationWindowCandles,
      hasCompletedFirstRun: hasCompletedFirstRun ?? this.hasCompletedFirstRun,
      backgroundTimeframeLabels: backgroundTimeframeLabels ?? this.backgroundTimeframeLabels,
    );
  }

  Map<String, Object?> toMap() => {
        'dataMode': dataMode.name,
        'refreshIntervalMinutes': refreshIntervalMinutes,
        'backgroundMonitoringEnabled': backgroundMonitoringEnabled,
        'notificationsEnabled': notificationsEnabled,
        'darkMode': darkMode,
        'defaultTimeframeLabel': defaultTimeframeLabel,
        'backtestMonths': backtestMonths,
        'tpSlMethod': tpSlMethod.name,
        'atrMultiple': atrMultiple,
        'fixedPips': fixedPips,
        'evaluationWindowCandles': evaluationWindowCandles,
        'hasCompletedFirstRun': hasCompletedFirstRun,
        'backgroundTimeframeLabels': backgroundTimeframeLabels.join(','),
      };

  static AppSettings fromMap(Map<String, Object?> map) => AppSettings(
        dataMode: DataMode.values.byName(map['dataMode'] as String? ?? 'demo'),
        refreshIntervalMinutes: map['refreshIntervalMinutes'] as int? ?? 5,
        backgroundMonitoringEnabled: map['backgroundMonitoringEnabled'] as bool? ?? false,
        notificationsEnabled: map['notificationsEnabled'] as bool? ?? true,
        darkMode: map['darkMode'] as bool? ?? true,
        defaultTimeframeLabel: map['defaultTimeframeLabel'] as String? ?? '15M',
        backtestMonths: map['backtestMonths'] as int? ?? 12,
        tpSlMethod:
            TpSlMethod.values.byName(map['tpSlMethod'] as String? ?? 'atrMultiple'),
        atrMultiple: (map['atrMultiple'] as num?)?.toDouble() ?? 1.5,
        fixedPips: (map['fixedPips'] as num?)?.toDouble() ?? 30,
        evaluationWindowCandles: map['evaluationWindowCandles'] as int? ?? 50,
        hasCompletedFirstRun: map['hasCompletedFirstRun'] as bool? ?? false,
        backgroundTimeframeLabels: (map['backgroundTimeframeLabels'] as String?)
            ?.split(',')
            .where((s) => s.isNotEmpty)
            .toList(),
      );
}
