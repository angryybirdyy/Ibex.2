import '../models/candle.dart';

/// Classic Wilder RSI. Seeded with a simple average of the first [period]
/// gains/losses, then smoothed with Wilder's `(prev*(n-1)+x)/n` recurrence
/// — this is the original 1978 formulation used by virtually every charting
/// platform, and is what produces the textbook RSI values (verified against
/// the standard 14-period example series during development).
class Rsi {
  static List<double?> compute(CandleSeries series, {int period = 14}) {
    final closes = series.closes;
    final out = List<double?>.filled(closes.length, null);
    if (closes.length <= period) return out;

    final gains = List<double>.filled(closes.length, 0);
    final losses = List<double>.filled(closes.length, 0);
    for (int i = 1; i < closes.length; i++) {
      final change = closes[i] - closes[i - 1];
      gains[i] = change > 0 ? change : 0;
      losses[i] = change < 0 ? -change : 0;
    }

    double avgGain = 0, avgLoss = 0;
    for (int i = 1; i <= period; i++) {
      avgGain += gains[i];
      avgLoss += losses[i];
    }
    avgGain /= period;
    avgLoss /= period;
    out[period] = _rsiFromAverages(avgGain, avgLoss);

    for (int i = period + 1; i < closes.length; i++) {
      avgGain = (avgGain * (period - 1) + gains[i]) / period;
      avgLoss = (avgLoss * (period - 1) + losses[i]) / period;
      out[i] = _rsiFromAverages(avgGain, avgLoss);
    }
    return out;
  }

  static double _rsiFromAverages(double avgGain, double avgLoss) {
    if (avgLoss == 0) return 100.0;
    final rs = avgGain / avgLoss;
    return 100 - (100 / (1 + rs));
  }
}
