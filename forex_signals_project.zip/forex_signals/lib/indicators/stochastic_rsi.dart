import '../models/candle.dart';
import 'indicator_utils.dart';
import 'rsi.dart';

class StochRsiResult {
  const StochRsiResult(this.percentK, this.percentD);
  final List<double?> percentK;
  final List<double?> percentD;
}

/// Stochastic RSI: the stochastic %K/%D formula applied to the *RSI series*
/// instead of price. More sensitive than plain RSI or plain Stochastic,
/// which is exactly why it's a separate strategy from both (spec lists it
/// distinctly from #4 RSI and #6 Stochastic).
class StochasticRsi {
  static StochRsiResult compute(
    CandleSeries series, {
    int rsiPeriod = 14,
    int stochPeriod = 14,
    int kSmoothing = 3,
    int dPeriod = 3,
  }) {
    final rsi = Rsi.compute(series, period: rsiPeriod);
    final firstDefined = rsi.indexWhere((v) => v != null);
    final out = List<double?>.filled(rsi.length, null);
    final outD = List<double?>.filled(rsi.length, null);
    if (firstDefined == -1) return StochRsiResult(out, outD);

    final rsiTail = rsi.sublist(firstDefined).cast<double>();
    final highestRsi = rollingHighest(rsiTail, stochPeriod);
    final lowestRsi = rollingLowest(rsiTail, stochPeriod);

    final rawK = List<double?>.filled(rsiTail.length, null);
    for (int i = 0; i < rsiTail.length; i++) {
      final hh = highestRsi[i], ll = lowestRsi[i];
      if (hh != null && ll != null) {
        final range = hh - ll;
        rawK[i] = range == 0 ? 50.0 : (rsiTail[i] - ll) / range * 100.0;
      }
    }

    final smoothedK = _smaSkippingNulls(rawK, kSmoothing);
    final dLine = _smaSkippingNulls(smoothedK, dPeriod);

    for (int i = 0; i < smoothedK.length; i++) {
      out[firstDefined + i] = smoothedK[i];
      outD[firstDefined + i] = dLine[i];
    }
    return StochRsiResult(out, outD);
  }

  static List<double?> _smaSkippingNulls(List<double?> values, int period) {
    final out = List<double?>.filled(values.length, null);
    final firstDefined = values.indexWhere((v) => v != null);
    if (firstDefined == -1) return out;
    final tail = values.sublist(firstDefined).cast<double>();
    final tailSma = smaSeries(tail, period);
    for (int i = 0; i < tailSma.length; i++) {
      out[firstDefined + i] = tailSma[i];
    }
    return out;
  }
}
