import '../models/candle.dart';
import 'indicator_utils.dart';

class StochasticResult {
  const StochasticResult(this.percentK, this.percentD);
  final List<double?> percentK;
  final List<double?> percentD;
}

/// "Slow" stochastic (the conventional default most platforms show):
/// raw %K = `(close - lowestLow(n)) / (highestHigh(n) - lowestLow(n)) * 100`,
/// then %K itself is smoothed by [kSmoothing] before %D (SMA of %K) is taken.
class Stochastic {
  static StochasticResult compute(
    CandleSeries series, {
    int period = 14,
    int kSmoothing = 3,
    int dPeriod = 3,
  }) {
    final highs = series.highs, lows = series.lows, closes = series.closes;
    final highestHigh = rollingHighest(highs, period);
    final lowestLow = rollingLowest(lows, period);

    final rawK = List<double?>.filled(closes.length, null);
    for (int i = 0; i < closes.length; i++) {
      final hh = highestHigh[i], ll = lowestLow[i];
      if (hh != null && ll != null) {
        final range = hh - ll;
        rawK[i] = range == 0 ? 50.0 : (closes[i] - ll) / range * 100.0;
      }
    }

    final smoothedK = _smaSkippingNulls(rawK, kSmoothing);
    final percentD = _smaSkippingNulls(smoothedK, dPeriod);
    return StochasticResult(smoothedK, percentD);
  }

  /// SMA over a nullable series: only produces output once [period]
  /// consecutive non-null values are available, and is otherwise identical
  /// to a plain rolling average.
  static List<double?> _smaSkippingNulls(List<double?> values, int period) {
    final out = List<double?>.filled(values.length, null);
    final firstDefined = values.indexWhere((v) => v != null);
    if (firstDefined == -1) return out;
    final tail = values.sublist(firstDefined).cast<double>();
    final tailSma = _plainSma(tail, period);
    for (int i = 0; i < tailSma.length; i++) {
      out[firstDefined + i] = tailSma[i];
    }
    return out;
  }

  static List<double?> _plainSma(List<double> values, int period) {
    final out = List<double?>.filled(values.length, null);
    if (values.length < period) return out;
    double sum = 0;
    for (int i = 0; i < values.length; i++) {
      sum += values[i];
      if (i >= period) sum -= values[i - period];
      if (i >= period - 1) out[i] = sum / period;
    }
    return out;
  }
}
