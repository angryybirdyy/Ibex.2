import '../models/candle.dart';

class PivotLevels {
  const PivotLevels({
    required this.pp,
    required this.r1,
    required this.r2,
    required this.r3,
    required this.s1,
    required this.s2,
    required this.s3,
  });
  final List<double?> pp;
  final List<double?> r1;
  final List<double?> r2;
  final List<double?> r3;
  final List<double?> s1;
  final List<double?> s2;
  final List<double?> s3;
}

/// Classic ("floor trader") daily pivot points: fixed for an entire UTC
/// calendar day, computed from the *previous completed day's* high, low and
/// close. The first day in the series has no prior day and is left null.
class PivotPoints {
  static PivotLevels compute(CandleSeries series) {
    final candles = series.candles;
    final n = candles.length;
    final pp = List<double?>.filled(n, null);
    final r1 = List<double?>.filled(n, null);
    final r2 = List<double?>.filled(n, null);
    final r3 = List<double?>.filled(n, null);
    final s1 = List<double?>.filled(n, null);
    final s2 = List<double?>.filled(n, null);
    final s3 = List<double?>.filled(n, null);
    if (candles.isEmpty) return PivotLevels(pp: pp, r1: r1, r2: r2, r3: r3, s1: s1, s2: s2, s3: s3);

    DateTime? curDay;
    double curHigh = 0, curLow = 0;
    double? prevHigh, prevLow, prevClose;

    for (int i = 0; i < n; i++) {
      final c = candles[i];
      final day = DateTime.utc(c.timestamp.year, c.timestamp.month, c.timestamp.day);

      if (curDay == null) {
        curDay = day;
        curHigh = c.high;
        curLow = c.low;
      } else if (day != curDay) {
        // Yesterday's session just closed — finalize its H/L/C using the
        // *last* candle we saw for that day (i-1's close).
        prevHigh = curHigh;
        prevLow = curLow;
        prevClose = candles[i - 1].close;
        curDay = day;
        curHigh = c.high;
        curLow = c.low;
      } else {
        if (c.high > curHigh) curHigh = c.high;
        if (c.low < curLow) curLow = c.low;
      }

      if (prevHigh != null && prevLow != null && prevClose != null) {
        final h = prevHigh, l = prevLow, cl = prevClose;
        final p = (h + l + cl) / 3;
        pp[i] = p;
        r1[i] = 2 * p - l;
        s1[i] = 2 * p - h;
        r2[i] = p + (h - l);
        s2[i] = p - (h - l);
        r3[i] = h + 2 * (p - l);
        s3[i] = l - 2 * (h - p);
      }
    }

    return PivotLevels(pp: pp, r1: r1, r2: r2, r3: r3, s1: s1, s2: s2, s3: s3);
  }
}
