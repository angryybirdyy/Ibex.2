import '../models/candle.dart';

/// Daily-session VWAP: `Σ(typicalPrice × volume) / Σ(volume)`, resetting at
/// the start of each UTC calendar day. Forex "volume" from most data
/// providers is *tick volume* (a count of price updates), not true traded
/// volume — VWAP is still meaningful as a tick-activity-weighted average
/// price, but this distinction is documented for the user in STRATEGIES.md
/// rather than glossed over.
class Vwap {
  static List<double?> compute(CandleSeries series) {
    final candles = series.candles;
    final out = List<double?>.filled(candles.length, null);
    if (candles.isEmpty) return out;

    DateTime? currentDay;
    double cumPv = 0;
    double cumVolume = 0;

    for (int i = 0; i < candles.length; i++) {
      final c = candles[i];
      final day = DateTime.utc(c.timestamp.year, c.timestamp.month, c.timestamp.day);
      if (currentDay == null || day != currentDay) {
        currentDay = day;
        cumPv = 0;
        cumVolume = 0;
      }
      final typicalPrice = (c.high + c.low + c.close) / 3;
      // Tick-volume candles occasionally report 0; treat as 1 tick so a
      // whole flat session doesn't collapse VWAP to null forever.
      final vol = c.volume > 0 ? c.volume : 1.0;
      cumPv += typicalPrice * vol;
      cumVolume += vol;
      out[i] = cumVolume == 0 ? null : cumPv / cumVolume;
    }
    return out;
  }
}
