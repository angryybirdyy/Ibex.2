import '../models/candle.dart';
import 'indicator_utils.dart';

class DonchianResult {
  const DonchianResult(this.upper, this.lower, this.middle);
  final List<double?> upper; // highest high over the period
  final List<double?> lower; // lowest low over the period
  final List<double?> middle; // midpoint, often called the "base line"
}

/// Donchian Channel: rolling highest-high / lowest-low over [period] bars.
/// A close beyond either band is a breakout of the recent trading range.
class Donchian {
  static DonchianResult compute(CandleSeries series, {int period = 20}) {
    final upper = rollingHighest(series.highs, period);
    final lower = rollingLowest(series.lows, period);
    final middle = List<double?>.filled(upper.length, null);
    for (int i = 0; i < upper.length; i++) {
      final u = upper[i], l = lower[i];
      if (u != null && l != null) middle[i] = (u + l) / 2;
    }
    return DonchianResult(upper, lower, middle);
  }
}
