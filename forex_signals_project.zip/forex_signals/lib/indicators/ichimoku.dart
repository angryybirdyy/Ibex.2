import '../models/candle.dart';
import 'indicator_utils.dart';

class IchimokuResult {
  const IchimokuResult({
    required this.tenkan,
    required this.kijun,
    required this.chikou,
    required this.senkouARaw,
    required this.senkouBRaw,
    required this.cloudTop,
    required this.cloudBottom,
  });

  /// Conversion line: midpoint of the 9-period high/low.
  final List<double?> tenkan;

  /// Base line: midpoint of the 26-period high/low.
  final List<double?> kijun;

  /// Lagging span: simply `close[i]`, conventionally *plotted* 26 bars
  /// back on a chart — exposed unshifted here; the chart widget applies the
  /// visual shift when drawing.
  final List<double?> chikou;

  /// Senkou Span A/B *as computed at index i*, i.e. before the standard
  /// 26-bar-forward plotting shift. Useful for drawing the projected cloud
  /// edge ahead of the last candle.
  final List<double?> senkouARaw;
  final List<double?> senkouBRaw;

  /// The cloud edges *applicable to candle i on a real chart* — i.e.
  /// already shifted forward, so `cloudTop[i]`/`cloudBottom[i]` is what a
  /// trader actually compares candle i's price against. This is what
  /// strategy logic should use, not [senkouARaw]/[senkouBRaw] directly.
  final List<double?> cloudTop;
  final List<double?> cloudBottom;
}

class Ichimoku {
  static IchimokuResult compute(
    CandleSeries series, {
    int tenkanPeriod = 9,
    int kijunPeriod = 26,
    int senkouBPeriod = 52,
    int displacement = 26,
  }) {
    final highs = series.highs, lows = series.lows, closes = series.closes;
    final n = closes.length;

    final tenkanHigh = rollingHighest(highs, tenkanPeriod);
    final tenkanLow = rollingLowest(lows, tenkanPeriod);
    final tenkan = List<double?>.filled(n, null);
    for (int i = 0; i < n; i++) {
      final h = tenkanHigh[i], l = tenkanLow[i];
      if (h != null && l != null) tenkan[i] = (h + l) / 2;
    }

    final kijunHigh = rollingHighest(highs, kijunPeriod);
    final kijunLow = rollingLowest(lows, kijunPeriod);
    final kijun = List<double?>.filled(n, null);
    for (int i = 0; i < n; i++) {
      final h = kijunHigh[i], l = kijunLow[i];
      if (h != null && l != null) kijun[i] = (h + l) / 2;
    }

    final senkouBHigh = rollingHighest(highs, senkouBPeriod);
    final senkouBLow = rollingLowest(lows, senkouBPeriod);
    final senkouBRaw = List<double?>.filled(n, null);
    for (int i = 0; i < n; i++) {
      final h = senkouBHigh[i], l = senkouBLow[i];
      if (h != null && l != null) senkouBRaw[i] = (h + l) / 2;
    }

    final senkouARaw = List<double?>.filled(n, null);
    for (int i = 0; i < n; i++) {
      final t = tenkan[i], k = kijun[i];
      if (t != null && k != null) senkouARaw[i] = (t + k) / 2;
    }

    final chikou = List<double?>.filled(n, null);
    for (int i = 0; i < n; i++) {
      chikou[i] = closes[i];
    }

    // Shift Senkou A/B forward by [displacement] so cloudTop/Bottom[i]
    // reflects what a real chart shows *at* candle i.
    final cloudTop = List<double?>.filled(n, null);
    final cloudBottom = List<double?>.filled(n, null);
    for (int i = displacement; i < n; i++) {
      final a = senkouARaw[i - displacement];
      final b = senkouBRaw[i - displacement];
      if (a != null && b != null) {
        cloudTop[i] = a > b ? a : b;
        cloudBottom[i] = a > b ? b : a;
      }
    }

    return IchimokuResult(
      tenkan: tenkan,
      kijun: kijun,
      chikou: chikou,
      senkouARaw: senkouARaw,
      senkouBRaw: senkouBRaw,
      cloudTop: cloudTop,
      cloudBottom: cloudBottom,
    );
  }
}
