import '../models/candle.dart';
import 'indicator_utils.dart';

class AdxResult {
  const AdxResult(this.plusDi, this.minusDi, this.adx);
  final List<double?> plusDi;
  final List<double?> minusDi;
  final List<double?> adx;
}

/// Wilder's Average Directional Index with +DI/-DI, computed the original
/// 1978 way:
///  1. +DM/-DM per bar from directional price movement (only the larger,
///     positive side counts; a tie or a down bar with bigger range zeroes
///     both).
///  2. True Range, +DM and -DM are each Wilder-smoothed over [period].
///  3. +DI = 100 * smoothed(+DM) / smoothed(TR), -DI likewise.
///  4. DX = 100 * |+DI - -DI| / (+DI + -DI).
///  5. ADX = Wilder-smoothed average of DX over [period].
class Adx {
  static AdxResult compute(CandleSeries series, {int period = 14}) {
    final highs = series.highs, lows = series.lows, closes = series.closes;
    final n = highs.length;
    final tr = trueRangeSeries(highs, lows, closes);
    final plusDmRaw = List<double?>.filled(n, null);
    final minusDmRaw = List<double?>.filled(n, null);

    for (int i = 1; i < n; i++) {
      final upMove = highs[i] - highs[i - 1];
      final downMove = lows[i - 1] - lows[i];
      final plusDm = (upMove > downMove && upMove > 0) ? upMove : 0.0;
      final minusDm = (downMove > upMove && downMove > 0) ? downMove : 0.0;
      plusDmRaw[i] = plusDm;
      minusDmRaw[i] = minusDm;
    }

    final smoothedTr = wilderSmoothNullable(tr, period);
    final smoothedPlusDm = wilderSmoothNullable(plusDmRaw, period);
    final smoothedMinusDm = wilderSmoothNullable(minusDmRaw, period);

    final plusDi = List<double?>.filled(n, null);
    final minusDi = List<double?>.filled(n, null);
    final dx = List<double?>.filled(n, null);

    for (int i = 0; i < n; i++) {
      final trV = smoothedTr[i];
      final pDm = smoothedPlusDm[i];
      final mDm = smoothedMinusDm[i];
      if (trV != null && trV != 0 && pDm != null && mDm != null) {
        final pDi = 100 * pDm / trV;
        final mDi = 100 * mDm / trV;
        plusDi[i] = pDi;
        minusDi[i] = mDi;
        final sum = pDi + mDi;
        dx[i] = sum == 0 ? 0.0 : 100 * (pDi - mDi).abs() / sum;
      }
    }

    final adx = wilderSmoothNullable(dx, period);
    return AdxResult(plusDi, minusDi, adx);
  }
}
