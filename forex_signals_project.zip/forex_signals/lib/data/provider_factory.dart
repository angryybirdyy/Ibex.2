import '../core/enums.dart';
import '../services/api_key_store.dart';
import 'demo_data_provider.dart';
import 'forex_data_provider.dart';
import 'twelve_data_provider.dart';

/// Builds the active [ForexDataProvider] for the given [DataMode] (spec
/// section 48). This is the single switch point — adding a third provider
/// means adding one more case here, and giving it an entry in the Settings
/// screen's data-source picker.
class ProviderFactory {
  ProviderFactory._();

  static final DemoDataProvider _demo = DemoDataProvider();
  static TwelveDataProvider? _twelveData;

  static ForexDataProvider create(DataMode mode) {
    switch (mode) {
      case DataMode.demo:
        return _demo;
      case DataMode.live:
        return _twelveData ??= TwelveDataProvider(
          apiKeyGetter: ApiKeyStore.instance.getApiKey,
        );
    }
  }
}
