import 'dart:math' as math;

import '../core/failures.dart';
import '../core/id_utils.dart';
import '../core/market_types.dart';
import '../models/candle.dart';
import 'forex_data_provider.dart';

/// Generates clearly-labelled DEMO candles so the whole app (charts,
/// strategies, backtesting, signals, notifications) can be built and tested
/// without a live API key (spec section 41). Every [Candle] this produces
/// has `isDemo = true`.
///
/// Design: rather than a step-by-step random walk (which would need to
/// replay potentially millions of steps from some epoch to answer a query
/// for a recent window), price is a deterministic function of wall-clock
/// time: a couple of slow sine cycles (so trends and swings exist for
/// strategies to react to) plus a hash-seeded per-candle noise term. This
/// makes every query for the same timestamp reproducible — important so a
/// "backtest" on demo data is a real, repeatable computation over a fixed
/// synthetic series, not a different fake number every time — and O(1) per
/// candle instead of O(history length).
class DemoDataProvider implements ForexDataProvider {
  static final DateTime _epoch = DateTime.utc(2024, 1, 1);

  @override
  String get name => 'Demo (synthetic data)';

  @override
  bool get requiresApiKey => false;

  double _basePrice(CurrencyPair pair) => switch (pair) {
        CurrencyPair.usdJpy => 148.500,
        CurrencyPair.eurUsd => 1.0850,
      };

  /// Amplitude of the long/short sine cycles, scaled per pair so JPY's
  /// larger absolute pip values don't look flat next to EUR/USD's.
  (double, double, double) _amplitudes(CurrencyPair pair) => switch (pair) {
        CurrencyPair.usdJpy => (2.4, 0.6, 0.035),
        CurrencyPair.eurUsd => (0.018, 0.005, 0.00035),
      };

  /// Maps an arbitrary string to a pseudo-random double in `[0, 1)` using
  /// the existing FNV-1a hash — reproducible, no stored RNG state needed.
  double _hashUnit(String key) {
    final h = int.parse(fnv1a(key), radix: 16);
    return h / 0xFFFFFFFF;
  }

  double _priceAt(CurrencyPair pair, DateTime utc) {
    final minutes = utc.difference(_epoch).inMinutes.toDouble();
    final base = _basePrice(pair);
    final (ampLong, ampShort, _) = _amplitudes(pair);
    // A multi-day cycle and a several-hour cycle, out of phase per pair so
    // USD/JPY and EUR/USD don't move in obvious lockstep.
    final longCycle = ampLong * math.sin(2 * math.pi * minutes / (60 * 24 * 5));
    final shortCycle = ampShort * math.sin(2 * math.pi * minutes / (60 * 7) + pair.index);
    return base + longCycle + shortCycle;
  }

  Candle _buildCandle(CurrencyPair pair, DateTime start, int intervalMinutes) {
    final end = start.add(Duration(minutes: intervalMinutes));
    final open = _priceAt(pair, start);
    final close = _priceAt(pair, end);
    final (_, __, noiseAmp) = _amplitudes(pair);
    final key = '${pair.code}|$intervalMinutes|${start.toIso8601String()}';
    final wickNoise = _hashUnit('$key|wick') * noiseAmp;
    final volumeNoise = _hashUnit('$key|vol');
    final high = math.max(open, close) + wickNoise;
    final low = math.min(open, close) - _hashUnit('$key|wick2') * noiseAmp;
    return Candle(
      timestamp: start,
      open: open,
      high: high,
      low: low,
      close: close,
      volume: 50 + volumeNoise * 450,
      isDemo: true,
    );
  }

  @override
  Future<Result<double>> getCurrentPrice(CurrencyPair pair) async {
    final now = DateTime.now().toUtc();
    return Result.ok(_priceAt(pair, now));
  }

  @override
  Future<Result<List<Candle>>> getCandles(
    CurrencyPair pair,
    Timeframe timeframe, {
    required int outputSize,
  }) async {
    final now = DateTime.now().toUtc();
    final candles = <Candle>[];
    // Walk backward from the current candle bucket for `outputSize` bars.
    var bucketStart = DateTime.utc(now.year, now.month, now.day, now.hour, now.minute)
        .subtract(Duration(
      minutes: now.minute % timeframe.minutes,
      seconds: now.second,
    ));
    for (int i = 0; i < outputSize; i++) {
      candles.add(_buildCandle(pair, bucketStart, timeframe.minutes));
      bucketStart = bucketStart.subtract(Duration(minutes: timeframe.minutes));
    }
    return Result.ok(candles.reversed.toList());
  }
}
