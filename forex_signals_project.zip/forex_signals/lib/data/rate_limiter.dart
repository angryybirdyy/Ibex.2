/// A simple token-bucket limiter (spec section 30: "the system must not
/// make an uncontrolled API request every second"). Tokens refill
/// continuously at `capacity / refillWindow`, so a burst can use up to
/// [capacity] credits immediately and then throttles to the steady-state
/// rate — matching how most market-data APIs (including Twelve Data)
/// describe their "N credits per minute" limits.
class RateLimiter {
  RateLimiter({required this.capacity, required this.refillWindow})
      : _tokens = capacity.toDouble(),
        _lastRefill = DateTime.now();

  final int capacity;
  final Duration refillWindow;

  double _tokens;
  DateTime _lastRefill;

  void _refill() {
    final now = DateTime.now();
    final elapsed = now.difference(_lastRefill);
    if (elapsed <= Duration.zero) return;
    final refillRate = capacity / refillWindow.inMilliseconds; // tokens per ms
    _tokens = (_tokens + elapsed.inMilliseconds * refillRate).clamp(0, capacity.toDouble());
    _lastRefill = now;
  }

  /// Attempts to consume [cost] tokens immediately. Returns `false` (and
  /// consumes nothing) if not enough tokens are available right now —
  /// callers should back off rather than block indefinitely on a background
  /// cycle.
  bool tryConsume(int cost) {
    _refill();
    if (_tokens >= cost) {
      _tokens -= cost;
      return true;
    }
    return false;
  }

  /// How long the caller should wait before [cost] tokens will be
  /// available, assuming no other consumption happens meanwhile. Used to
  /// give a concrete "try again in Xs" figure rather than a vague failure.
  Duration timeUntilAvailable(int cost) {
    _refill();
    if (_tokens >= cost) return Duration.zero;
    final deficit = cost - _tokens;
    final refillRate = capacity / refillWindow.inMilliseconds;
    final msNeeded = (deficit / refillRate).ceil();
    return Duration(milliseconds: msNeeded);
  }
}
