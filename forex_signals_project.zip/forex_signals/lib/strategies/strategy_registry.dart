import 'adx_di_strategy.dart';
import 'atr_breakout_strategy.dart';
import 'bollinger_band_squeeze_strategy.dart';
import 'bollinger_bands_strategy.dart';
import 'donchian_breakout_strategy.dart';
import 'ema_crossover_strategy.dart';
import 'ema_macd_trend_confirmation_strategy.dart';
import 'ema_rsi_confirmation_strategy.dart';
import 'ichimoku_cloud_strategy.dart';
import 'ma_adx_trend_strategy.dart';
import 'macd_rsi_confirmation_strategy.dart';
import 'macd_strategy.dart';
import 'mean_reversion_strategy.dart';
import 'momentum_breakout_strategy.dart';
import 'parabolic_sar_strategy.dart';
import 'pivot_point_strategy.dart';
import 'rsi_divergence_strategy.dart';
import 'rsi_overbought_oversold_strategy.dart';
import 'sma_crossover_strategy.dart';
import 'stochastic_rsi_strategy.dart';
import 'stochastic_strategy.dart';
import 'strategy.dart';
import 'supertrend_strategy.dart';
import 'support_resistance_breakout_strategy.dart';
import 'vwap_strategy.dart';

/// Single source of truth for "which 24 strategies exist and in what
/// order". Every screen that lists strategies (Strategies tab, chart
/// overlay picker, Signal Engine's evaluation loop) reads from
/// [StrategyRegistry.all] rather than hard-coding a list — adding strategy
/// #25 means adding one entry here and nowhere else needs to change.
class StrategyRegistry {
  StrategyRegistry._();

  /// Order matches the spec's numbered list (1–24) so the Strategies screen
  /// reads the same way the requirements did.
  static final List<Strategy> all = [
    SmaCrossoverStrategy(),
    EmaCrossoverStrategy(),
    MacdStrategy(),
    RsiOverboughtOversoldStrategy(),
    RsiDivergenceStrategy(),
    StochasticStrategy(),
    StochasticRsiStrategy(),
    BollingerBandsStrategy(),
    BollingerBandSqueezeStrategy(),
    AtrBreakoutStrategy(),
    DonchianBreakoutStrategy(),
    IchimokuCloudStrategy(),
    AdxDiStrategy(),
    ParabolicSarStrategy(),
    SupertrendStrategy(),
    VwapStrategy(),
    EmaRsiConfirmationStrategy(),
    MacdRsiConfirmationStrategy(),
    EmaMacdTrendConfirmationStrategy(),
    SupportResistanceBreakoutStrategy(),
    PivotPointStrategy(),
    MaAdxTrendStrategy(),
    MeanReversionStrategy(),
    MomentumBreakoutStrategy(),
  ];

  static final Map<String, Strategy> _byId = {for (final s in all) s.id: s};

  static Strategy byId(String id) {
    final s = _byId[id];
    if (s == null) throw ArgumentError('Unknown strategy id: $id');
    return s;
  }

  static bool exists(String id) => _byId.containsKey(id);
}
