import '../core/enums.dart';
import '../indicators/indicator_engine.dart';
import '../indicators/pivot_points.dart';
import '../models/candle.dart';
import '../models/strategy_meta.dart';
import '../models/strategy_result.dart';
import 'strategy.dart';

/// #21 — Pivot Point Strategy. A classic floor-trader directional bias:
/// trading above the daily pivot is bullish, below is bearish.
class PivotPointStrategy extends Strategy {
  @override
  String get id => 'pivot_point';

  @override
  int get minCandles => 30;

  @override
  List<StrategyParamSpec> get paramSpecs => const [];

  @override
  StrategyMeta get meta => StrategyMeta(
        id: id,
        name: 'Pivot Point Strategy',
        shortExplanation:
            'Uses the classic daily floor-trader pivot as a bullish/bearish dividing line.',
        indicatorsUsed: const ['Classic daily Pivot Point (PP, R1-3, S1-3)'],
        calculationLogic:
            'PP = (previous day\'s high + low + close) ÷ 3, fixed for the whole UTC day. '
            'Price trading above PP is read as a bullish bias for the day, below as bearish.',
        buyConditions: 'Close crosses above the daily Pivot Point.',
        sellConditions: 'Close crosses below the daily Pivot Point.',
        neutralConditions: 'No cross of the pivot on this candle.',
        suitableMarketConditions: 'Intraday trading around well-defined daily levels.',
        typicalWeaknesses:
            'The pivot is fixed for the whole day, so it can be a stale reference late in a '
            'session after conditions have changed.',
        usualTimeframes: '15M, 1H',
      );

  @override
  StrategyResult evaluate(CandleSeries series, Map<String, num> params) {
    final base = IndicatorEngine.seriesKey(series, 'any', 'any');
    final pivots = IndicatorEngine.memoize('$base|pivots', () => PivotPoints.compute(series));

    final i = series.length - 1;
    final last = series.last;
    var direction = StrategyDirection.neutral;
    var reason = 'No pivot-point cross on this candle.';

    if (i > 0 && pivots.pp[i - 1] != null && pivots.pp[i] != null) {
      final close0 = series[i - 1].close, close1 = last.close;
      if (close0 <= pivots.pp[i - 1]! && close1 > pivots.pp[i]!) {
        direction = StrategyDirection.buy;
        reason = 'Price crossed above the daily Pivot Point.';
      } else if (close0 >= pivots.pp[i - 1]! && close1 < pivots.pp[i]!) {
        direction = StrategyDirection.sell;
        reason = 'Price crossed below the daily Pivot Point.';
      }
    }

    return StrategyResult(
      strategyId: id,
      direction: direction,
      timestamp: last.timestamp,
      entryPriceRef: last.close,
      indicatorValues: {
        if (pivots.pp[i] != null) 'pp': pivots.pp[i]!,
        if (pivots.r1[i] != null) 'r1': pivots.r1[i]!,
        if (pivots.s1[i] != null) 's1': pivots.s1[i]!,
      },
      explanation: reason,
    );
  }
}
