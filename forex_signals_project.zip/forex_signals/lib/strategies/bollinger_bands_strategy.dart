import '../core/enums.dart';
import '../indicators/bollinger_bands.dart';
import '../indicators/indicator_engine.dart';
import '../models/candle.dart';
import '../models/strategy_meta.dart';
import '../models/strategy_result.dart';
import 'strategy.dart';

/// #8 — Bollinger Bands. Mean-reversion signal on the *re-entry* cross
/// (price closing back inside the bands after being outside), which is a
/// single discrete event rather than "still outside the band" repeating
/// every candle.
class BollingerBandsStrategy extends Strategy {
  @override
  String get id => 'bollinger_bands';

  @override
  int get minCandles => 40;

  @override
  List<StrategyParamSpec> get paramSpecs => const [
        StrategyParamSpec(key: 'period', label: 'Period', defaultValue: 20, min: 10, max: 50),
        StrategyParamSpec(
            key: 'std_dev', label: 'Std deviations', defaultValue: 2, min: 1, max: 4, step: 0.1, isInteger: false),
      ];

  @override
  StrategyMeta get meta => StrategyMeta(
        id: id,
        name: 'Bollinger Bands',
        shortExplanation:
            'Flags when price stretches outside its normal volatility band and then snaps back.',
        indicatorsUsed: const ['Bollinger Bands (SMA ± std dev)'],
        calculationLogic:
            'A middle SMA plus upper/lower bands offset by a configurable number of standard '
            'deviations. Signals fire when price closes back inside the bands after closing '
            'outside them on the prior candle.',
        buyConditions: 'Close crosses back above the lower band after closing below it.',
        sellConditions: 'Close crosses back below the upper band after closing above it.',
        neutralConditions: 'Price stays inside the bands, or remains outside without re-entering.',
        suitableMarketConditions: 'Range-bound markets with mean-reverting price action.',
        typicalWeaknesses:
            'In a strong trend, price can "walk the band" for a long time — treating every '
            'touch as a reversal opportunity fights the trend.',
        usualTimeframes: '15M, 1H, 4H',
      );

  @override
  StrategyResult evaluate(CandleSeries series, Map<String, num> params) {
    final period = params['period']!.toInt();
    final stdDev = params['std_dev']!.toDouble();
    final base = IndicatorEngine.seriesKey(series, 'any', 'any');
    final bb = IndicatorEngine.memoize(
      '$base|bb|$period|$stdDev',
      () => BollingerBands.compute(series, period: period, stdDevMultiple: stdDev),
    );

    final i = series.length - 1;
    final last = series.last;
    var direction = StrategyDirection.neutral;
    var reason = 'Price is inside the bands with no re-entry event.';

    if (i > 0) {
      final upper0 = bb.upper[i - 1], upper1 = bb.upper[i];
      final lower0 = bb.lower[i - 1], lower1 = bb.lower[i];
      final close0 = series[i - 1].close, close1 = last.close;
      if (lower0 != null && lower1 != null && close0 < lower0 && close1 >= lower1) {
        direction = StrategyDirection.buy;
        reason = 'Price closed back above the lower Bollinger Band after closing below it.';
      } else if (upper0 != null && upper1 != null && close0 > upper0 && close1 <= upper1) {
        direction = StrategyDirection.sell;
        reason = 'Price closed back below the upper Bollinger Band after closing above it.';
      }
    }

    return StrategyResult(
      strategyId: id,
      direction: direction,
      timestamp: last.timestamp,
      entryPriceRef: last.close,
      indicatorValues: {
        if (bb.middle[i] != null) 'bb_mid': bb.middle[i]!,
        if (bb.upper[i] != null) 'bb_upper': bb.upper[i]!,
        if (bb.lower[i] != null) 'bb_lower': bb.lower[i]!,
      },
      explanation: reason,
    );
  }
}
