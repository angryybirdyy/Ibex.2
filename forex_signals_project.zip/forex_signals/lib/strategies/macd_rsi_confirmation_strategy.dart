import '../core/enums.dart';
import '../indicators/indicator_engine.dart';
import '../indicators/indicator_utils.dart';
import '../indicators/macd.dart';
import '../indicators/rsi.dart';
import '../models/candle.dart';
import '../models/strategy_meta.dart';
import '../models/strategy_result.dart';
import 'strategy.dart';

/// #18 — MACD + RSI Confirmation. Same idea as #17 but built on MACD's
/// signal-line cross instead of an EMA cross.
class MacdRsiConfirmationStrategy extends Strategy {
  @override
  String get id => 'macd_rsi_confirmation';

  @override
  int get minCandles => 100;

  @override
  List<StrategyParamSpec> get paramSpecs => const [
        StrategyParamSpec(key: 'fast', label: 'Fast EMA', defaultValue: 12, min: 3, max: 50),
        StrategyParamSpec(key: 'slow', label: 'Slow EMA', defaultValue: 26, min: 10, max: 100),
        StrategyParamSpec(key: 'signal', label: 'Signal EMA', defaultValue: 9, min: 3, max: 50),
        StrategyParamSpec(key: 'rsi_period', label: 'RSI period', defaultValue: 14, min: 5, max: 40),
        StrategyParamSpec(
            key: 'rsi_confirm', label: 'RSI confirmation level', defaultValue: 50, min: 40, max: 60),
      ];

  @override
  StrategyMeta get meta => StrategyMeta(
        id: id,
        name: 'MACD + RSI Confirmation',
        shortExplanation:
            'Only takes a MACD signal-line cross when RSI agrees with the new direction.',
        indicatorsUsed: const ['MACD line', 'MACD signal line', 'RSI'],
        calculationLogic:
            'A MACD line/signal-line crossover must be accompanied by RSI being on the '
            'correct side of the confirmation level (default 50) on the same candle.',
        buyConditions:
            'MACD line crosses above its signal line and RSI is above the confirmation level.',
        sellConditions:
            'MACD line crosses below its signal line and RSI is below the confirmation level.',
        neutralConditions: 'MACD crosses without RSI agreeing, or no crossover at all.',
        suitableMarketConditions: 'Trending markets where momentum and relative strength agree.',
        typicalWeaknesses:
            'Both MACD and RSI are derived from price via EMAs, so they can agree on a false '
            'signal during a fakeout together.',
        usualTimeframes: '1H, 4H, 1D',
      );

  @override
  StrategyResult evaluate(CandleSeries series, Map<String, num> params) {
    final fastP = params['fast']!.toInt();
    final slowP = params['slow']!.toInt();
    final signalP = params['signal']!.toInt();
    final rsiPeriod = params['rsi_period']!.toInt();
    final rsiConfirm = params['rsi_confirm']!.toDouble();
    final base = IndicatorEngine.seriesKey(series, 'any', 'any');
    final macd = IndicatorEngine.memoize(
      '$base|macd|$fastP|$slowP|$signalP',
      () => Macd.compute(series, fast: fastP, slow: slowP, signalPeriod: signalP),
    );
    final rsi = IndicatorEngine.memoize('$base|rsi|$rsiPeriod', () => Rsi.compute(series, period: rsiPeriod));

    final i = series.length - 1;
    final last = series.last;
    var direction = StrategyDirection.neutral;
    var reason = 'No MACD crossover with RSI confirmation on this candle.';

    final rsiNow = rsi[i];
    if (rsiNow != null) {
      if (crossedAbove(macd.macdLine, macd.signalLine, i) && rsiNow > rsiConfirm) {
        direction = StrategyDirection.buy;
        reason = 'MACD crossed above its signal line and RSI is above $rsiConfirm.';
      } else if (crossedBelow(macd.macdLine, macd.signalLine, i) && rsiNow < rsiConfirm) {
        direction = StrategyDirection.sell;
        reason = 'MACD crossed below its signal line and RSI is below $rsiConfirm.';
      }
    }

    return StrategyResult(
      strategyId: id,
      direction: direction,
      timestamp: last.timestamp,
      entryPriceRef: last.close,
      indicatorValues: {
        if (macd.macdLine[i] != null) 'macd': macd.macdLine[i]!,
        if (macd.signalLine[i] != null) 'macd_signal': macd.signalLine[i]!,
        if (rsi[i] != null) 'rsi': rsi[i]!,
      },
      explanation: reason,
    );
  }
}
