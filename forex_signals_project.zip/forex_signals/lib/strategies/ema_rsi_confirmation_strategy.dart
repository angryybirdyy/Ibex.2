import '../core/enums.dart';
import '../indicators/indicator_engine.dart';
import '../indicators/indicator_utils.dart';
import '../indicators/moving_averages.dart';
import '../indicators/rsi.dart';
import '../models/candle.dart';
import '../models/strategy_meta.dart';
import '../models/strategy_result.dart';
import 'strategy.dart';

/// #17 — EMA + RSI Confirmation. Requires two independent signals to agree
/// before firing, trading fewer, higher-conviction signals for reduced
/// frequency.
class EmaRsiConfirmationStrategy extends Strategy {
  @override
  String get id => 'ema_rsi_confirmation';

  @override
  int get minCandles => 60;

  @override
  List<StrategyParamSpec> get paramSpecs => const [
        StrategyParamSpec(key: 'fast', label: 'Fast EMA', defaultValue: 9, min: 3, max: 50),
        StrategyParamSpec(key: 'slow', label: 'Slow EMA', defaultValue: 21, min: 10, max: 100),
        StrategyParamSpec(key: 'rsi_period', label: 'RSI period', defaultValue: 14, min: 5, max: 40),
        StrategyParamSpec(
            key: 'rsi_confirm', label: 'RSI confirmation level', defaultValue: 50, min: 40, max: 60),
      ];

  @override
  StrategyMeta get meta => StrategyMeta(
        id: id,
        name: 'EMA + RSI Confirmation',
        shortExplanation:
            'Only takes an EMA crossover when RSI agrees with the new direction, cutting '
            'down on false crossovers.',
        indicatorsUsed: const ['EMA (fast)', 'EMA (slow)', 'RSI'],
        calculationLogic:
            'An EMA crossover must be accompanied by RSI being on the correct side of the '
            'confirmation level (default 50) on the same candle.',
        buyConditions:
            'Fast EMA crosses above slow EMA and RSI is above the configured confirmation '
            'threshold.',
        sellConditions:
            'Fast EMA crosses below slow EMA and RSI is below the configured confirmation '
            'threshold.',
        neutralConditions: 'EMA crosses without RSI agreeing, or no crossover at all.',
        suitableMarketConditions: 'Trending markets; the RSI filter reduces low-quality '
            'crossovers during chop.',
        typicalWeaknesses:
            'Fewer signals than a plain EMA crossover, and both conditions can still align '
            'briefly right before a trend fails.',
        usualTimeframes: '1H, 4H',
      );

  @override
  StrategyResult evaluate(CandleSeries series, Map<String, num> params) {
    final fastP = params['fast']!.toInt();
    final slowP = params['slow']!.toInt();
    final rsiPeriod = params['rsi_period']!.toInt();
    final rsiConfirm = params['rsi_confirm']!.toDouble();
    final base = IndicatorEngine.seriesKey(series, 'any', 'any');
    final fast = IndicatorEngine.memoize('$base|ema|$fastP', () => Ema.compute(series, period: fastP));
    final slow = IndicatorEngine.memoize('$base|ema|$slowP', () => Ema.compute(series, period: slowP));
    final rsi = IndicatorEngine.memoize('$base|rsi|$rsiPeriod', () => Rsi.compute(series, period: rsiPeriod));

    final i = series.length - 1;
    final last = series.last;
    var direction = StrategyDirection.neutral;
    var reason = 'No EMA crossover with RSI confirmation on this candle.';

    final rsiNow = rsi[i];
    if (rsiNow != null) {
      if (crossedAbove(fast, slow, i) && rsiNow > rsiConfirm) {
        direction = StrategyDirection.buy;
        reason = 'Fast EMA crossed above slow EMA and RSI moved above the configured '
            'confirmation threshold ($rsiConfirm).';
      } else if (crossedBelow(fast, slow, i) && rsiNow < rsiConfirm) {
        direction = StrategyDirection.sell;
        reason = 'Fast EMA crossed below slow EMA and RSI moved below the configured '
            'confirmation threshold ($rsiConfirm).';
      }
    }

    return StrategyResult(
      strategyId: id,
      direction: direction,
      timestamp: last.timestamp,
      entryPriceRef: last.close,
      indicatorValues: {
        if (fast[i] != null) 'ema_fast': fast[i]!,
        if (slow[i] != null) 'ema_slow': slow[i]!,
        if (rsi[i] != null) 'rsi': rsi[i]!,
      },
      explanation: reason,
    );
  }
}
