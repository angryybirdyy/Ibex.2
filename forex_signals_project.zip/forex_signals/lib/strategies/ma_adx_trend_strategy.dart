import '../core/enums.dart';
import '../indicators/adx.dart';
import '../indicators/indicator_engine.dart';
import '../indicators/indicator_utils.dart';
import '../indicators/moving_averages.dart';
import '../models/candle.dart';
import '../models/strategy_meta.dart';
import '../models/strategy_result.dart';
import 'strategy.dart';

/// #22 — Moving Average + ADX Trend Strategy. Distinct from #13 (ADX+DI):
/// here the *direction* comes from an EMA crossover and ADX is purely a
/// trend-strength gate, rather than ADX's own DI lines providing direction.
class MaAdxTrendStrategy extends Strategy {
  @override
  String get id => 'ma_adx_trend';

  @override
  int get minCandles => 80;

  @override
  List<StrategyParamSpec> get paramSpecs => const [
        StrategyParamSpec(key: 'fast', label: 'Fast EMA', defaultValue: 20, min: 5, max: 60),
        StrategyParamSpec(key: 'slow', label: 'Slow EMA', defaultValue: 50, min: 20, max: 200),
        StrategyParamSpec(key: 'adx_period', label: 'ADX period', defaultValue: 14, min: 5, max: 40),
        StrategyParamSpec(
            key: 'adx_threshold', label: 'Min ADX (trend strength)', defaultValue: 25, min: 10, max: 40),
      ];

  @override
  StrategyMeta get meta => StrategyMeta(
        id: id,
        name: 'Moving Average + ADX Trend Strategy',
        shortExplanation:
            'An EMA crossover for direction, gated by ADX to require a genuinely strong trend.',
        indicatorsUsed: const ['EMA (fast)', 'EMA (slow)', 'ADX'],
        calculationLogic:
            'An EMA crossover only counts as a signal when ADX is above the configured '
            'threshold at the same time, confirming real trend strength rather than noise.',
        buyConditions: 'Fast EMA crosses above slow EMA while ADX is above the threshold.',
        sellConditions: 'Fast EMA crosses below slow EMA while ADX is above the threshold.',
        neutralConditions: 'An EMA cross happens but ADX is below the threshold.',
        suitableMarketConditions: 'Strongly trending markets; filters out low-conviction crosses.',
        typicalWeaknesses:
            'The stricter ADX filter means fewer signals overall and some real trend starts '
            'may be missed while ADX is still climbing.',
        usualTimeframes: '4H, 1D',
      );

  @override
  StrategyResult evaluate(CandleSeries series, Map<String, num> params) {
    final fastP = params['fast']!.toInt();
    final slowP = params['slow']!.toInt();
    final adxPeriod = params['adx_period']!.toInt();
    final threshold = params['adx_threshold']!.toDouble();
    final base = IndicatorEngine.seriesKey(series, 'any', 'any');
    final fast = IndicatorEngine.memoize('$base|ema|$fastP', () => Ema.compute(series, period: fastP));
    final slow = IndicatorEngine.memoize('$base|ema|$slowP', () => Ema.compute(series, period: slowP));
    final adx = IndicatorEngine.memoize('$base|adx|$adxPeriod', () => Adx.compute(series, period: adxPeriod));

    final i = series.length - 1;
    final last = series.last;
    var direction = StrategyDirection.neutral;
    var reason = 'No qualifying EMA cross with sufficient ADX trend strength.';

    final adxNow = adx.adx[i];
    if (adxNow != null && adxNow >= threshold) {
      if (crossedAbove(fast, slow, i)) {
        direction = StrategyDirection.buy;
        reason = 'Fast EMA crossed above slow EMA with ADX at ${adxNow.toStringAsFixed(1)} '
            '(≥ $threshold).';
      } else if (crossedBelow(fast, slow, i)) {
        direction = StrategyDirection.sell;
        reason = 'Fast EMA crossed below slow EMA with ADX at ${adxNow.toStringAsFixed(1)} '
            '(≥ $threshold).';
      }
    }

    return StrategyResult(
      strategyId: id,
      direction: direction,
      timestamp: last.timestamp,
      entryPriceRef: last.close,
      indicatorValues: {
        if (fast[i] != null) 'ema_fast': fast[i]!,
        if (slow[i] != null) 'ema_slow': slow[i]!,
        if (adx.adx[i] != null) 'adx': adx.adx[i]!,
      },
      explanation: reason,
    );
  }
}
