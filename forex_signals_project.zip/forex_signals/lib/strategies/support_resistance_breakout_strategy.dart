import '../core/enums.dart';
import '../indicators/indicator_utils.dart';
import '../models/candle.dart';
import '../models/strategy_meta.dart';
import '../models/strategy_result.dart';
import 'strategy.dart';

/// #20 — Support/Resistance Breakout. Finds the most recent confirmed swing
/// high/low within a lookback window and treats it as a resistance/support
/// level; a close beyond it is a breakout.
class SupportResistanceBreakoutStrategy extends Strategy {
  @override
  String get id => 'support_resistance_breakout';

  @override
  int get minCandles => 60;

  @override
  List<StrategyParamSpec> get paramSpecs => const [
        StrategyParamSpec(
            key: 'swing_left_right', label: 'Swing bars each side', defaultValue: 4, min: 2, max: 10),
        StrategyParamSpec(
            key: 'lookback', label: 'Level search window', defaultValue: 50, min: 20, max: 150),
      ];

  @override
  StrategyMeta get meta => StrategyMeta(
        id: id,
        name: 'Support/Resistance Breakout',
        shortExplanation:
            'Finds the most recent swing high/low and signals when price breaks through it.',
        indicatorsUsed: const ['Price swing highs/lows'],
        calculationLogic:
            'The most recent confirmed swing high in the lookback window is treated as '
            'resistance, and the most recent swing low as support. A close beyond either '
            'level is a breakout.',
        buyConditions: 'Close breaks above the most recent swing-high resistance level.',
        sellConditions: 'Close breaks below the most recent swing-low support level.',
        neutralConditions: 'Price stays between the identified support and resistance.',
        suitableMarketConditions: 'Markets approaching a well-defined recent high or low.',
        typicalWeaknesses:
            'Swing levels are naive (based on local highs/lows only) and can be broken by a '
            'brief spike that reverses immediately.',
        usualTimeframes: '1H, 4H, 1D',
      );

  @override
  StrategyResult evaluate(CandleSeries series, Map<String, num> params) {
    final leftRight = params['swing_left_right']!.toInt();
    final lookback = params['lookback']!.toInt();
    final i = series.length - 1;
    final last = series.last;
    final start = (i - lookback + 1).clamp(0, i);

    final highsWindow = series.highs.sublist(start);
    final lowsWindow = series.lows.sublist(start);
    final swingHighs = findSwingHighIndices(highsWindow, leftRight: leftRight);
    final swingLows = findSwingLowIndices(lowsWindow, leftRight: leftRight);

    var direction = StrategyDirection.neutral;
    var reason = 'Price is between the recent support and resistance levels.';
    final values = <String, double>{};

    if (swingHighs.isNotEmpty) {
      final resistance = highsWindow[swingHighs.last];
      values['resistance'] = resistance;
      final prevClose = i > 0 ? series[i - 1].close : last.close;
      if (prevClose <= resistance && last.close > resistance) {
        direction = StrategyDirection.buy;
        reason = 'Close broke above recent resistance at ${resistance.toStringAsFixed(5)}.';
      }
    }

    if (direction == StrategyDirection.neutral && swingLows.isNotEmpty) {
      final support = lowsWindow[swingLows.last];
      values['support'] = support;
      final prevClose = i > 0 ? series[i - 1].close : last.close;
      if (prevClose >= support && last.close < support) {
        direction = StrategyDirection.sell;
        reason = 'Close broke below recent support at ${support.toStringAsFixed(5)}.';
      }
    }

    return StrategyResult(
      strategyId: id,
      direction: direction,
      timestamp: last.timestamp,
      entryPriceRef: last.close,
      indicatorValues: values,
      explanation: reason,
    );
  }
}
