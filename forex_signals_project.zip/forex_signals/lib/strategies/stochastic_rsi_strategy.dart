import '../core/enums.dart';
import '../indicators/indicator_engine.dart';
import '../indicators/indicator_utils.dart';
import '../indicators/stochastic_rsi.dart';
import '../models/candle.dart';
import '../models/strategy_meta.dart';
import '../models/strategy_result.dart';
import 'strategy.dart';

/// #7 — Stochastic RSI. Applies the stochastic formula to RSI instead of
/// price, making it more sensitive than either plain RSI (#4) or plain
/// Stochastic (#6) — useful for catching earlier turns, at the cost of
/// more false positives.
class StochasticRsiStrategy extends Strategy {
  @override
  String get id => 'stochastic_rsi';

  @override
  int get minCandles => 80;

  @override
  List<StrategyParamSpec> get paramSpecs => const [
        StrategyParamSpec(key: 'rsi_period', label: 'RSI period', defaultValue: 14, min: 5, max: 40),
        StrategyParamSpec(key: 'stoch_period', label: 'Stoch period', defaultValue: 14, min: 5, max: 40),
        StrategyParamSpec(key: 'k_smooth', label: '%K smoothing', defaultValue: 3, min: 1, max: 10),
        StrategyParamSpec(key: 'd_period', label: '%D period', defaultValue: 3, min: 1, max: 10),
        StrategyParamSpec(key: 'oversold', label: 'Oversold level', defaultValue: 20, min: 5, max: 30),
        StrategyParamSpec(key: 'overbought', label: 'Overbought level', defaultValue: 80, min: 70, max: 95),
      ];

  @override
  StrategyMeta get meta => StrategyMeta(
        id: id,
        name: 'Stochastic RSI',
        shortExplanation: 'A more sensitive cousin of RSI and Stochastic, built by applying the '
            'stochastic formula to RSI itself.',
        indicatorsUsed: const ['RSI', 'Stochastic RSI %K', 'Stochastic RSI %D'],
        calculationLogic:
            'RSI is computed first, then the stochastic %K/%D formula is applied to the RSI '
            'series (instead of price) over its own lookback period.',
        buyConditions: '%K crosses above %D while below the oversold level.',
        sellConditions: '%K crosses below %D while above the overbought level.',
        neutralConditions: 'Cross happens outside the extreme zones, or no cross at all.',
        suitableMarketConditions: 'Range-bound markets; early reversal spotting within a range.',
        typicalWeaknesses: 'More prone to noise/false signals than plain RSI or Stochastic since '
            'it is a derivative of a derivative.',
        usualTimeframes: '15M, 1H',
      );

  @override
  StrategyResult evaluate(CandleSeries series, Map<String, num> params) {
    final rsiPeriod = params['rsi_period']!.toInt();
    final stochPeriod = params['stoch_period']!.toInt();
    final kSmooth = params['k_smooth']!.toInt();
    final dPeriod = params['d_period']!.toInt();
    final oversold = params['oversold']!.toDouble();
    final overbought = params['overbought']!.toDouble();
    final base = IndicatorEngine.seriesKey(series, 'any', 'any');
    final sr = IndicatorEngine.memoize(
      '$base|stochrsi|$rsiPeriod|$stochPeriod|$kSmooth|$dPeriod',
      () => StochasticRsi.compute(series,
          rsiPeriod: rsiPeriod, stochPeriod: stochPeriod, kSmoothing: kSmooth, dPeriod: dPeriod),
    );

    final i = series.length - 1;
    final last = series.last;
    var direction = StrategyDirection.neutral;
    var reason = 'No %K/%D cross inside an extreme zone.';

    if (crossedAbove(sr.percentK, sr.percentD, i) && (sr.percentK[i] ?? 100) < oversold) {
      direction = StrategyDirection.buy;
      reason = 'StochRSI %K crossed above %D while below the oversold level ($oversold).';
    } else if (crossedBelow(sr.percentK, sr.percentD, i) && (sr.percentK[i] ?? 0) > overbought) {
      direction = StrategyDirection.sell;
      reason = 'StochRSI %K crossed below %D while above the overbought level ($overbought).';
    }

    return StrategyResult(
      strategyId: id,
      direction: direction,
      timestamp: last.timestamp,
      entryPriceRef: last.close,
      indicatorValues: {
        if (sr.percentK[i] != null) 'stochrsi_k': sr.percentK[i]!,
        if (sr.percentD[i] != null) 'stochrsi_d': sr.percentD[i]!,
      },
      explanation: reason,
    );
  }
}
