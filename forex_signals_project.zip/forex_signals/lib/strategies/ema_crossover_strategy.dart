import '../core/enums.dart';
import '../indicators/indicator_engine.dart';
import '../indicators/indicator_utils.dart';
import '../indicators/moving_averages.dart';
import '../models/candle.dart';
import '../models/strategy_meta.dart';
import '../models/strategy_result.dart';
import 'strategy.dart';

/// #2 — EMA Crossover. Same idea as SMA Crossover but with exponential
/// moving averages, which weight recent candles more heavily and so react
/// faster (at the cost of more noise) than the SMA version.
class EmaCrossoverStrategy extends Strategy {
  @override
  String get id => 'ema_crossover';

  @override
  int get minCandles => 60;

  @override
  List<StrategyParamSpec> get paramSpecs => const [
        StrategyParamSpec(key: 'fast', label: 'Fast period', defaultValue: 9, min: 3, max: 50),
        StrategyParamSpec(key: 'slow', label: 'Slow period', defaultValue: 21, min: 10, max: 200),
      ];

  @override
  StrategyMeta get meta => StrategyMeta(
        id: id,
        name: 'EMA Crossover',
        shortExplanation:
            'Like SMA Crossover but weights recent candles more, so it reacts faster.',
        indicatorsUsed: const ['EMA (fast)', 'EMA (slow)'],
        calculationLogic:
            'Computes a fast and a slow Exponential Moving Average of closing price and '
            'watches for the fast line crossing the slow line.',
        buyConditions: 'Fast EMA crosses above slow EMA.',
        sellConditions: 'Fast EMA crosses below slow EMA.',
        neutralConditions: 'No crossover on the current candle.',
        suitableMarketConditions: 'Trending markets; reacts faster than SMA Crossover.',
        typicalWeaknesses:
            'More sensitive to short-term noise than SMA Crossover, so it can whipsaw more '
            'often in ranging conditions.',
        usualTimeframes: '15M, 1H, 4H',
      );

  @override
  StrategyResult evaluate(CandleSeries series, Map<String, num> params) {
    final fastP = params['fast']!.toInt();
    final slowP = params['slow']!.toInt();
    final base = IndicatorEngine.seriesKey(series, 'any', 'any');
    final fast =
        IndicatorEngine.memoize('$base|ema|$fastP', () => Ema.compute(series, period: fastP));
    final slow =
        IndicatorEngine.memoize('$base|ema|$slowP', () => Ema.compute(series, period: slowP));

    final i = series.length - 1;
    final last = series.last;

    var direction = StrategyDirection.neutral;
    var reason = 'No EMA crossover on this candle.';
    if (crossedAbove(fast, slow, i)) {
      direction = StrategyDirection.buy;
      reason = 'Fast EMA($fastP) crossed above slow EMA($slowP).';
    } else if (crossedBelow(fast, slow, i)) {
      direction = StrategyDirection.sell;
      reason = 'Fast EMA($fastP) crossed below slow EMA($slowP).';
    }

    return StrategyResult(
      strategyId: id,
      direction: direction,
      timestamp: last.timestamp,
      entryPriceRef: last.close,
      indicatorValues: {
        if (fast[i] != null) 'ema_fast': fast[i]!,
        if (slow[i] != null) 'ema_slow': slow[i]!,
      },
      explanation: reason,
    );
  }
}
