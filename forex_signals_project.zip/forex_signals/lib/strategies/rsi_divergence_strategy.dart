import '../core/enums.dart';
import '../indicators/indicator_engine.dart';
import '../indicators/indicator_utils.dart';
import '../indicators/rsi.dart';
import '../models/candle.dart';
import '../models/strategy_meta.dart';
import '../models/strategy_result.dart';
import 'strategy.dart';

/// #5 — RSI Divergence. Distinct from #4: this looks for *disagreement*
/// between price swings and RSI swings, a classic early-reversal signal.
///
/// A swing point (local min/max, [swingLeftRight] bars on each side) is
/// only "confirmed" once enough bars exist after it — so this strategy only
/// fires on the single candle where a new swing gets confirmed and disagrees
/// with the prior swing, rather than repeating every candle afterwards.
class RsiDivergenceStrategy extends Strategy {
  @override
  String get id => 'rsi_divergence';

  @override
  int get minCandles => 80;

  @override
  List<StrategyParamSpec> get paramSpecs => const [
        StrategyParamSpec(key: 'rsi_period', label: 'RSI period', defaultValue: 14, min: 5, max: 50),
        StrategyParamSpec(
            key: 'swing_left_right', label: 'Swing bars each side', defaultValue: 3, min: 2, max: 8),
        StrategyParamSpec(
            key: 'lookback', label: 'Swing search window', defaultValue: 60, min: 30, max: 150),
      ];

  @override
  StrategyMeta get meta => StrategyMeta(
        id: id,
        name: 'RSI Divergence',
        shortExplanation:
            'Looks for price and RSI disagreeing at swing points — an early hint of exhaustion.',
        indicatorsUsed: const ['RSI', 'Price swing highs/lows'],
        calculationLogic:
            'Detects local swing highs and lows in price and compares them to RSI at the same '
            'points. A swing point is confirmed once enough bars exist on both sides of it.',
        buyConditions:
            'Bullish divergence: price makes a lower swing low while RSI makes a higher swing '
            'low (downward momentum is fading).',
        sellConditions:
            'Bearish divergence: price makes a higher swing high while RSI makes a lower swing '
            'high (upward momentum is fading).',
        neutralConditions: 'No newly confirmed divergent swing pair.',
        suitableMarketConditions: 'Near the end of an extended trend, ahead of a reversal.',
        typicalWeaknesses:
            'Divergence can persist for a long time before price actually reverses ("divergence '
            'without reversal"), and swing confirmation introduces a small lag.',
        usualTimeframes: '1H, 4H, 1D',
      );

  @override
  StrategyResult evaluate(CandleSeries series, Map<String, num> params) {
    final rsiPeriod = params['rsi_period']!.toInt();
    final leftRight = params['swing_left_right']!.toInt();
    final lookback = params['lookback']!.toInt();
    final base = IndicatorEngine.seriesKey(series, 'any', 'any');
    final rsi = IndicatorEngine.memoize('$base|rsi|$rsiPeriod', () => Rsi.compute(series, period: rsiPeriod));

    final i = series.length - 1;
    final last = series.last;
    final start = (i - lookback + 1).clamp(0, i);
    final windowCloses = series.closes.sublist(start);

    var direction = StrategyDirection.neutral;
    var reason = 'No newly confirmed price/RSI divergence.';
    final values = <String, double>{if (rsi[i] != null) 'rsi': rsi[i]!};

    final swingLows = findSwingLowIndices(windowCloses, leftRight: leftRight);
    if (swingLows.length >= 2) {
      final lastLocal = swingLows.last;
      final confirmedNow = (start + lastLocal + leftRight) == i;
      if (confirmedNow) {
        final prevLocal = swingLows[swingLows.length - 2];
        final idxA = start + prevLocal, idxB = start + lastLocal;
        final priceA = series.closes[idxA], priceB = series.closes[idxB];
        final rsiA = rsi[idxA], rsiB = rsi[idxB];
        if (rsiA != null && rsiB != null && priceB < priceA && rsiB > rsiA) {
          direction = StrategyDirection.buy;
          reason = 'Bullish divergence: price made a lower low but RSI made a higher low '
              '(swings at ${series.candles[idxA].timestamp.toIso8601String()} and '
              '${series.candles[idxB].timestamp.toIso8601String()}).';
        }
      }
    }

    if (direction == StrategyDirection.neutral) {
      final swingHighs = findSwingHighIndices(windowCloses, leftRight: leftRight);
      if (swingHighs.length >= 2) {
        final lastLocal = swingHighs.last;
        final confirmedNow = (start + lastLocal + leftRight) == i;
        if (confirmedNow) {
          final prevLocal = swingHighs[swingHighs.length - 2];
          final idxA = start + prevLocal, idxB = start + lastLocal;
          final priceA = series.closes[idxA], priceB = series.closes[idxB];
          final rsiA = rsi[idxA], rsiB = rsi[idxB];
          if (rsiA != null && rsiB != null && priceB > priceA && rsiB < rsiA) {
            direction = StrategyDirection.sell;
            reason = 'Bearish divergence: price made a higher high but RSI made a lower high '
                '(swings at ${series.candles[idxA].timestamp.toIso8601String()} and '
                '${series.candles[idxB].timestamp.toIso8601String()}).';
          }
        }
      }
    }

    return StrategyResult(
      strategyId: id,
      direction: direction,
      timestamp: last.timestamp,
      entryPriceRef: last.close,
      indicatorValues: values,
      explanation: reason,
    );
  }
}
