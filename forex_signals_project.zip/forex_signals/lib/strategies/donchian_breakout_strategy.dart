import '../core/enums.dart';
import '../indicators/donchian.dart';
import '../indicators/indicator_engine.dart';
import '../models/candle.dart';
import '../models/strategy_meta.dart';
import '../models/strategy_result.dart';
import 'strategy.dart';

/// #11 — Donchian Channel Breakout. The classic "Turtle Trader" style
/// breakout: a close beyond the N-period high/low range signals a new
/// directional move.
class DonchianBreakoutStrategy extends Strategy {
  @override
  String get id => 'donchian_breakout';

  @override
  int get minCandles => 60;

  @override
  List<StrategyParamSpec> get paramSpecs => const [
        StrategyParamSpec(key: 'period', label: 'Channel period', defaultValue: 20, min: 10, max: 100),
      ];

  @override
  StrategyMeta get meta => StrategyMeta(
        id: id,
        name: 'Donchian Channel Breakout',
        shortExplanation: 'Signals when price closes beyond its highest high or lowest low of '
            'the last N candles.',
        indicatorsUsed: const ['Donchian Channel (rolling high/low)'],
        calculationLogic:
            'Upper band = highest high of the last N candles; lower band = lowest low. A close '
            'beyond either band, that was inside it the candle before, is a breakout.',
        buyConditions: 'Close crosses above the N-period highest high.',
        sellConditions: 'Close crosses below the N-period lowest low.',
        neutralConditions: 'Price stays inside the channel.',
        suitableMarketConditions: 'Markets breaking out of an established trading range.',
        typicalWeaknesses:
            'Can produce false breakouts in choppy markets that briefly poke outside the range '
            'and snap back.',
        usualTimeframes: '4H, 1D',
      );

  @override
  StrategyResult evaluate(CandleSeries series, Map<String, num> params) {
    final period = params['period']!.toInt();
    final base = IndicatorEngine.seriesKey(series, 'any', 'any');
    final donchian =
        IndicatorEngine.memoize('$base|donchian|$period', () => Donchian.compute(series, period: period));

    final i = series.length - 1;
    final last = series.last;
    var direction = StrategyDirection.neutral;
    var reason = 'Price is inside the Donchian channel.';

    if (i > 0) {
      final upper0 = donchian.upper[i - 1], upper1 = donchian.upper[i];
      final lower0 = donchian.lower[i - 1], lower1 = donchian.lower[i];
      final close0 = series[i - 1].close, close1 = last.close;
      if (upper0 != null && upper1 != null && close0 <= upper0 && close1 > upper1) {
        direction = StrategyDirection.buy;
        reason = 'Close broke above the $period-period highest high.';
      } else if (lower0 != null && lower1 != null && close0 >= lower0 && close1 < lower1) {
        direction = StrategyDirection.sell;
        reason = 'Close broke below the $period-period lowest low.';
      }
    }

    return StrategyResult(
      strategyId: id,
      direction: direction,
      timestamp: last.timestamp,
      entryPriceRef: last.close,
      indicatorValues: {
        if (donchian.upper[i] != null) 'donchian_upper': donchian.upper[i]!,
        if (donchian.lower[i] != null) 'donchian_lower': donchian.lower[i]!,
      },
      explanation: reason,
    );
  }
}
