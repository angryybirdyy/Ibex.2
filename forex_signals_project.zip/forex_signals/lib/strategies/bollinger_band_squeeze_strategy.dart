import '../core/enums.dart';
import '../indicators/bollinger_bands.dart';
import '../indicators/indicator_engine.dart';
import '../models/candle.dart';
import '../models/strategy_meta.dart';
import '../models/strategy_result.dart';
import 'strategy.dart';

/// #9 — Bollinger Band Squeeze. Distinct from plain Bollinger Bands (#8):
/// this watches band *width* rather than price position, looking for a
/// volatility contraction (squeeze) followed by a directional breakout —
/// the classic "calm before the move" setup.
class BollingerBandSqueezeStrategy extends Strategy {
  @override
  String get id => 'bollinger_band_squeeze';

  @override
  int get minCandles => 60;

  @override
  List<StrategyParamSpec> get paramSpecs => const [
        StrategyParamSpec(key: 'period', label: 'BB period', defaultValue: 20, min: 10, max: 50),
        StrategyParamSpec(
            key: 'std_dev', label: 'Std deviations', defaultValue: 2, min: 1, max: 4, step: 0.1, isInteger: false),
        StrategyParamSpec(
            key: 'squeeze_lookback', label: 'Squeeze window', defaultValue: 20, min: 10, max: 60),
        StrategyParamSpec(
            key: 'confirm_window', label: 'Breakout search window', defaultValue: 5, min: 1, max: 15),
      ];

  @override
  StrategyMeta get meta => StrategyMeta(
        id: id,
        name: 'Bollinger Band Squeeze',
        shortExplanation:
            'Watches for the bands pinching in (low volatility) and then a breakout move.',
        indicatorsUsed: const ['Bollinger Bands', 'Band width'],
        calculationLogic:
            'Band width = (upper − lower) ÷ middle. A squeeze is flagged when width hits a new '
            'N-bar low; a breakout is a close beyond either band shortly after a squeeze.',
        buyConditions: 'A recent squeeze was followed by a close above the upper band.',
        sellConditions: 'A recent squeeze was followed by a close below the lower band.',
        neutralConditions: 'No recent squeeze, or a squeeze with no breakout yet.',
        suitableMarketConditions:
            'Consolidating markets that are building up for a volatility expansion.',
        typicalWeaknesses:
            'Breakouts can be false ("fakeouts") that reverse quickly, especially without '
            'a volume or momentum confirmation.',
        usualTimeframes: '1H, 4H, 1D',
      );

  @override
  StrategyResult evaluate(CandleSeries series, Map<String, num> params) {
    final period = params['period']!.toInt();
    final stdDev = params['std_dev']!.toDouble();
    final squeezeLookback = params['squeeze_lookback']!.toInt();
    final confirmWindow = params['confirm_window']!.toInt();
    final base = IndicatorEngine.seriesKey(series, 'any', 'any');
    final bb = IndicatorEngine.memoize(
      '$base|bb|$period|$stdDev',
      () => BollingerBands.compute(series, period: period, stdDevMultiple: stdDev),
    );

    final i = series.length - 1;
    final last = series.last;
    var direction = StrategyDirection.neutral;
    var reason = 'No recent squeeze-then-breakout sequence.';

    bool wasSqueezeAt(int k) {
      if (k - squeezeLookback + 1 < 0) return false;
      final w = bb.bandwidth[k];
      if (w == null) return false;
      for (int j = k - squeezeLookback + 1; j <= k; j++) {
        final wj = bb.bandwidth[j];
        if (wj == null || wj < w) return false;
      }
      return true;
    }

    bool squeezeRecently = false;
    for (int k = (i - confirmWindow).clamp(0, i); k < i; k++) {
      if (wasSqueezeAt(k)) {
        squeezeRecently = true;
        break;
      }
    }

    if (squeezeRecently && i > 0) {
      final upper0 = bb.upper[i - 1], upper1 = bb.upper[i];
      final lower0 = bb.lower[i - 1], lower1 = bb.lower[i];
      final close0 = series[i - 1].close, close1 = last.close;
      if (upper0 != null && upper1 != null && close0 <= upper0 && close1 > upper1) {
        direction = StrategyDirection.buy;
        reason = 'Bands squeezed recently and price broke out above the upper band.';
      } else if (lower0 != null && lower1 != null && close0 >= lower0 && close1 < lower1) {
        direction = StrategyDirection.sell;
        reason = 'Bands squeezed recently and price broke out below the lower band.';
      }
    }

    return StrategyResult(
      strategyId: id,
      direction: direction,
      timestamp: last.timestamp,
      entryPriceRef: last.close,
      indicatorValues: {
        if (bb.bandwidth[i] != null) 'bb_bandwidth': bb.bandwidth[i]!,
        if (bb.upper[i] != null) 'bb_upper': bb.upper[i]!,
        if (bb.lower[i] != null) 'bb_lower': bb.lower[i]!,
      },
      explanation: reason,
    );
  }
}
