import '../core/enums.dart';
import '../indicators/indicator_engine.dart';
import '../indicators/rsi.dart';
import '../models/candle.dart';
import '../models/strategy_meta.dart';
import '../models/strategy_result.dart';
import 'strategy.dart';

/// #4 — RSI Overbought/Oversold. Fires on the *recovery* cross (RSI
/// re-entering its normal range), not merely "RSI is below 30" every
/// candle — that distinction is what keeps this from spamming identical
/// signals every refresh while RSI sits under the threshold.
class RsiOverboughtOversoldStrategy extends Strategy {
  @override
  String get id => 'rsi_overbought_oversold';

  @override
  int get minCandles => 60;

  @override
  List<StrategyParamSpec> get paramSpecs => const [
        StrategyParamSpec(key: 'period', label: 'RSI period', defaultValue: 14, min: 5, max: 50),
        StrategyParamSpec(
            key: 'oversold', label: 'Oversold level', defaultValue: 30, min: 10, max: 40),
        StrategyParamSpec(
            key: 'overbought', label: 'Overbought level', defaultValue: 70, min: 60, max: 90),
      ];

  @override
  StrategyMeta get meta => StrategyMeta(
        id: id,
        name: 'RSI Overbought/Oversold',
        shortExplanation:
            'Flags when price has likely moved too far, too fast, and may be due for a bounce.',
        indicatorsUsed: const ['RSI'],
        calculationLogic:
            'Wilder\'s RSI measures the ratio of average gains to average losses over the '
            'period. Signals fire on the *recovery* cross back through the threshold, not '
            'on every candle spent beyond it.',
        buyConditions: 'RSI crosses back above the oversold level (e.g. 30) from below.',
        sellConditions: 'RSI crosses back below the overbought level (e.g. 70) from above.',
        neutralConditions: 'RSI is between the thresholds, or holding beyond one without a '
            'recovery cross yet.',
        suitableMarketConditions: 'Range-bound / mean-reverting markets.',
        typicalWeaknesses:
            'In a strong trend, RSI can stay overbought or oversold for a long time, so '
            'counter-trend signals can fire early and repeatedly against the trend.',
        usualTimeframes: '15M, 1H, 4H',
      );

  @override
  StrategyResult evaluate(CandleSeries series, Map<String, num> params) {
    final period = params['period']!.toInt();
    final oversold = params['oversold']!.toDouble();
    final overbought = params['overbought']!.toDouble();
    final base = IndicatorEngine.seriesKey(series, 'any', 'any');
    final rsi = IndicatorEngine.memoize('$base|rsi|$period', () => Rsi.compute(series, period: period));

    final i = series.length - 1;
    final last = series.last;
    final cur = rsi[i];
    final prev = i > 0 ? rsi[i - 1] : null;

    var direction = StrategyDirection.neutral;
    var reason = 'RSI is within its normal range.';
    if (cur != null && prev != null) {
      if (prev <= oversold && cur > oversold) {
        direction = StrategyDirection.buy;
        reason = 'RSI recovered above the oversold level ($oversold) after being oversold.';
      } else if (prev >= overbought && cur < overbought) {
        direction = StrategyDirection.sell;
        reason = 'RSI dropped back below the overbought level ($overbought) after being overbought.';
      }
    }

    return StrategyResult(
      strategyId: id,
      direction: direction,
      timestamp: last.timestamp,
      entryPriceRef: last.close,
      indicatorValues: {if (cur != null) 'rsi': cur},
      explanation: reason,
    );
  }
}
