import '../backtesting/tpsl_rules.dart';
import '../core/enums.dart';
import '../core/failures.dart';
import '../core/market_types.dart';
import '../database/backtest_dao.dart';
import '../database/candle_dao.dart';
import '../database/signal_dao.dart';
import '../database/strategy_settings_dao.dart';
import '../indicators/atr.dart';
import '../models/app_settings.dart';
import '../models/candle.dart';
import '../models/signal.dart';
import '../strategies/strategy_registry.dart';
import 'signal_deduplicator.dart';
import 'signal_resolver.dart';

/// Everything that happened during one call to [SignalEngine.runCycle].
/// The caller (foreground provider or background TaskHandler) uses
/// [newlyCreated] to decide what to notify about (spec section 43, step 10)
/// — [SignalEngine] itself never touches `flutter_local_notifications`
/// directly, so it stays a plain Dart class testable with `flutter test`
/// and reusable unchanged inside the foreground-service isolate.
class SignalCycleSummary {
  const SignalCycleSummary({
    required this.pair,
    required this.timeframe,
    required this.newlyCreated,
    required this.resolvedCount,
    required this.syncFailure,
    required this.candleCount,
  });

  final CurrencyPair pair;
  final Timeframe timeframe;
  final List<Signal> newlyCreated;
  final int resolvedCount;
  final AppFailure? syncFailure;
  final int candleCount;
}

/// The engine described in spec sections 43/44: for every market update, it
/// runs **all** implemented strategies (never just the chart-visible
/// subset — see `strategies/strategy_registry.dart` and
/// `database/strategy_settings_dao.dart`'s doc comment for where that
/// separation is enforced), records genuinely new signals exactly once, and
/// resolves previously-active ones. The Strategies tab's enable/disable
/// toggles are never consulted here — that would be the bug spec section 44
/// explicitly warns against.
class SignalEngine {
  SignalEngine({
    required this.getSeries,
    required this.syncPairTimeframe,
    required this.candleDao,
    required this.signalDao,
    required this.backtestDao,
    required this.strategySettingsDao,
    required this.getSettings,
  })  : _dedup = SignalDeduplicator(signalDao),
        _resolver = SignalResolver(signalDao, candleDao);

  /// Injected rather than importing `MarketDataRepository` directly, so
  /// this class has zero dependency on `http`/`sqflite` platform channels
  /// beyond what its own dao parameters already need — kept easy to unit
  /// test with in-memory fakes.
  final Future<CandleSeries> Function(CurrencyPair pair, Timeframe timeframe, {int limit}) getSeries;
  final Future<AppFailure?> Function(CurrencyPair pair, Timeframe timeframe, {int outputSize}) syncPairTimeframe;
  final CandleDao candleDao;
  final SignalDao signalDao;
  final BacktestDao backtestDao;
  final StrategySettingsDao strategySettingsDao;
  final AppSettings Function() getSettings;

  final SignalDeduplicator _dedup;
  final SignalResolver _resolver;

  Future<SignalCycleSummary> runCycle(
    CurrencyPair pair,
    Timeframe timeframe, {
    int candleLookback = 300,
  }) async {
    final settings = getSettings();

    // Step 1: refresh candles. A sync failure is recorded but never fatal —
    // we still evaluate against whatever's cached (spec section 20).
    final syncFailure = await syncPairTimeframe(pair, timeframe, outputSize: candleLookback);
    final series = await getSeries(pair, timeframe, limit: candleLookback);

    final newlyCreated = <Signal>[];

    if (series.length >= 30) {
      // Step 2 (indicator updates) happens inside each strategy's own
      // evaluate() call — there's no separate global "update indicators"
      // step because indicators are cached per-series in
      // `indicators/indicator_engine.dart`, not precomputed eagerly.
      final atrSeries = Atr.compute(series, period: 14);
      final atrNow = atrSeries.isEmpty ? null : atrSeries.last;

      // Steps 3-4: run every strategy, regardless of chart-visibility.
      for (final strategy in StrategyRegistry.all) {
        final overrides = await strategySettingsDao.getParamOverrides(strategy.id);
        final result = strategy.evaluateSafe(series, overrides: overrides.isEmpty ? null : overrides);
        if (result.direction == StrategyDirection.neutral) continue;

        final direction =
            result.direction == StrategyDirection.buy ? SignalDirection.buy : SignalDirection.sell;
        final levels = computeTpSl(
          direction: direction,
          entryPrice: result.entryPriceRef,
          pair: pair,
          method: settings.tpSlMethod,
          atrValue: atrNow,
          atrMultiple: settings.atrMultiple,
          fixedPips: settings.fixedPips,
        );

        // Freeze the most recently computed win rate onto the signal at
        // creation time (spec section 15) rather than a live join, so a
        // later backtest recalculation never silently rewrites history.
        final btRow = await backtestDao.latestFor(strategy.id, pair.code, timeframe.label);
        final winRate = (btRow?['win_rate'] as num?)?.toDouble();
        final sampleSize = btRow == null
            ? null
            : ((btRow['winning_trades'] as int) + (btRow['losing_trades'] as int));

        // Steps 5-7: create + dedupe + store.
        final created = await _dedup.recordIfNew(
          result: result,
          pairCode: pair.code,
          timeframeLabel: timeframe.label,
          targetPrice: levels.target,
          stopLossPrice: levels.stopLoss,
          historicalWinRate: winRate,
          historicalSampleSize: sampleSize,
          isDemo: settings.dataMode == DataMode.demo,
        );
        if (created != null) newlyCreated.add(created);
      }
    }

    // Step 8-9: resolve previously active signals against fresh candles.
    final resolvedCount = await _resolver.resolveActiveSignals(
      pair: pair,
      timeframe: timeframe,
      evaluationWindowCandles: settings.evaluationWindowCandles,
    );

    // Step 10 (notifications) and step 11 (UI refresh) are the caller's
    // responsibility — see `services/background_service.dart` and
    // `state/signals_provider.dart`.
    return SignalCycleSummary(
      pair: pair,
      timeframe: timeframe,
      newlyCreated: newlyCreated,
      resolvedCount: resolvedCount,
      syncFailure: syncFailure,
      candleCount: series.length,
    );
  }

  Future<List<SignalCycleSummary>> runFullCycle({
    required List<CurrencyPair> pairs,
    required List<Timeframe> timeframes,
  }) async {
    final out = <SignalCycleSummary>[];
    for (final pair in pairs) {
      for (final tf in timeframes) {
        out.add(await runCycle(pair, tf));
      }
    }
    return out;
  }
}
