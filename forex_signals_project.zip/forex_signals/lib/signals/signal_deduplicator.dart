import '../core/enums.dart';
import '../core/id_utils.dart';
import '../database/signal_dao.dart';
import '../models/signal.dart';
import '../models/strategy_result.dart';

/// Implements spec section 16 (signal deduplication) and section 17
/// (multi-timeframe independence).
///
/// The identity of a signal *event* is the tuple (pair, timeframe,
/// strategy, candle timestamp, direction) — see
/// `core/id_utils.dart#buildSignalIdentity`. Two evaluations of the same
/// strategy against the same candle, with the same resulting direction,
/// always produce the same id. Since [SignalDao.insertIfNew] uses
/// `INSERT OR IGNORE` on that id as the primary key, calling this on every
/// refresh cycle is always safe: repeated refreshes while the same candle
/// is still forming, or while the strategy's state hasn't changed, simply
/// hit the "already exists" branch and insert nothing new.
///
/// A genuinely new row only appears when *any* part of the identity
/// changes — most commonly, a new candle closes and the strategy fires
/// again (candle timestamp changes), or the same candle's strategy result
/// flips direction after a late data correction (direction changes). Every
/// (pair, timeframe) pair is independent by construction, since both are
/// part of the identity — a 5M RSI signal can never collide with, or
/// overwrite, a 1H RSI signal on the same pair.
class SignalDeduplicator {
  SignalDeduplicator(this._signalDao);
  final SignalDao _signalDao;

  /// Builds a [Signal] from a non-neutral [StrategyResult] and inserts it
  /// if — and only if — this exact event hasn't been recorded before.
  /// Returns the inserted [Signal], or `null` if it was a duplicate.
  Future<Signal?> recordIfNew({
    required StrategyResult result,
    required String pairCode,
    required String timeframeLabel,
    double? targetPrice,
    double? stopLossPrice,
    double? historicalWinRate,
    int? historicalSampleSize,
    bool isDemo = false,
  }) async {
    if (result.direction == StrategyDirection.neutral) return null;

    final direction =
        result.direction == StrategyDirection.buy ? SignalDirection.buy : SignalDirection.sell;

    final id = buildSignalIdentity(
      pairCode: pairCode,
      timeframeLabel: timeframeLabel,
      strategyId: result.strategyId,
      candleTimestampUtc: result.timestamp,
      direction: direction.name,
    );

    final signal = Signal(
      id: id,
      pairCode: pairCode,
      timeframeLabel: timeframeLabel,
      strategyId: result.strategyId,
      direction: direction,
      candleTimestamp: result.timestamp,
      entryPrice: result.entryPriceRef,
      createdAt: DateTime.now().toUtc(),
      targetPrice: targetPrice,
      stopLossPrice: stopLossPrice,
      historicalWinRate: historicalWinRate,
      historicalSampleSize: historicalSampleSize,
      explanation: result.explanation,
      indicatorSnapshot: result.indicatorValues,
      isDemo: isDemo,
    );

    final inserted = await _signalDao.insertIfNew(signal);
    return inserted ? signal : null;
  }
}
