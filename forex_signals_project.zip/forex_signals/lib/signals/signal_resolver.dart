import '../backtesting/tpsl_rules.dart';
import '../core/enums.dart';
import '../core/logger.dart';
import '../core/market_types.dart';
import '../database/candle_dao.dart';
import '../database/signal_dao.dart';

/// Checks every ACTIVE signal for a (pair, timeframe) against candles that
/// have arrived since it was created, using the exact same
/// [evaluateSignalOutcome] rule the backtester uses — so "did this signal
/// win?" is answered identically whether it happened five minutes ago or
/// five months ago (spec section 13).
class SignalResolver {
  SignalResolver(this._signalDao, this._candleDao);
  final SignalDao _signalDao;
  final CandleDao _candleDao;
  static const String _tag = 'SignalResolver';

  /// Returns how many signals changed state (resolved or expired).
  Future<int> resolveActiveSignals({
    required CurrencyPair pair,
    required Timeframe timeframe,
    required int evaluationWindowCandles,
  }) async {
    final active = await _signalDao.getActive(pair: pair.code, timeframe: timeframe.label);
    if (active.isEmpty) return 0;

    final series = await _candleDao.getCandles(pair.code, timeframe.label);
    if (series.isEmpty) return 0;

    int changed = 0;
    for (final signal in active) {
      if (signal.targetPrice == null || signal.stopLossPrice == null) {
        AppLogger.instance.warn(_tag, 'Signal ${signal.id} has no TP/SL — skipping resolution.');
        continue;
      }

      final idx = series.candles.indexWhere((c) => c.timestamp == signal.candleTimestamp);
      if (idx == -1) continue; // signal's own candle has aged out of the local cache

      final allFuture = series.candles.sublist(idx + 1);
      if (allFuture.isEmpty) continue; // no newer candle to check yet

      final windowed =
          allFuture.length > evaluationWindowCandles ? allFuture.sublist(0, evaluationWindowCandles) : allFuture;

      final outcome = evaluateSignalOutcome(
        direction: signal.direction,
        target: signal.targetPrice!,
        stopLoss: signal.stopLossPrice!,
        futureCandles: windowed,
      );

      if (outcome.result == SignalResultType.win || outcome.result == SignalResultType.loss) {
        await _signalDao.update(signal.copyWith(
          status: SignalStatus.resolved,
          resultType: outcome.result,
          resultTimestamp: outcome.exitTime,
          resultPrice: outcome.exitPrice,
        ));
        changed++;
      } else if (allFuture.length >= evaluationWindowCandles) {
        // Every candle in the evaluation window has arrived and neither
        // level was touched — the window has genuinely expired.
        await _signalDao.update(signal.copyWith(
          status: SignalStatus.expired,
          resultType: SignalResultType.unresolved,
          resultTimestamp: series.candles.last.timestamp,
        ));
        changed++;
      }
    }
    return changed;
  }
}
