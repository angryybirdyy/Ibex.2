import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/app_theme.dart';
import '../core/enums.dart';
import '../services/service_status_controller.dart';

/// The small status indicator required by spec section 3: LIVE / MONITORING
/// / PAUSED / OFFLINE / ERROR, plus the last successful update time.
class ServiceStatusChip extends StatelessWidget {
  const ServiceStatusChip({super.key});

  Color _colorFor(ServiceStatus status) => switch (status) {
        ServiceStatus.live => AppColors.bullish,
        ServiceStatus.monitoring => AppColors.accent,
        ServiceStatus.paused => AppColors.neutral,
        ServiceStatus.offline => AppColors.warning,
        ServiceStatus.error => AppColors.bearish,
      };

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<ServiceStatusController>();
    final color = _colorFor(controller.status);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.14),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withValues(alpha: 0.4)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(width: 6, height: 6, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
          const SizedBox(width: 6),
          Text(controller.status.label, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}
