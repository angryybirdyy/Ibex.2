import 'package:flutter/material.dart';

import '../screens/settings/settings_screen.dart';

/// The one settings entry point required by spec section 29: "include a
/// small settings button in an appropriate top area" of every screen, even
/// though the four bottom tabs stay the primary navigation.
class SettingsActionButton extends StatelessWidget {
  const SettingsActionButton({super.key});

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.settings_outlined),
      tooltip: 'Settings',
      onPressed: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => const SettingsScreen()),
      ),
    );
  }
}
