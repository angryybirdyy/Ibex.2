import 'package:flutter/material.dart';

import '../../core/app_theme.dart';
import '../../core/enums.dart';
import '../../core/time_utils.dart';
import '../../models/signal.dart';

/// One signal row (spec sections 11/14/15). Color is never the only signal
/// of status — every colored state also carries an explicit text label
/// (spec section 14: "do not rely only on color").
class SignalListItem extends StatelessWidget {
  const SignalListItem({super.key, required this.signal, required this.onTap});
  final Signal signal;
  final VoidCallback onTap;

  (Color, String, IconData) _statusVisual() {
    if (signal.status == SignalStatus.active) {
      return (AppColors.active, 'ACTIVE', Icons.radio_button_checked);
    }
    switch (signal.resultType) {
      case SignalResultType.win:
        return (AppColors.win, 'WIN', Icons.check_circle);
      case SignalResultType.loss:
        return (AppColors.loss, 'LOSS', Icons.cancel);
      case SignalResultType.unresolved:
        return (AppColors.expired, 'EXPIRED', Icons.timer_off);
      case SignalResultType.pending:
        return (AppColors.active, 'ACTIVE', Icons.radio_button_checked);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isBuy = signal.direction == SignalDirection.buy;
    final directionColor = isBuy ? AppColors.bullish : AppColors.bearish;
    final (statusColor, statusLabel, statusIcon) = _statusVisual();
    final theme = Theme.of(context);

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(color: directionColor.withValues(alpha: 0.16), borderRadius: BorderRadius.circular(6)),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(isBuy ? Icons.arrow_upward : Icons.arrow_downward, size: 14, color: directionColor),
                      const SizedBox(width: 4),
                      Text(isBuy ? 'BUY' : 'SELL', style: TextStyle(color: directionColor, fontWeight: FontWeight.w800, fontSize: 12)),
                    ]),
                  ),
                  const SizedBox(width: 8),
                  Text(signal.pairCode, style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                  const SizedBox(width: 6),
                  Chip(label: Text(signal.timeframeLabel), visualDensity: VisualDensity.compact, padding: EdgeInsets.zero),
                  const Spacer(),
                  Icon(statusIcon, size: 14, color: statusColor),
                  const SizedBox(width: 4),
                  Text(statusLabel, style: TextStyle(color: statusColor, fontWeight: FontWeight.w700, fontSize: 11)),
                ],
              ),
              const SizedBox(height: 8),
              Text(signal.strategyId.replaceAll('_', ' '), style: theme.textTheme.bodyMedium),
              const SizedBox(height: 2),
              Text(
                'Entry ${signal.entryPrice.toStringAsFixed(5)} • ${formatLocal(signal.candleTimestamp)}',
                style: theme.textTheme.bodySmall,
              ),
              if (signal.historicalWinRate != null)
                Padding(
                  padding: const EdgeInsets.only(top: 2),
                  child: Text(
                    'Win rate ${signal.historicalWinRate!.toStringAsFixed(1)}% '
                    '(n=${signal.historicalSampleSize ?? 0})',
                    style: theme.textTheme.bodySmall,
                  ),
                ),
              if (signal.isDemo)
                const Padding(
                  padding: EdgeInsets.only(top: 4),
                  child: Text('DEMO', style: TextStyle(color: AppColors.warning, fontWeight: FontWeight.w700, fontSize: 10)),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
