import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../charts/candlestick_chart.dart';
import '../../core/enums.dart';
import '../../core/market_types.dart';
import '../../core/time_utils.dart';
import '../../models/candle.dart';
import '../../models/signal.dart';
import '../../strategies/strategy_registry.dart';
import '../../state/app_services.dart';

class SignalDetailScreen extends StatefulWidget {
  const SignalDetailScreen({super.key, required this.signal});
  final Signal signal;

  @override
  State<SignalDetailScreen> createState() => _SignalDetailScreenState();
}

class _SignalDetailScreenState extends State<SignalDetailScreen> {
  CandleSeries? _windowSeries;
  int _markerIndex = -1;

  @override
  void initState() {
    super.initState();
    _loadChartWindow();
  }

  Future<void> _loadChartWindow() async {
    final appServices = context.read<AppServices>();
    final pair = CurrencyPair.fromCode(widget.signal.pairCode);
    final timeframe = Timeframe.fromLabel(widget.signal.timeframeLabel);
    final full = await appServices.repository.getSeries(pair, timeframe);
    final idx = full.candles.indexWhere((c) => c.timestamp == widget.signal.candleTimestamp);
    if (idx == -1 || !mounted) return;
    final start = (idx - 30).clamp(0, full.length);
    final end = (idx + 15).clamp(0, full.length);
    setState(() {
      _windowSeries = CandleSeries(full.candles.sublist(start, end));
      _markerIndex = idx - start;
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.signal;
    final meta = StrategyRegistry.exists(s.strategyId) ? StrategyRegistry.byId(s.strategyId).meta : null;
    final pair = CurrencyPair.fromCode(s.pairCode);

    return Scaffold(
      appBar: AppBar(title: Text('${s.pairCode} ${s.direction.name.toUpperCase()} signal')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (_windowSeries != null && _windowSeries!.isNotEmpty)
            SizedBox(
              height: 220,
              child: CandlestickChart(
                series: _windowSeries!,
                pair: pair,
                timeframe: Timeframe.fromLabel(s.timeframeLabel),
                markers: _markerIndex >= 0
                    ? [ChartMarker(candleIndex: _markerIndex, direction: s.direction, price: s.entryPrice)]
                    : const [],
                initialVisibleCandles: _windowSeries!.length,
              ),
            )
          else
            const SizedBox(height: 220, child: Center(child: CircularProgressIndicator())),
          const SizedBox(height: 16),
          _row('Pair', s.pairCode),
          _row('Direction', s.direction.name.toUpperCase()),
          _row('Timeframe', s.timeframeLabel),
          _row('Strategy', meta?.name ?? s.strategyId),
          _row('Signal timestamp', formatLocal(s.candleTimestamp)),
          _row('Entry price', s.entryPrice.toStringAsFixed(5)),
          if (s.targetPrice != null) _row('Target (TP)', s.targetPrice!.toStringAsFixed(5)),
          if (s.stopLossPrice != null) _row('Stop-loss (SL)', s.stopLossPrice!.toStringAsFixed(5)),
          if (s.historicalWinRate != null) _row('Historical win rate', '${s.historicalWinRate!.toStringAsFixed(1)}%'),
          if (s.historicalSampleSize != null) _row('Historical sample size', '${s.historicalSampleSize}'),
          _row('Status', s.status.name.toUpperCase()),
          _row('Result', s.resultType.name.toUpperCase()),
          if (s.resultTimestamp != null) _row('Result timestamp', formatLocal(s.resultTimestamp!)),
          if (s.resultPrice != null) _row('Result price', s.resultPrice!.toStringAsFixed(5)),
          if (s.indicatorSnapshot.isNotEmpty)
            _row('Indicator values', s.indicatorSnapshot.entries.map((e) => '${e.key}=${e.value.toStringAsFixed(4)}').join(', ')),
          const SizedBox(height: 8),
          Text('Signal reasoning', style: Theme.of(context).textTheme.labelLarge?.copyWith(fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text(s.explanation.isEmpty ? '—' : s.explanation),
          if (s.isDemo) ...[
            const SizedBox(height: 16),
            const Text('DEMO DATA', style: TextStyle(fontWeight: FontWeight.w700)),
          ],
        ],
      ),
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(width: 150, child: Text(label, style: const TextStyle(fontWeight: FontWeight.w600))),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }
}
