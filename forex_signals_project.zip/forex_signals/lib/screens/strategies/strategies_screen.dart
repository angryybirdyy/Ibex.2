import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/strategy_meta.dart';
import '../../strategies/strategy_registry.dart';
import '../../state/strategy_settings_provider.dart';
import '../../widgets/settings_action_button.dart';
import 'strategy_detail_screen.dart';

/// The Strategies tab (spec sections 7–9). Every toggle here controls chart
/// *visibility only* — see `StrategySettingsProvider`'s doc comment for
/// where that separation from the Signal Engine is actually enforced.
class StrategiesScreen extends StatelessWidget {
  const StrategiesScreen({super.key});

  void _showAboutSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (context) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('About strategies', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            const Text(
              'Turning a strategy OFF here only hides its lines and markers from the '
              'USD/JPY and EUR/USD charts. Every strategy — on or off — keeps running in '
              'the background and keeps producing signals on the Signals tab, using real '
              'market data.',
            ),
            const SizedBox(height: 12),
            Text('How win rates are calculated', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 6),
            Text(StrategyMeta.winRateMethodology()),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<StrategySettingsProvider>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Strategies'),
        actions: [
          IconButton(
            icon: const Icon(Icons.info_outline),
            tooltip: 'About strategies',
            onPressed: () => _showAboutSheet(context),
          ),
          const SettingsActionButton(),
        ],
      ),
      body: !provider.isLoaded
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  child: Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(onPressed: provider.selectAll, child: const Text('Select all')),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: OutlinedButton(onPressed: provider.deselectAll, child: const Text('Deselect all')),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: OutlinedButton(onPressed: provider.resetToDefault, child: const Text('Reset')),
                      ),
                    ],
                  ),
                ),
                const Divider(height: 1),
                Expanded(
                  child: ListView.separated(
                    itemCount: StrategyRegistry.all.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (context, i) {
                      final strategy = StrategyRegistry.all[i];
                      final enabled = provider.isChartEnabled(strategy.id);
                      return ListTile(
                        title: Text(strategy.meta.name),
                        subtitle: Text(
                          strategy.meta.shortExplanation,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.info_outline),
                              tooltip: '${strategy.meta.name} info',
                              onPressed: () => Navigator.of(context).push(
                                MaterialPageRoute(builder: (_) => StrategyDetailScreen(strategy: strategy)),
                              ),
                            ),
                            Switch(
                              value: enabled,
                              onChanged: (v) => provider.setChartEnabled(strategy.id, v),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
    );
  }
}
