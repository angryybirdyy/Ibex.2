import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:provider/provider.dart';

import '../../backtesting/backtest_engine.dart';
import '../../core/enums.dart';
import '../../core/logger.dart';
import '../../core/market_types.dart';
import '../../models/app_settings.dart';
import '../../services/api_key_store.dart';
import '../../services/background_service.dart';
import '../../services/notification_service.dart';
import '../../state/app_services.dart';
import '../../state/settings_provider.dart';
import '../../strategies/strategy_registry.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _apiKeyController = TextEditingController();
  bool _apiKeyLoaded = false;
  String _version = '';
  bool _isRunningBacktests = false;

  @override
  void initState() {
    super.initState();
    ApiKeyStore.instance.getApiKey().then((key) {
      if (!mounted) return;
      setState(() {
        _apiKeyController.text = key ?? '';
        _apiKeyLoaded = true;
      });
    });
    PackageInfo.fromPlatform().then((info) {
      if (!mounted) return;
      setState(() => _version = '${info.version} (${info.buildNumber})');
    });
  }

  @override
  void dispose() {
    _apiKeyController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final settingsProvider = context.watch<SettingsProvider>();
    final settings = settingsProvider.settings;
    final appServices = context.read<AppServices>();

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        children: [
          _SectionHeader('Data source'),
          RadioListTile<DataMode>(
            title: const Text('Demo (synthetic data, no API key needed)'),
            value: DataMode.demo,
            groupValue: settings.dataMode,
            onChanged: (v) => settingsProvider.setDataMode(v!),
          ),
          RadioListTile<DataMode>(
            title: const Text('Live (Twelve Data)'),
            value: DataMode.live,
            groupValue: settings.dataMode,
            onChanged: (v) => settingsProvider.setDataMode(v!),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextField(
              controller: _apiKeyController,
              enabled: _apiKeyLoaded,
              obscureText: true,
              decoration: InputDecoration(
                labelText: 'Twelve Data API key',
                helperText: 'Stored in Android secure storage — never logged or shown elsewhere.',
                suffixIcon: IconButton(
                  icon: const Icon(Icons.save_outlined),
                  onPressed: () async {
                    await ApiKeyStore.instance.setApiKey(_apiKeyController.text.trim());
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('API key saved')));
                    }
                  },
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),

          _SectionHeader('Sync & background monitoring'),
          ListTile(
            title: const Text('Refresh interval'),
            subtitle: Text('${settings.refreshIntervalMinutes} minutes'),
            trailing: SizedBox(
              width: 160,
              child: Slider(
                value: settings.refreshIntervalMinutes.toDouble(),
                min: 1,
                max: 60,
                divisions: 59,
                onChanged: (v) => settingsProvider.setRefreshIntervalMinutes(v.round()),
              ),
            ),
          ),
          SwitchListTile(
            title: const Text('Background monitoring'),
            subtitle: const Text('Runs a foreground service so monitoring continues while the app is closed.'),
            value: settings.backgroundMonitoringEnabled,
            onChanged: (v) async {
              await settingsProvider.setBackgroundMonitoringEnabled(v);
              if (v) {
                await BackgroundService.start();
              } else {
                await BackgroundService.stop();
              }
            },
          ),
          ListTile(
            title: const Text('Ignore battery optimization'),
            subtitle: const Text('Recommended so the OS does not stop monitoring to save power.'),
            trailing: FilledButton(
              onPressed: () => BackgroundService.requestBatteryOptimizationExemption(),
              child: const Text('Request'),
            ),
          ),
          SwitchListTile(
            title: const Text('Notifications'),
            subtitle: const Text('Show a notification when a new signal is generated.'),
            value: settings.notificationsEnabled,
            onChanged: (v) async {
              await settingsProvider.setNotificationsEnabled(v);
              if (v) await NotificationService.instance.requestPermission();
            },
          ),
          ListTile(
            title: const Text('Background timeframes'),
            subtitle: Text(settings.backgroundTimeframeLabels.isEmpty
                ? 'None selected'
                : settings.backgroundTimeframeLabels.join(', ')),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Wrap(
              spacing: 6,
              children: Timeframe.values.map((t) {
                final selected = settings.backgroundTimeframeLabels.contains(t.label);
                return FilterChip(
                  label: Text(t.label),
                  selected: selected,
                  onSelected: (v) {
                    final labels = List<String>.from(settings.backgroundTimeframeLabels);
                    if (v) {
                      labels.add(t.label);
                    } else {
                      labels.remove(t.label);
                    }
                    settingsProvider.setBackgroundTimeframeLabels(labels);
                  },
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 8),

          _SectionHeader('Appearance'),
          SwitchListTile(
            title: const Text('Dark mode'),
            value: settings.darkMode,
            onChanged: settingsProvider.setDarkMode,
          ),
          ListTile(
            title: const Text('Default timeframe'),
            trailing: DropdownButton<String>(
              value: settings.defaultTimeframeLabel,
              items: Timeframe.values.map((t) => DropdownMenuItem(value: t.label, child: Text(t.label))).toList(),
              onChanged: (v) => settingsProvider.setDefaultTimeframeLabel(v!),
            ),
          ),

          _SectionHeader('Signal evaluation'),
          ListTile(
            title: const Text('Backtest period'),
            subtitle: Text('${settings.backtestMonths} months'),
            trailing: SizedBox(
              width: 160,
              child: Slider(
                value: settings.backtestMonths.toDouble(),
                min: 1,
                max: 24,
                divisions: 23,
                onChanged: (v) => settingsProvider.setBacktestMonths(v.round()),
              ),
            ),
          ),
          RadioListTile<TpSlMethod>(
            title: const Text('TP/SL: ATR multiple (adapts to volatility)'),
            value: TpSlMethod.atrMultiple,
            groupValue: settings.tpSlMethod,
            onChanged: (v) => settingsProvider.setTpSlMethod(v!),
          ),
          if (settings.tpSlMethod == TpSlMethod.atrMultiple)
            ListTile(
              title: const Text('ATR multiple'),
              subtitle: Text(settings.atrMultiple.toStringAsFixed(2)),
              trailing: SizedBox(
                width: 160,
                child: Slider(
                  value: settings.atrMultiple,
                  min: 0.5,
                  max: 4,
                  divisions: 35,
                  onChanged: settingsProvider.setAtrMultiple,
                ),
              ),
            ),
          RadioListTile<TpSlMethod>(
            title: const Text('TP/SL: fixed pips'),
            value: TpSlMethod.fixedPips,
            groupValue: settings.tpSlMethod,
            onChanged: (v) => settingsProvider.setTpSlMethod(v!),
          ),
          if (settings.tpSlMethod == TpSlMethod.fixedPips)
            ListTile(
              title: const Text('Fixed pips'),
              subtitle: Text(settings.fixedPips.toStringAsFixed(0)),
              trailing: SizedBox(
                width: 160,
                child: Slider(
                  value: settings.fixedPips,
                  min: 5,
                  max: 200,
                  divisions: 39,
                  onChanged: settingsProvider.setFixedPips,
                ),
              ),
            ),
          ListTile(
            title: const Text('Evaluation window'),
            subtitle: Text('${settings.evaluationWindowCandles} candles before a signal expires unresolved'),
            trailing: SizedBox(
              width: 160,
              child: Slider(
                value: settings.evaluationWindowCandles.toDouble(),
                min: 5,
                max: 200,
                divisions: 39,
                onChanged: (v) => settingsProvider.setEvaluationWindowCandles(v.round()),
              ),
            ),
          ),

          _SectionHeader('Database management'),
          ListTile(
            title: const Text('Recalculate all win rates'),
            subtitle: const Text('Runs a fresh backtest for every strategy, pair and timeframe using cached candles.'),
            trailing: _isRunningBacktests
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                : FilledButton(
                    onPressed: () => _recalculateAllBacktests(context, appServices, settings),
                    child: const Text('Run'),
                  ),
          ),
          ListTile(
            title: const Text('Export diagnostic logs'),
            trailing: OutlinedButton(
              onPressed: () => _showLogs(context),
              child: const Text('View'),
            ),
          ),

          _SectionHeader('About'),
          const ListTile(
            title: Text('Signal / analysis app only'),
            subtitle: Text('This app never places trades, connects to a broker, or moves money.'),
          ),
          ListTile(title: const Text('App version'), subtitle: Text(_version.isEmpty ? '…' : _version)),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Future<void> _recalculateAllBacktests(BuildContext context, AppServices appServices, AppSettings settings) async {
    setState(() => _isRunningBacktests = true);
    try {
      for (final pair in CurrencyPair.values) {
        for (final tf in Timeframe.values) {
          final series = await appServices.repository.getSeries(pair, tf);
          if (series.length < 100) continue;
          final results = await BacktestEngine.runAll(
            strategies: StrategyRegistry.all,
            pair: pair,
            timeframe: tf,
            fullHistory: series,
            tpSlMethod: settings.tpSlMethod,
            atrMultiple: settings.atrMultiple,
            fixedPips: settings.fixedPips,
            evaluationWindowCandles: settings.evaluationWindowCandles,
          );
          for (final r in results) {
            await appServices.backtestDao.save(r);
          }
        }
      }
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Backtests updated')));
      }
    } finally {
      if (mounted) setState(() => _isRunningBacktests = false);
    }
  }

  void _showLogs(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => DraggableScrollableSheet(
        expand: false,
        builder: (context, scrollController) => SingleChildScrollView(
          controller: scrollController,
          padding: const EdgeInsets.all(16),
          child: SelectableText(AppLogger.instance.exportDiagnostics()),
        ),
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader(this.title);
  final String title;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 4),
      child: Text(title, style: Theme.of(context).textTheme.labelLarge?.copyWith(fontWeight: FontWeight.w800)),
    );
  }
}
