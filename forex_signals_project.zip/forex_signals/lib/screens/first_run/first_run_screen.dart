import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/enums.dart';
import '../../services/api_key_store.dart';
import '../../services/background_service.dart';
import '../../services/notification_service.dart';
import '../../state/settings_provider.dart';
import '../root_shell.dart';

/// Minimal first-launch setup (spec section 49) — a handful of choices,
/// then straight into the four-tab interface. Nothing here is required:
/// every choice has a sensible default and can be changed later in
/// Settings, so a user in a hurry can just tap "Get started".
class FirstRunScreen extends StatefulWidget {
  const FirstRunScreen({super.key});

  @override
  State<FirstRunScreen> createState() => _FirstRunScreenState();
}

class _FirstRunScreenState extends State<FirstRunScreen> {
  DataMode _dataMode = DataMode.demo;
  final _apiKeyController = TextEditingController();
  int _refreshMinutes = 5;
  bool _notificationsEnabled = true;
  bool _backgroundEnabled = false;

  @override
  void dispose() {
    _apiKeyController.dispose();
    super.dispose();
  }

  Future<void> _finish() async {
    if (_dataMode == DataMode.live && _apiKeyController.text.trim().isNotEmpty) {
      await ApiKeyStore.instance.setApiKey(_apiKeyController.text.trim());
    }
    if (_notificationsEnabled) {
      await NotificationService.instance.requestPermission();
    }
    if (!mounted) return;
    final settingsProvider = context.read<SettingsProvider>();
    await settingsProvider.setDataMode(_dataMode);
    await settingsProvider.setRefreshIntervalMinutes(_refreshMinutes);
    await settingsProvider.setNotificationsEnabled(_notificationsEnabled);
    await settingsProvider.setBackgroundMonitoringEnabled(_backgroundEnabled);
    if (_backgroundEnabled) await BackgroundService.start();
    await settingsProvider.markFirstRunComplete();

    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const RootShell()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Welcome')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            'Forex Signals is a personal signal/analysis tool for USD/JPY and EUR/USD. '
            'It never places trades or connects to a broker.',
            style: Theme.of(context).textTheme.bodyLarge,
          ),
          const SizedBox(height: 24),
          Text('Data source', style: Theme.of(context).textTheme.titleMedium),
          RadioListTile<DataMode>(
            title: const Text('Demo (synthetic data — try it now, no key needed)'),
            value: DataMode.demo,
            groupValue: _dataMode,
            onChanged: (v) => setState(() => _dataMode = v!),
          ),
          RadioListTile<DataMode>(
            title: const Text('Live (Twelve Data)'),
            value: DataMode.live,
            groupValue: _dataMode,
            onChanged: (v) => setState(() => _dataMode = v!),
          ),
          if (_dataMode == DataMode.live)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: TextField(
                controller: _apiKeyController,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'Twelve Data API key',
                  helperText: 'You can also add this later in Settings.',
                ),
              ),
            ),
          const SizedBox(height: 16),
          Text('Refresh interval: $_refreshMinutes min', style: Theme.of(context).textTheme.titleMedium),
          Slider(
            value: _refreshMinutes.toDouble(),
            min: 1,
            max: 30,
            divisions: 29,
            onChanged: (v) => setState(() => _refreshMinutes = v.round()),
          ),
          SwitchListTile(
            title: const Text('Enable notifications'),
            value: _notificationsEnabled,
            onChanged: (v) => setState(() => _notificationsEnabled = v),
          ),
          SwitchListTile(
            title: const Text('Enable background monitoring now'),
            subtitle: const Text('You can turn this on later in Settings instead.'),
            value: _backgroundEnabled,
            onChanged: (v) => setState(() => _backgroundEnabled = v),
          ),
          const SizedBox(height: 24),
          FilledButton(
            onPressed: _finish,
            style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(48)),
            child: const Text('Get started'),
          ),
        ],
      ),
    );
  }
}
