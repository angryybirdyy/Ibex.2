import 'package:connectivity_plus/connectivity_plus.dart';

/// Wraps `connectivity_plus` behind a tiny interface so the repository and
/// background service don't depend on the package's exact API shape (which
/// has changed across major versions) in more than one place.
class ConnectivityService {
  ConnectivityService._();
  static final ConnectivityService instance = ConnectivityService._();

  final Connectivity _connectivity = Connectivity();

  /// Test-only seam: when set, [isOnline] returns this instead of touching
  /// the real `connectivity_plus` platform channel, which isn't available
  /// in a plain `flutter test` widget test. Production code never sets
  /// this — see `test/test_utils/connectivity_test_utils.dart`.
  static bool Function()? debugIsOnlineOverride;

  Future<bool> isOnline() async {
    final override = debugIsOnlineOverride;
    if (override != null) return override();
    final results = await _connectivity.checkConnectivity();
    return results.any((r) => r != ConnectivityResult.none);
  }

  Stream<bool> onConnectivityChanged() => _connectivity.onConnectivityChanged
      .map((results) => results.any((r) => r != ConnectivityResult.none));
}
