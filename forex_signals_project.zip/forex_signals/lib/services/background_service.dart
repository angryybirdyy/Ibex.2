import 'package:flutter_foreground_task/flutter_foreground_task.dart';

import '../core/enums.dart';
import '../core/logger.dart';
import '../core/market_types.dart';
import '../database/app_database.dart';
import '../database/backtest_dao.dart';
import '../database/candle_dao.dart';
import '../database/signal_dao.dart';
import '../database/strategy_settings_dao.dart';
import '../database/sync_state_dao.dart';
import '../data/market_data_repository.dart';
import '../data/provider_factory.dart';
import '../signals/signal_engine.dart';
import 'notification_service.dart';
import 'settings_repository.dart';

/// Wires `flutter_foreground_task` to the Signal Engine (spec section 3).
///
/// **A note on Android's real constraints, stated plainly rather than
/// glossed over:** Android does *not* guarantee unrestricted 24/7
/// background execution for any app. A foreground service with a visible,
/// ongoing notification — what this class starts — is the most reliable
/// Android-compliant mechanism available, and is what every serious
/// long-running Android app (fitness trackers, music players, delivery
/// trackers) uses for exactly this reason. But manufacturer-specific
/// battery management (Samsung, Xiaomi, Huawei, OnePlus and others all ship
/// extra, non-stock battery optimizers on top of Android's own Doze/App
/// Standby) can still kill a foreground service. `TROUBLESHOOTING.md`
/// documents the manufacturer-specific steps to whitelist the app; there is
/// no code-only fix for OEM battery managers that ignore standard Android
/// APIs.
///
/// **Package API note:** the exact `TaskHandler` method signatures below
/// match `flutter_foreground_task`'s published API at the time this project
/// was written. This is the single dependency most likely to publish a
/// breaking change to these signatures between when this was written and
/// when you run `flutter pub get`. If `flutter analyze` flags a signature
/// mismatch here, open the installed package's `lib/task_handler.dart`
/// (path printed by the analyzer error) and adjust the overrides to match —
/// see TROUBLESHOOTING.md.
class BackgroundService {
  BackgroundService._();

  static const int _serviceId = 4501;

  static Future<void> initialize() async {
    FlutterForegroundTask.init(
      androidNotificationOptions: AndroidNotificationOptions(
        channelId: 'forex_signals_monitor',
        channelName: 'Background Monitoring',
        channelDescription: 'Shows that USD/JPY and EUR/USD monitoring is active.',
        onlyAlertOnce: true,
      ),
      iosNotificationOptions: const IOSNotificationOptions(showNotification: false),
      foregroundTaskOptions: ForegroundTaskOptions(
        eventAction: ForegroundTaskEventAction.repeat(60000),
        autoRunOnBoot: true,
        autoRunOnMyPackageReplaced: true,
        allowWakeLock: true,
        allowWifiLock: true,
      ),
    );
  }

  static Future<bool> isRunning() => FlutterForegroundTask.isRunningService;

  static Future<void> start() async {
    if (await isRunning()) return;
    await FlutterForegroundTask.startService(
      serviceId: _serviceId,
      notificationTitle: 'Forex signal monitoring',
      notificationText: 'Starting…',
      callback: _startCallback,
    );
  }

  static Future<void> stop() async {
    await FlutterForegroundTask.stopService();
  }

  static Future<void> requestBatteryOptimizationExemption() async {
    final isIgnoring = await FlutterForegroundTask.isIgnoringBatteryOptimizations;
    if (!isIgnoring) {
      await FlutterForegroundTask.requestIgnoreBatteryOptimizations();
    }
  }
}

/// Entry point the Android service isolate calls into. Must be a top-level
/// (or static) function annotated `@pragma('vm:entry-point')` so the
/// Flutter engine can find it when the OS restarts the service outside of
/// the normal app launch path (spec section 3: "resume monitoring after the
/// phone restarts").
@pragma('vm:entry-point')
void _startCallback() {
  FlutterForegroundTask.setTaskHandler(SignalMonitoringTaskHandler());
}

/// Runs one full [SignalEngine] cycle per `onRepeatEvent` tick. Executes in
/// a background isolate — every dependency it needs (database, DAOs,
/// engine) is constructed fresh in [onStart] rather than reused from the
/// main isolate, since isolates don't share memory.
class SignalMonitoringTaskHandler extends TaskHandler {
  SignalEngine? _engine;
  CandleDao? _candleDao;
  int _consecutiveFailures = 0;

  @override
  Future<void> onStart(DateTime timestamp, TaskStarter starter) async {
    AppLogger.instance.info('BackgroundService', 'Started (trigger: ${starter.name}).');
    final appDb = await AppDatabase.open();
    final candleDao = CandleDao(appDb);
    final signalDao = SignalDao(appDb);
    final backtestDao = BacktestDao(appDb);
    final strategySettingsDao = StrategySettingsDao(appDb);
    final syncStateDao = SyncStateDao(appDb);

    final settings = await SettingsRepository.instance.load();
    final repository = MarketDataRepository(
      candleDao: candleDao,
      syncStateDao: syncStateDao,
      providerGetter: () => ProviderFactory.create(settings.dataMode),
    );

    _candleDao = candleDao;
    _engine = SignalEngine(
      getSeries: (pair, tf, {limit = 300}) => repository.getSeries(pair, tf, limit: limit),
      syncPairTimeframe: (pair, tf, {outputSize = 300}) =>
          repository.syncPairTimeframe(pair, tf, outputSize: outputSize),
      candleDao: candleDao,
      signalDao: signalDao,
      backtestDao: backtestDao,
      strategySettingsDao: strategySettingsDao,
      getSettings: () => settings,
    );

    await NotificationService.instance.initialize();
  }

  @override
  Future<void> onRepeatEvent(DateTime timestamp) async {
    final engine = _engine;
    if (engine == null) return;

    final settings = await SettingsRepository.instance.load();
    final timeframes = Timeframe.values.where((t) => settings.backgroundTimeframeLabels.contains(t.label));

    var anySuccess = false;
    var anyFailure = false;
    String? lastError;

    for (final pair in CurrencyPair.values) {
      for (final tf in timeframes) {
        try {
          final summary = await engine.runCycle(pair, tf);
          if (summary.syncFailure == null) {
            anySuccess = true;
          } else {
            anyFailure = true;
            lastError = summary.syncFailure!.friendlyMessage;
          }
          if (settings.notificationsEnabled) {
            for (final signal in summary.newlyCreated) {
              await NotificationService.instance.showSignalNotification(signal);
            }
          }
        } catch (e, st) {
          anyFailure = true;
          lastError = 'Unexpected error';
          AppLogger.instance.error('BackgroundService', 'Cycle failed for ${pair.code} ${tf.label}', e, st);
        }
      }
    }

    _consecutiveFailures = anySuccess ? 0 : _consecutiveFailures + 1;
    final status = anySuccess
        ? ServiceStatus.monitoring
        : (anyFailure && _consecutiveFailures >= 2 ? ServiceStatus.error : ServiceStatus.offline);

    final nowUtc = DateTime.now().toUtc();
    await FlutterForegroundTask.updateService(
      notificationTitle: 'Forex signal monitoring — ${status.label}',
      notificationText: anySuccess
          ? 'Last update: ${nowUtc.toLocal()}'
          : (lastError ?? 'Waiting for connection…'),
    );
    FlutterForegroundTask.sendDataToMain({
      'status': status.name,
      'lastUpdateUtc': nowUtc.toIso8601String(),
      if (lastError != null) 'error': lastError,
    });
  }

  @override
  Future<void> onDestroy(DateTime timestamp, bool isTimeout) async {
    AppLogger.instance.info('BackgroundService', 'Stopped (timeout: $isTimeout).');
  }

  @override
  void onNotificationButtonPressed(String id) {}

  @override
  void onNotificationPressed() {
    FlutterForegroundTask.launchApp('/');
  }

  @override
  void onNotificationDismissed() {}
}
