import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// The *only* place the live-data API key is read or written (spec sections
/// 29/32). Backed by Android Keystore-encrypted SharedPreferences via
/// `flutter_secure_storage` — never plain SharedPreferences, never a plain
/// file, and never included in `AppSettings` (which is logged/exported far
/// more casually than this is).
class ApiKeyStore {
  ApiKeyStore._();
  static final ApiKeyStore instance = ApiKeyStore._();

  static const _key = 'twelve_data_api_key';

  final FlutterSecureStorage _storage = const FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  Future<String?> getApiKey() => _storage.read(key: _key);

  Future<void> setApiKey(String value) => _storage.write(key: _key, value: value);

  Future<void> clearApiKey() => _storage.delete(key: _key);

  Future<bool> hasApiKey() async {
    final v = await getApiKey();
    return v != null && v.isNotEmpty;
  }
}
