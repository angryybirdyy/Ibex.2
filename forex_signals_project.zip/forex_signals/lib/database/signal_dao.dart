import 'package:sqflite/sqflite.dart';

import '../core/enums.dart';
import '../models/signal.dart';
import 'app_database.dart';

class SignalDao {
  SignalDao(this._appDb);
  final AppDatabase _appDb;

  /// Inserts [signal] unless a row with the same `id` already exists.
  /// [Signal.id] is the deterministic identity built by
  /// `core/id_utils.dart#buildSignalIdentity`, so this single
  /// insert-or-ignore call *is* the deduplication mechanism (spec section
  /// 16) — no separate "does this already exist?" query is needed, which
  /// also avoids a race between checking and inserting.
  ///
  /// Returns `true` if a new row was actually inserted.
  Future<bool> insertIfNew(Signal signal) async {
    final rowId = await _appDb.db.insert(
      'signals',
      signal.toMap(),
      conflictAlgorithm: ConflictAlgorithm.ignore,
    );
    return rowId != 0;
  }

  Future<Signal?> getById(String id) async {
    final rows = await _appDb.db.query('signals', where: 'id = ?', whereArgs: [id], limit: 1);
    if (rows.isEmpty) return null;
    return Signal.fromMap(rows.first);
  }

  Future<void> update(Signal signal) async {
    await _appDb.db.update('signals', signal.toMap(), where: 'id = ?', whereArgs: [signal.id]);
  }

  Future<List<Signal>> getActive({String? pair, String? timeframe}) async {
    final where = StringBuffer("status = 'active'");
    final args = <Object?>[];
    if (pair != null) {
      where.write(' AND pair = ?');
      args.add(pair);
    }
    if (timeframe != null) {
      where.write(' AND timeframe = ?');
      args.add(timeframe);
    }
    final rows = await _appDb.db.query('signals', where: where.toString(), whereArgs: args, orderBy: 'created_at DESC');
    return rows.map(Signal.fromMap).toList();
  }

  /// Flexible, filtered query for both the Current and History pages (spec
  /// section 15: sortable/filterable by pair, strategy, direction,
  /// timeframe, win/loss, date).
  Future<List<Signal>> query({
    String? pair,
    String? timeframe,
    String? strategyId,
    SignalDirection? direction,
    SignalStatus? status,
    SignalResultType? resultType,
    DateTime? fromUtc,
    DateTime? toUtc,
    String orderBy = 'created_at DESC',
    int? limit,
  }) async {
    final where = <String>[];
    final args = <Object?>[];
    if (pair != null) {
      where.add('pair = ?');
      args.add(pair);
    }
    if (timeframe != null) {
      where.add('timeframe = ?');
      args.add(timeframe);
    }
    if (strategyId != null) {
      where.add('strategy_id = ?');
      args.add(strategyId);
    }
    if (direction != null) {
      where.add('direction = ?');
      args.add(direction.name);
    }
    if (status != null) {
      where.add('status = ?');
      args.add(status.name);
    }
    if (resultType != null) {
      where.add('result_type = ?');
      args.add(resultType.name);
    }
    if (fromUtc != null) {
      where.add('created_at >= ?');
      args.add(fromUtc.toIso8601String());
    }
    if (toUtc != null) {
      where.add('created_at <= ?');
      args.add(toUtc.toIso8601String());
    }
    final rows = await _appDb.db.query(
      'signals',
      where: where.isEmpty ? null : where.join(' AND '),
      whereArgs: where.isEmpty ? null : args,
      orderBy: orderBy,
      limit: limit,
    );
    return rows.map(Signal.fromMap).toList();
  }

  Future<int> countAll() async {
    final result = await _appDb.db.rawQuery('SELECT COUNT(*) AS c FROM signals');
    return Sqflite.firstIntValue(result) ?? 0;
  }
}
