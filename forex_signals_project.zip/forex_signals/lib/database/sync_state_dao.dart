import 'package:sqflite/sqflite.dart';

import '../core/time_utils.dart';
import 'app_database.dart';

class SyncState {
  const SyncState({this.lastSyncedAt, this.lastCandleTs, this.lastError});
  final DateTime? lastSyncedAt;
  final DateTime? lastCandleTs;
  final String? lastError;
}

/// Tracks "last successful market-data update time" per pair/timeframe
/// (spec section 3: "Clearly show the last successful market-data update
/// time"), plus the most recent error so the UI can explain *why* data is
/// stale without the user needing to dig through logs.
class SyncStateDao {
  SyncStateDao(this._appDb);
  final AppDatabase _appDb;

  Future<void> recordSuccess(String pair, String timeframe, {required DateTime syncedAtUtc, DateTime? latestCandleUtc}) async {
    await _appDb.db.insert(
      'sync_state',
      {
        'pair': pair,
        'timeframe': timeframe,
        'last_synced_at': toStorageString(syncedAtUtc),
        'last_candle_ts': latestCandleUtc == null ? null : toStorageString(latestCandleUtc),
        'last_error': null,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> recordError(String pair, String timeframe, String error) async {
    final existing = await get(pair, timeframe);
    await _appDb.db.insert(
      'sync_state',
      {
        'pair': pair,
        'timeframe': timeframe,
        'last_synced_at': existing.lastSyncedAt == null ? null : toStorageString(existing.lastSyncedAt!),
        'last_candle_ts': existing.lastCandleTs == null ? null : toStorageString(existing.lastCandleTs!),
        'last_error': error,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<SyncState> get(String pair, String timeframe) async {
    final rows = await _appDb.db.query('sync_state', where: 'pair = ? AND timeframe = ?', whereArgs: [pair, timeframe]);
    if (rows.isEmpty) return const SyncState();
    final r = rows.first;
    return SyncState(
      lastSyncedAt: r['last_synced_at'] == null ? null : fromStorageString(r['last_synced_at'] as String),
      lastCandleTs: r['last_candle_ts'] == null ? null : fromStorageString(r['last_candle_ts'] as String),
      lastError: r['last_error'] as String?,
    );
  }
}
