import '../models/backtest_result.dart';
import 'app_database.dart';

class BacktestDao {
  BacktestDao(this._appDb);
  final AppDatabase _appDb;

  /// Backtest runs are keyed by (strategy, pair, timeframe, start, end), so
  /// re-running the same configuration overwrites the previous result
  /// instead of accumulating duplicates.
  Future<void> save(BacktestResult result) async {
    await _appDb.db.insert('backtest_results', result.toMap());
  }

  Future<Map<String, Object?>?> latestFor(String strategyId, String pair, String timeframe) async {
    final rows = await _appDb.db.query(
      'backtest_results',
      where: 'strategy_id = ? AND pair = ? AND timeframe = ?',
      whereArgs: [strategyId, pair, timeframe],
      orderBy: 'computed_at DESC',
      limit: 1,
    );
    return rows.isEmpty ? null : rows.first;
  }

  Future<List<Map<String, Object?>>> allFor(String pair, String timeframe) async {
    return _appDb.db.query(
      'backtest_results',
      where: 'pair = ? AND timeframe = ?',
      whereArgs: [pair, timeframe],
      orderBy: 'strategy_id ASC',
    );
  }
}
