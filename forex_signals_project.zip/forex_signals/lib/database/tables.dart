/// Schema for the local SQLite database (spec section 19).
///
/// Design note (documented in ARCHITECTURE.md): structured, queryable,
/// growing data — candles, signals, backtests, strategy settings, sync
/// state — lives here in SQLite, where indexes make range/filter queries
/// fast. Simple scalar app preferences (dark mode, refresh interval, etc.)
/// live in SharedPreferences via `models/app_settings.dart` instead — both
/// are "persistent local storage", the split is about using the right tool
/// for each shape of data, not a shortcut.
library;

const int dbVersion = 1;
const String dbFileName = 'forex_signals.db';

const String createCandlesTable = '''
CREATE TABLE candles (
  pair TEXT NOT NULL,
  timeframe TEXT NOT NULL,
  ts TEXT NOT NULL,
  open REAL NOT NULL,
  high REAL NOT NULL,
  low REAL NOT NULL,
  close REAL NOT NULL,
  volume REAL NOT NULL DEFAULT 0,
  is_demo INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (pair, timeframe, ts)
)
''';

const String createCandlesIndex = '''
CREATE INDEX idx_candles_lookup ON candles (pair, timeframe, ts DESC)
''';

const String createSignalsTable = '''
CREATE TABLE signals (
  id TEXT PRIMARY KEY,
  pair TEXT NOT NULL,
  timeframe TEXT NOT NULL,
  strategy_id TEXT NOT NULL,
  direction TEXT NOT NULL,
  candle_ts TEXT NOT NULL,
  entry_price REAL NOT NULL,
  created_at TEXT NOT NULL,
  target_price REAL,
  stop_loss_price REAL,
  hist_win_rate REAL,
  hist_sample_size INTEGER,
  status TEXT NOT NULL,
  result_type TEXT NOT NULL,
  result_ts TEXT,
  result_price REAL,
  explanation TEXT NOT NULL DEFAULT '',
  indicator_snapshot_json TEXT,
  is_demo INTEGER NOT NULL DEFAULT 0
)
''';

// sqflite/Android SQLite only runs one statement per db.execute() call, so
// multi-index groups are kept as a list of individual statements rather
// than one semicolon-joined string.
const List<String> createSignalsIndexList = [
  'CREATE INDEX idx_signals_status ON signals (status)',
  'CREATE INDEX idx_signals_pair_tf ON signals (pair, timeframe)',
  'CREATE INDEX idx_signals_strategy ON signals (strategy_id)',
  'CREATE INDEX idx_signals_created ON signals (created_at DESC)',
];

const String createBacktestResultsTable = '''
CREATE TABLE backtest_results (
  run_id TEXT PRIMARY KEY,
  strategy_id TEXT NOT NULL,
  pair TEXT NOT NULL,
  timeframe TEXT NOT NULL,
  start_date TEXT NOT NULL,
  end_date TEXT NOT NULL,
  total_trades INTEGER NOT NULL,
  winning_trades INTEGER NOT NULL,
  losing_trades INTEGER NOT NULL,
  unresolved_trades INTEGER NOT NULL,
  win_rate REAL,
  profit_factor REAL,
  avg_return REAL,
  max_drawdown REAL,
  avg_win REAL,
  avg_loss REAL,
  computed_at TEXT NOT NULL
)
''';

const String createBacktestIndex = '''
CREATE INDEX idx_backtest_lookup ON backtest_results (strategy_id, pair, timeframe, computed_at DESC)
''';

const String createStrategySelectionTable = '''
CREATE TABLE strategy_selection (
  strategy_id TEXT PRIMARY KEY,
  chart_enabled INTEGER NOT NULL DEFAULT 1
)
''';

const String createStrategyParamsTable = '''
CREATE TABLE strategy_params (
  strategy_id TEXT NOT NULL,
  param_key TEXT NOT NULL,
  value REAL NOT NULL,
  PRIMARY KEY (strategy_id, param_key)
)
''';

const String createSyncStateTable = '''
CREATE TABLE sync_state (
  pair TEXT NOT NULL,
  timeframe TEXT NOT NULL,
  last_synced_at TEXT,
  last_candle_ts TEXT,
  last_error TEXT,
  PRIMARY KEY (pair, timeframe)
)
''';

final List<String> allCreateStatements = [
  createCandlesTable,
  createCandlesIndex,
  createSignalsTable,
  ...createSignalsIndexList,
  createBacktestResultsTable,
  createBacktestIndex,
  createStrategySelectionTable,
  createStrategyParamsTable,
  createSyncStateTable,
];
