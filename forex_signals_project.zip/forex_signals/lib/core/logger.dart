import 'dart:collection';

/// Severity for a log line. Kept intentionally small.
enum LogLevel { debug, info, warn, error }

class LogEntry {
  LogEntry(this.time, this.level, this.tag, this.message);
  final DateTime time; // UTC
  final LogLevel level;
  final String tag;
  final String message;

  @override
  String toString() {
    final lvl = level.name.toUpperCase().padRight(5);
    return '${time.toIso8601String()} $lvl [$tag] $message';
  }
}

/// App-wide logger (spec section 36).
///
/// - Never logs API keys or other secrets: callers must pre-redact before
///   calling [warn]/[error]/[info] — this class does not attempt to scan
///   free-text messages for secrets, since that would give a false sense of
///   safety. `data/twelve_data_provider.dart` redacts the `apikey` query
///   parameter before ever constructing a log message.
/// - Keeps a bounded in-memory ring buffer so [exportDiagnostics] can dump
///   recent history without unbounded memory growth over a long-running
///   background service.
class AppLogger {
  AppLogger._();
  static final AppLogger instance = AppLogger._();

  static const int _maxEntries = 2000;
  final Queue<LogEntry> _buffer = ListQueue<LogEntry>(_maxEntries);

  void _log(LogLevel level, String tag, String message) {
    final entry = LogEntry(DateTime.now().toUtc(), level, tag, message);
    _buffer.addLast(entry);
    while (_buffer.length > _maxEntries) {
      _buffer.removeFirst();
    }
    // ignore: avoid_print
    print(entry.toString());
  }

  void debug(String tag, String message) => _log(LogLevel.debug, tag, message);
  void info(String tag, String message) => _log(LogLevel.info, tag, message);
  void warn(String tag, String message) => _log(LogLevel.warn, tag, message);
  void error(String tag, String message, [Object? err, StackTrace? st]) {
    final full = err == null ? message : '$message | $err';
    _log(LogLevel.error, tag, full);
    if (st != null) {
      // ignore: avoid_print
      print(st);
    }
  }

  /// Returns the buffered log as a single plain-text blob, newest last.
  /// Used by Settings > "Export diagnostic logs".
  String exportDiagnostics() => _buffer.map((e) => e.toString()).join('\n');

  void clear() => _buffer.clear();
}
