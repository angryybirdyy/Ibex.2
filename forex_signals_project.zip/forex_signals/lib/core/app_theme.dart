import 'package:flutter/material.dart';

/// Colors and [ThemeData] for a professional, TradingView-style dark
/// interface (spec section 2/27: "not a generic beginner demo"). Dark is
/// the default; [lightTheme] exists for the Settings > appearance toggle
/// but every screen is designed dark-first.
class AppColors {
  AppColors._();

  // Dark palette
  static const Color darkBackground = Color(0xFF0B0E14);
  static const Color darkSurface = Color(0xFF131722);
  static const Color darkSurfaceRaised = Color(0xFF1B2130);
  static const Color darkBorder = Color(0xFF262B3A);
  static const Color darkTextPrimary = Color(0xFFE7EAF0);
  static const Color darkTextSecondary = Color(0xFF8A93A6);

  // Light palette
  static const Color lightBackground = Color(0xFFF4F5F8);
  static const Color lightSurface = Color(0xFFFFFFFF);
  static const Color lightBorder = Color(0xFFDDE1EA);
  static const Color lightTextPrimary = Color(0xFF11131A);
  static const Color lightTextSecondary = Color(0xFF5C6273);

  // Shared semantic colors (financial convention: teal/green up, red down).
  static const Color bullish = Color(0xFF22C55E);
  static const Color bearish = Color(0xFFEF4444);
  static const Color neutral = Color(0xFF9AA3B2);
  static const Color accent = Color(0xFF3EA6FF);
  static const Color warning = Color(0xFFF5A524);

  static const Color win = Color(0xFF22C55E);
  static const Color loss = Color(0xFFEF4444);
  static const Color expired = Color(0xFF9AA3B2);
  static const Color active = Color(0xFF3EA6FF);

  // A small fixed palette for chart overlay lines, cycled through when
  // multiple strategy overlays are visible at once.
  static const List<Color> overlaySeries = [
    Color(0xFF3EA6FF),
    Color(0xFFF5A524),
    Color(0xFFC084FC),
    Color(0xFF22C55E),
    Color(0xFFEF4444),
    Color(0xFF2DD4BF),
  ];
}

class AppTheme {
  AppTheme._();

  static ThemeData get darkTheme {
    const scheme = ColorScheme.dark(
      primary: AppColors.accent,
      secondary: AppColors.accent,
      surface: AppColors.darkSurface,
      error: AppColors.bearish,
    );
    return _base(scheme, AppColors.darkBackground, AppColors.darkSurface, AppColors.darkBorder,
        AppColors.darkTextPrimary, AppColors.darkTextSecondary);
  }

  static ThemeData get lightTheme {
    const scheme = ColorScheme.light(
      primary: AppColors.accent,
      secondary: AppColors.accent,
      surface: AppColors.lightSurface,
      error: AppColors.bearish,
    );
    return _base(scheme, AppColors.lightBackground, AppColors.lightSurface, AppColors.lightBorder,
        AppColors.lightTextPrimary, AppColors.lightTextSecondary);
  }

  static ThemeData _base(
    ColorScheme scheme,
    Color background,
    Color surface,
    Color border,
    Color textPrimary,
    Color textSecondary,
  ) {
    final base = ThemeData(useMaterial3: true, colorScheme: scheme, scaffoldBackgroundColor: background);
    return base.copyWith(
      textTheme: base.textTheme
          .apply(bodyColor: textPrimary, displayColor: textPrimary)
          .copyWith(
            bodySmall: base.textTheme.bodySmall?.copyWith(color: textSecondary),
            labelSmall: base.textTheme.labelSmall?.copyWith(color: textSecondary),
          ),
      appBarTheme: AppBarTheme(
        backgroundColor: background,
        foregroundColor: textPrimary,
        elevation: 0,
        centerTitle: false,
      ),
      cardTheme: CardThemeData(
        color: surface,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: border),
        ),
      ),
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: surface,
        selectedItemColor: AppColors.accent,
        unselectedItemColor: textSecondary,
        type: BottomNavigationBarType.fixed,
        showUnselectedLabels: true,
      ),
      dividerTheme: DividerThemeData(color: border, space: 1),
      chipTheme: base.chipTheme.copyWith(
        backgroundColor: surface,
        side: BorderSide(color: border),
        labelStyle: TextStyle(color: textPrimary, fontSize: 12),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith(
            (states) => states.contains(WidgetState.selected) ? AppColors.accent : textSecondary),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surface,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: border)),
      ),
    );
  }
}
