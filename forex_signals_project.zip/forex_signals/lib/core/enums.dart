/// Shared enums used across the strategy engine, signal store and UI.
library;

/// Raw output of a single strategy evaluation. Strategies never emit
/// anything else — the Signal Engine is what decides whether a `buy`/`sell`
/// becomes a stored [SignalDirection].
enum StrategyDirection { buy, sell, neutral }

/// Direction of a *stored* signal. Unlike [StrategyDirection], there is no
/// `neutral` value here: a neutral strategy result never creates a signal
/// record in the first place (see `signals/signal_engine.dart`).
enum SignalDirection { buy, sell }

/// Lifecycle state of a stored signal.
enum SignalStatus {
  /// Still within its evaluation window; neither TP nor SL has been hit.
  active,

  /// TP or SL was reached; see [SignalResultType] for which one.
  resolved,

  /// The evaluation window elapsed before TP or SL was reached.
  expired,
}

/// Final outcome of a resolved signal. `unresolved` mirrors
/// [SignalStatus.expired] but is kept as a separate enum because a signal's
/// *status* and its *result* are conceptually different columns (a caller
/// asking "did this win?" wants [SignalResultType], not [SignalStatus]).
enum SignalResultType { win, loss, unresolved, pending }

/// How a strategy's take-profit / stop-loss levels are computed. Configurable
/// per strategy-run in Settings; see `backtesting/tpsl_rules.dart`.
enum TpSlMethod {
  /// TP/SL are a fixed multiple of ATR(14) at signal time. Default — adapts
  /// to each pair's current volatility rather than using a fixed pip count.
  atrMultiple,

  /// TP/SL are a fixed number of pips from entry.
  fixedPips,
}

/// Whether the app is fetching real broker-grade data or generated demo
/// data. Every screen that renders a price or signal must show this,
/// unlabelled DEMO data is never allowed to look like the real thing.
enum DataMode { demo, live }

/// Status of the background monitoring service, shown as the small
/// indicator required by the spec.
enum ServiceStatus { live, monitoring, paused, offline, error }

extension ServiceStatusX on ServiceStatus {
  String get label => switch (this) {
        ServiceStatus.live => 'LIVE',
        ServiceStatus.monitoring => 'MONITORING',
        ServiceStatus.paused => 'PAUSED',
        ServiceStatus.offline => 'OFFLINE',
        ServiceStatus.error => 'ERROR',
      };
}
