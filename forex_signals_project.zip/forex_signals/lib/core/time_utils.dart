/// Time handling rules for the whole app (spec section 31):
///  - Every timestamp is stored as UTC (ISO-8601, e.g. `2026-09-28T15:15:00Z`).
///  - Every timestamp shown to the user is converted to local time at the
///    point of display, never before.
///  - Candle timestamps are always bucketed to the *start* of the candle.
library;

/// Converts a UTC [DateTime] to the canonical storage string. Throws if
/// [dt] is not UTC, to catch accidental local-time leaks into the database
/// at the source rather than downstream.
String toStorageString(DateTime dt) {
  if (!dt.isUtc) {
    throw ArgumentError.value(dt, 'dt', 'Must be UTC before storage');
  }
  return dt.toIso8601String();
}

DateTime fromStorageString(String s) => DateTime.parse(s).toUtc();

/// Formats a UTC instant as local time for on-screen display, e.g.
/// `2026-09-28 15:15` (24h, no timezone-package dependency needed since we
/// only ever show *this device's* local time).
String formatLocal(DateTime utc, {bool withSeconds = false}) {
  final local = utc.toLocal();
  final y = local.year.toString().padLeft(4, '0');
  final mo = local.month.toString().padLeft(2, '0');
  final d = local.day.toString().padLeft(2, '0');
  final h = local.hour.toString().padLeft(2, '0');
  final mi = local.minute.toString().padLeft(2, '0');
  if (!withSeconds) return '$y-$mo-$d $h:$mi';
  final s = local.second.toString().padLeft(2, '0');
  return '$y-$mo-$d $h:$mi:$s';
}

/// Formats just the local time-of-day, e.g. `15:15`, for compact chart axes.
String formatLocalTime(DateTime utc) {
  final local = utc.toLocal();
  final h = local.hour.toString().padLeft(2, '0');
  final mi = local.minute.toString().padLeft(2, '0');
  return '$h:$mi';
}

/// Rounds [instant] (UTC) down to the start of the candle it belongs to for
/// a given interval length in minutes. Used both when caching freshly
/// fetched candles and when the background engine decides which candle
/// "now" falls into for dedup purposes.
DateTime floorToCandle(DateTime instant, int intervalMinutes) {
  final utc = instant.toUtc();
  final totalMinutes = utc.hour * 60 + utc.minute;
  final flooredTotal = (totalMinutes ~/ intervalMinutes) * intervalMinutes;
  final dayStart = DateTime.utc(utc.year, utc.month, utc.day);
  return dayStart.add(Duration(minutes: flooredTotal));
}

/// A human string like "2h 14m" for signal age, used in the Signals screen.
String formatDuration(Duration d) {
  if (d.inDays > 0) {
    final h = d.inHours % 24;
    return '${d.inDays}d ${h}h';
  }
  if (d.inHours > 0) {
    final m = d.inMinutes % 60;
    return '${d.inHours}h ${m}m';
  }
  if (d.inMinutes > 0) return '${d.inMinutes}m';
  return '${d.inSeconds}s';
}
