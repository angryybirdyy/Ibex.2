#!/usr/bin/env bash
# Runs the same sequence as .github/workflows/build_and_test.yml, on your
# own machine. Run from the project root: bash tool/verify_build.sh
#
# Stops at the first failure (set -e) so you always see the first real
# problem rather than a wall of cascading errors from later steps.
set -euo pipefail

echo "== flutter pub get =="
flutter pub get

echo "== flutter analyze =="
flutter analyze --no-fatal-infos

echo "== flutter test =="
flutter test

echo "== flutter test integration_test =="
flutter test integration_test

echo "== flutter build apk --debug =="
flutter build apk --debug

echo "== flutter build apk --release =="
flutter build apk --release

echo
echo "All checks passed."
echo "Debug APK:   build/app/outputs/flutter-apk/app-debug.apk"
echo "Release APK: build/app/outputs/flutter-apk/app-release.apk"
