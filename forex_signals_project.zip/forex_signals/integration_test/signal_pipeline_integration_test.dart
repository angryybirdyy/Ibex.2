// Exercises MarketDataRepository + SignalEngine + the real SQLite-backed
// DAOs together (spec section 34: "integration tests for market-data
// synchronization, signal generation pipeline, database persistence").
// Uses the deterministic DemoDataProvider so this needs no network and no
// emulator, and runs under plain `flutter test integration_test/`.
import 'package:flutter_test/flutter_test.dart';
import 'package:forex_signals/core/market_types.dart';
import 'package:forex_signals/data/demo_data_provider.dart';
import 'package:forex_signals/data/market_data_repository.dart';
import 'package:forex_signals/database/backtest_dao.dart';
import 'package:forex_signals/database/candle_dao.dart';
import 'package:forex_signals/database/signal_dao.dart';
import 'package:forex_signals/database/strategy_settings_dao.dart';
import 'package:forex_signals/database/sync_state_dao.dart';
import 'package:forex_signals/models/app_settings.dart';
import 'package:forex_signals/signals/signal_engine.dart';

import '../test/test_utils/db_test_utils.dart';

void main() {
  setUpAll(initTestDatabaseFactory);

  test('a full sync + signal cycle stores candles, creates signals once, and stays stable on replay', () async {
    final db = await openInMemoryTestDatabase();
    final candleDao = CandleDao(db);
    final signalDao = SignalDao(db);
    final backtestDao = BacktestDao(db);
    final strategySettingsDao = StrategySettingsDao(db);
    final syncStateDao = SyncStateDao(db);

    final demoProvider = DemoDataProvider();
    final repository = MarketDataRepository(
      candleDao: candleDao,
      syncStateDao: syncStateDao,
      providerGetter: () => demoProvider,
    );

    const settings = AppSettings(); // defaults: demo mode, ATR TP/SL, etc.
    final engine = SignalEngine(
      getSeries: (pair, tf, {limit = 300}) => repository.getSeries(pair, tf, limit: limit),
      syncPairTimeframe: (pair, tf, {outputSize = 300}) => repository.syncPairTimeframe(pair, tf, outputSize: outputSize),
      candleDao: candleDao,
      signalDao: signalDao,
      backtestDao: backtestDao,
      strategySettingsDao: strategySettingsDao,
      getSettings: () => settings,
    );

    // --- Market-data synchronization + persistence
    final firstSummary = await engine.runCycle(CurrencyPair.eurUsd, Timeframe.h1, candleLookback: 300);
    expect(firstSummary.syncFailure, isNull, reason: 'the demo provider must never fail a sync');
    final storedCandles = await candleDao.getCandles('EURUSD', '1H');
    expect(storedCandles.length, 300);
    expect(storedCandles.candles.every((c) => c.isDemo), isTrue);

    // --- Signal generation pipeline: every stored signal really is in the DB.
    final allSignalsAfterFirst = await signalDao.query();
    expect(allSignalsAfterFirst.length, firstSummary.newlyCreated.length);
    for (final s in firstSummary.newlyCreated) {
      expect(s.pairCode, 'EURUSD');
      expect(s.timeframeLabel, '1H');
    }

    // --- Replaying the exact same cycle must not duplicate signals: the
    // demo provider is deterministic for a fixed "now", but in case the
    // clock ticked into a new candle between the two calls, newlyCreated on
    // replay must only ever contain NEW events, never a re-creation of an
    // id already in the database.
    final secondSummary = await engine.runCycle(CurrencyPair.eurUsd, Timeframe.h1, candleLookback: 300);
    final allSignalsAfterSecond = await signalDao.query();
    expect(allSignalsAfterSecond.length, allSignalsAfterFirst.length + secondSummary.newlyCreated.length);
    final idsAfterFirst = allSignalsAfterFirst.map((s) => s.id).toSet();
    for (final s in secondSummary.newlyCreated) {
      expect(idsAfterFirst.contains(s.id), isFalse, reason: 'a "new" signal must never reuse an existing id');
    }
  });

  test('USD/JPY and EUR/USD signal streams never collide', () async {
    final db = await openInMemoryTestDatabase();
    final candleDao = CandleDao(db);
    final signalDao = SignalDao(db);
    final repository = MarketDataRepository(
      candleDao: candleDao,
      syncStateDao: SyncStateDao(db),
      providerGetter: () => DemoDataProvider(),
    );
    const settings = AppSettings();
    final engine = SignalEngine(
      getSeries: (pair, tf, {limit = 300}) => repository.getSeries(pair, tf, limit: limit),
      syncPairTimeframe: (pair, tf, {outputSize = 300}) => repository.syncPairTimeframe(pair, tf, outputSize: outputSize),
      candleDao: candleDao,
      signalDao: signalDao,
      backtestDao: BacktestDao(db),
      strategySettingsDao: StrategySettingsDao(db),
      getSettings: () => settings,
    );

    await engine.runCycle(CurrencyPair.usdJpy, Timeframe.h1);
    await engine.runCycle(CurrencyPair.eurUsd, Timeframe.h1);

    final jpySignals = await signalDao.query(pair: 'USDJPY');
    final eurSignals = await signalDao.query(pair: 'EURUSD');
    expect(jpySignals.every((s) => s.pairCode == 'USDJPY'), isTrue);
    expect(eurSignals.every((s) => s.pairCode == 'EURUSD'), isTrue);
  });
}
