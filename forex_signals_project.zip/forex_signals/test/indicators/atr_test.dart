import 'package:flutter_test/flutter_test.dart';
import 'package:forex_signals/indicators/atr.dart';
import 'package:forex_signals/models/candle.dart';

void main() {
  test('ATR converges to the constant true range of a uniform series', () {
    // Every candle has the same 1.0-wide high/low range with no gaps, so
    // the true range is 1.0 on every bar and ATR should converge to 1.0.
    final start = DateTime.utc(2024, 1, 1);
    final candles = List.generate(40, (i) {
      const base = 100.0;
      return Candle(
        timestamp: start.add(Duration(hours: i)),
        open: base,
        high: base + 0.5,
        low: base - 0.5,
        close: base,
      );
    });
    final atr = Atr.compute(CandleSeries(candles), period: 14);
    expect(atr[39], isNotNull);
    expect(atr[39]!, closeTo(1.0, 1e-6));
  });

  test('is null for every index before the series has 2 candles', () {
    final atr = Atr.compute(CandleSeries(const []), period: 14);
    expect(atr, isEmpty);
  });
}
