import 'package:flutter_test/flutter_test.dart';
import 'package:forex_signals/indicators/rsi.dart';
import 'package:forex_signals/models/candle.dart';

CandleSeries _seriesFromCloses(List<double> closes) {
  final start = DateTime.utc(2024, 1, 1);
  return CandleSeries([
    for (int i = 0; i < closes.length; i++)
      Candle(
        timestamp: start.add(Duration(days: i)),
        open: closes[i],
        high: closes[i] + 0.1,
        low: closes[i] - 0.1,
        close: closes[i],
      ),
  ]);
}

void main() {
  group('Rsi.compute', () {
    // This is the widely-published 14-period RSI worked example (the same
    // series used in most textbook explanations of Wilder's RSI), used here
    // to pin the implementation to the textbook formula rather than a
    // plausible-looking approximation.
    const closes = [
      44.3389, 44.0902, 44.1497, 43.6124, 44.3278, 44.8264, 45.0955, 45.4245,
      45.8433, 46.0826, 45.8931, 46.0328, 45.6140, 46.2820, 46.2820, 46.0028,
      46.0328, 46.4116, 46.2222, 45.6439, 46.2122, 46.2521, 45.7137, 46.4515,
      45.7835, 45.3548, 44.0288, 44.1783, 44.2181, 44.5672, 43.4205, 42.6628,
      43.1314,
    ];

    test('first value at index 14 matches the textbook result (~70.53)', () {
      final rsi = Rsi.compute(_seriesFromCloses(closes), period: 14);
      expect(rsi[14], isNotNull);
      expect(rsi[14]!, closeTo(70.53, 0.05));
    });

    test('later Wilder-smoothed value matches (~37.77 at index 31)', () {
      final rsi = Rsi.compute(_seriesFromCloses(closes), period: 14);
      expect(rsi[31]!, closeTo(37.77, 0.05));
    });

    test('is null before the warm-up period', () {
      final rsi = Rsi.compute(_seriesFromCloses(closes), period: 14);
      for (int i = 0; i < 14; i++) {
        expect(rsi[i], isNull, reason: 'index $i should be before warm-up');
      }
    });

    test('returns 100 for a strictly rising series with no losses', () {
      final rising = List.generate(30, (i) => 1.0 + i * 0.01);
      final rsi = Rsi.compute(_seriesFromCloses(rising), period: 14);
      expect(rsi[29], 100.0);
    });

    test('all-null when there are fewer candles than the period', () {
      final rsi = Rsi.compute(_seriesFromCloses(closes.sublist(0, 10)), period: 14);
      expect(rsi.every((v) => v == null), isTrue);
    });
  });
}
