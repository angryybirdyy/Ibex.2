import 'package:flutter_test/flutter_test.dart';
import 'package:forex_signals/data/twelve_data_provider.dart';

void main() {
  group('TwelveDataProvider.parseCandlesFromJson', () {
    test('parses values, converts to UTC, and sorts oldest-first', () {
      // Twelve Data returns newest-first, as reflected in this fixture's
      // input order (deliberately reversed from what the output should be).
      final raw = [
        {'datetime': '2026-09-28 15:30:00', 'open': '148.400', 'high': '148.450', 'low': '148.380', 'close': '148.420', 'volume': '120'},
        {'datetime': '2026-09-28 15:15:00', 'open': '148.300', 'high': '148.350', 'low': '148.280', 'close': '148.320', 'volume': '98'},
      ];

      final candles = TwelveDataProvider.parseCandlesFromJson(raw);

      expect(candles.length, 2);
      expect(candles.first.timestamp, DateTime.utc(2026, 9, 28, 15, 15));
      expect(candles.last.timestamp, DateTime.utc(2026, 9, 28, 15, 30));
      expect(candles.first.close, 148.320);
      expect(candles.first.volume, 98);
      expect(candles.every((c) => !c.isDemo), isTrue);
    });

    test('defaults volume to 0 when the field is missing', () {
      final raw = [
        {'datetime': '2026-09-28 15:15:00', 'open': '1.0800', 'high': '1.0810', 'low': '1.0790', 'close': '1.0805'},
      ];
      final candles = TwelveDataProvider.parseCandlesFromJson(raw);
      expect(candles.single.volume, 0);
    });

    test('throws on a malformed numeric field rather than silently producing NaN', () {
      final raw = [
        {'datetime': '2026-09-28 15:15:00', 'open': 'not-a-number', 'high': '1.08', 'low': '1.07', 'close': '1.075'},
      ];
      expect(() => TwelveDataProvider.parseCandlesFromJson(raw), throwsFormatException);
    });
  });
}
