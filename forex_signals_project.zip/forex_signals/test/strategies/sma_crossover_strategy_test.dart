import 'package:flutter_test/flutter_test.dart';
import 'package:forex_signals/core/enums.dart';
import 'package:forex_signals/models/candle.dart';
import 'package:forex_signals/strategies/sma_crossover_strategy.dart';

CandleSeries _seriesFromCloses(List<double> closes) {
  final start = DateTime.utc(2024, 1, 1);
  return CandleSeries([
    for (int i = 0; i < closes.length; i++)
      Candle(timestamp: start.add(Duration(hours: i)), open: closes[i], high: closes[i] + 0.01, low: closes[i] - 0.01, close: closes[i]),
  ]);
}

void main() {
  final strategy = SmaCrossoverStrategy();

  test('fires BUY exactly on the candle where fast SMA crosses above slow SMA', () {
    // A flat run (keeps both SMAs equal and low) followed by a sharp,
    // sustained rise. With fast=5/slow=20, the fast average overtakes the
    // slow one partway through the rise — we only assert that a BUY occurs
    // somewhere in the rise and never before it, not the exact bar, so the
    // test isn't coupled to SMA arithmetic down to the candle.
    final flat = List.generate(40, (_) => 100.0);
    final rising = List.generate(40, (i) => 100.0 + i * 0.5);
    final closes = [...flat, ...rising];
    final series = _seriesFromCloses(closes);

    bool buyBeforeRiseStarted = false;
    int? firstBuyIndex;
    for (int i = strategy.minCandles; i < series.length; i++) {
      final window = CandleSeries(series.candles.sublist(0, i + 1));
      final result = strategy.evaluateSafe(window, overrides: {'fast': 5, 'slow': 20});
      if (result.direction == StrategyDirection.buy) {
        firstBuyIndex ??= i;
        if (i < flat.length) buyBeforeRiseStarted = true;
      }
    }

    expect(buyBeforeRiseStarted, isFalse, reason: 'a flat series must not produce a BUY crossover');
    expect(firstBuyIndex, isNotNull, reason: 'a sustained rise must eventually produce a BUY crossover');
    expect(firstBuyIndex!, greaterThanOrEqualTo(flat.length));
  });

  test('stays neutral on a perfectly flat series (no crossover possible)', () {
    final series = _seriesFromCloses(List.generate(60, (_) => 150.0));
    final result = strategy.evaluateSafe(series, overrides: {'fast': 5, 'slow': 20});
    expect(result.direction, StrategyDirection.neutral);
  });
}
