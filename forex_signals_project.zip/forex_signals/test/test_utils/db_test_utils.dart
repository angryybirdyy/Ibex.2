import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'package:forex_signals/database/app_database.dart';

/// Every database-touching test calls this once (typically in `setUpAll`)
/// before the first [AppDatabase.open] — it points `sqflite` at the FFI
/// implementation backed by a real SQLite engine on the test host (desktop
/// Linux/macOS/Windows, including CI runners), so the exact same DAO code
/// that runs on an Android device is exercised here with no emulator.
void initTestDatabaseFactory() {
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;
}

/// Opens a fresh in-memory database for one test.
///
/// [AppDatabase] caches a single opened instance (by design — the real app
/// only ever wants one). That means a *second* call to [AppDatabase.open]
/// anywhere in the same test process would silently hand back whichever
/// instance opened first, overridePath included — not a fresh database.
/// This helper closes any existing instance first, so every call to it
/// really does start clean. Tests still call this themselves in `setUp`
/// (not just once in `setUpAll`) precisely so each test case gets isolated,
/// empty tables.
Future<AppDatabase> openInMemoryTestDatabase() async {
  await AppDatabase.closeForTests();
  return AppDatabase.open(overridePath: inMemoryDatabasePath);
}
