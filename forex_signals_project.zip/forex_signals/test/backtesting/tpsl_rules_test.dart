import 'package:flutter_test/flutter_test.dart';
import 'package:forex_signals/backtesting/tpsl_rules.dart';
import 'package:forex_signals/core/enums.dart';
import 'package:forex_signals/core/market_types.dart';
import 'package:forex_signals/models/candle.dart';

Candle _c(DateTime t, double o, double h, double l, double c) =>
    Candle(timestamp: t, open: o, high: h, low: l, close: c);

void main() {
  final t0 = DateTime.utc(2024, 1, 1);

  group('computeTpSl', () {
    test('ATR method places TP/SL symmetrically at entry ± atr*multiple for a BUY', () {
      final levels = computeTpSl(
        direction: SignalDirection.buy,
        entryPrice: 150.0,
        pair: CurrencyPair.usdJpy,
        method: TpSlMethod.atrMultiple,
        atrValue: 0.20,
        atrMultiple: 1.5,
        fixedPips: 30,
      );
      expect(levels.target, closeTo(150.30, 1e-9)); // 150 + 0.20*1.5
      expect(levels.stopLoss, closeTo(149.70, 1e-9));
    });

    test('falls back to fixed pips when ATR is unavailable', () {
      final levels = computeTpSl(
        direction: SignalDirection.sell,
        entryPrice: 1.1000,
        pair: CurrencyPair.eurUsd,
        method: TpSlMethod.atrMultiple,
        atrValue: null,
        atrMultiple: 1.5,
        fixedPips: 30, // 30 * 0.0001 = 0.0030
      );
      expect(levels.target, closeTo(1.0970, 1e-9));
      expect(levels.stopLoss, closeTo(1.1030, 1e-9));
    });

    test('fixedPips method uses the pair pip size directly', () {
      final levels = computeTpSl(
        direction: SignalDirection.buy,
        entryPrice: 150.000,
        pair: CurrencyPair.usdJpy, // pip size 0.01
        method: TpSlMethod.fixedPips,
        atrValue: 999, // must be ignored for this method
        atrMultiple: 1.5,
        fixedPips: 20,
      );
      expect(levels.target, closeTo(150.200, 1e-9)); // 20 * 0.01
      expect(levels.stopLoss, closeTo(149.800, 1e-9));
    });
  });

  group('evaluateSignalOutcome', () {
    test('a BUY wins when a later candle\'s high reaches target before any SL touch', () {
      final future = [
        _c(t0, 150.1, 150.2, 150.0, 150.1),
        _c(t0, 150.1, 150.4, 150.05, 150.3), // high touches target 150.3
      ];
      final outcome = evaluateSignalOutcome(
          direction: SignalDirection.buy, target: 150.3, stopLoss: 149.7, futureCandles: future);
      expect(outcome.result, SignalResultType.win);
      expect(outcome.exitPrice, 150.3);
    });

    test('a BUY loses when a candle\'s low reaches stop-loss first', () {
      final future = [
        _c(t0, 150.1, 150.15, 149.6, 149.65), // low touches SL 149.7 first
      ];
      final outcome = evaluateSignalOutcome(
          direction: SignalDirection.buy, target: 150.3, stopLoss: 149.7, futureCandles: future);
      expect(outcome.result, SignalResultType.loss);
      expect(outcome.exitPrice, 149.7);
    });

    test('unresolved when neither level is touched within the given candles', () {
      final future = [_c(t0, 150.0, 150.05, 149.95, 150.0)];
      final outcome = evaluateSignalOutcome(
          direction: SignalDirection.buy, target: 150.3, stopLoss: 149.7, futureCandles: future);
      expect(outcome.result, SignalResultType.unresolved);
    });

    test('ambiguous same-candle case resolves to whichever level is closer to the open (documented rule)', () {
      // Open is much closer to the target than to the stop-loss.
      final future = [_c(t0, 150.25, 150.35, 149.60, 150.00)];
      final outcome = evaluateSignalOutcome(
          direction: SignalDirection.buy, target: 150.3, stopLoss: 149.7, futureCandles: future);
      expect(outcome.result, SignalResultType.win);
    });

    test('SELL direction mirrors BUY logic', () {
      final future = [_c(t0, 150.0, 150.05, 149.70, 149.75)]; // low touches sell target
      final outcome = evaluateSignalOutcome(
          direction: SignalDirection.sell, target: 149.7, stopLoss: 150.3, futureCandles: future);
      expect(outcome.result, SignalResultType.win);
    });
  });
}
