import 'package:flutter_test/flutter_test.dart';
import 'package:forex_signals/database/candle_dao.dart';
import 'package:forex_signals/models/candle.dart';

import '../test_utils/db_test_utils.dart';

void main() {
  setUpAll(initTestDatabaseFactory);

  late CandleDao dao;

  setUp(() async {
    final db = await openInMemoryTestDatabase();
    dao = CandleDao(db);
  });

  final t0 = DateTime.utc(2024, 1, 1, 0, 0);

  test('upsertCandles then getCandles round-trips in chronological order', () async {
    final candles = [
      Candle(timestamp: t0, open: 1, high: 2, low: 0.5, close: 1.5),
      Candle(timestamp: t0.add(const Duration(hours: 1)), open: 1.5, high: 2.5, low: 1.0, close: 2.0),
    ];
    await dao.upsertCandles('EURUSD', '1H', candles);
    final series = await dao.getCandles('EURUSD', '1H');
    expect(series.length, 2);
    expect(series[0].timestamp, t0);
    expect(series[1].timestamp, t0.add(const Duration(hours: 1)));
  });

  test('re-upserting the same timestamp replaces rather than duplicates (spec: duplicate candles)', () async {
    await dao.upsertCandles('EURUSD', '1H', [Candle(timestamp: t0, open: 1, high: 1, low: 1, close: 1)]);
    await dao.upsertCandles('EURUSD', '1H', [Candle(timestamp: t0, open: 1, high: 1, low: 1, close: 1.999)]);
    final series = await dao.getCandles('EURUSD', '1H');
    expect(series.length, 1);
    expect(series[0].close, 1.999);
  });

  test('different pairs/timeframes never collide', () async {
    await dao.upsertCandles('EURUSD', '1H', [Candle(timestamp: t0, open: 1, high: 1, low: 1, close: 1)]);
    await dao.upsertCandles('USDJPY', '1H', [Candle(timestamp: t0, open: 150, high: 150, low: 150, close: 150)]);
    await dao.upsertCandles('EURUSD', '15M', [Candle(timestamp: t0, open: 2, high: 2, low: 2, close: 2)]);

    expect((await dao.getCandles('EURUSD', '1H')).length, 1);
    expect((await dao.getCandles('USDJPY', '1H')).length, 1);
    expect((await dao.getCandles('EURUSD', '15M')).length, 1);
    expect((await dao.getCandles('EURUSD', '1H'))[0].close, 1);
  });

  test('findGaps detects a missing candle in the middle of a series', () async {
    await dao.upsertCandles('EURUSD', '1H', [
      Candle(timestamp: t0, open: 1, high: 1, low: 1, close: 1),
      // t0 + 1h is missing
      Candle(timestamp: t0.add(const Duration(hours: 2)), open: 1, high: 1, low: 1, close: 1),
      Candle(timestamp: t0.add(const Duration(hours: 3)), open: 1, high: 1, low: 1, close: 1),
    ]);
    final gaps = await dao.findGaps('EURUSD', '1H', 60);
    expect(gaps, [t0.add(const Duration(hours: 1))]);
  });

  test('findGaps returns empty for a contiguous series', () async {
    await dao.upsertCandles('EURUSD', '1H', [
      Candle(timestamp: t0, open: 1, high: 1, low: 1, close: 1),
      Candle(timestamp: t0.add(const Duration(hours: 1)), open: 1, high: 1, low: 1, close: 1),
    ]);
    expect(await dao.findGaps('EURUSD', '1H', 60), isEmpty);
  });

  test('getLatestCandle returns the most recent candle only', () async {
    await dao.upsertCandles('EURUSD', '1H', [
      Candle(timestamp: t0, open: 1, high: 1, low: 1, close: 1),
      Candle(timestamp: t0.add(const Duration(hours: 5)), open: 9, high: 9, low: 9, close: 9),
    ]);
    final latest = await dao.getLatestCandle('EURUSD', '1H');
    expect(latest!.close, 9);
  });
}
