import 'package:flutter_test/flutter_test.dart';
import 'package:forex_signals/core/enums.dart';
import 'package:forex_signals/database/signal_dao.dart';
import 'package:forex_signals/models/signal.dart';

import '../test_utils/db_test_utils.dart';

Signal _signal(String id, {SignalStatus status = SignalStatus.active}) {
  final now = DateTime.utc(2024, 1, 1, 12);
  return Signal(
    id: id,
    pairCode: 'EURUSD',
    timeframeLabel: '15M',
    strategyId: 'rsi_overbought_oversold',
    direction: SignalDirection.buy,
    candleTimestamp: now,
    entryPrice: 1.1000,
    createdAt: now,
    status: status,
  );
}

void main() {
  setUpAll(initTestDatabaseFactory);

  late SignalDao dao;

  setUp(() async {
    final db = await openInMemoryTestDatabase();
    dao = SignalDao(db);
  });

  test('insertIfNew returns true for a brand new id', () async {
    expect(await dao.insertIfNew(_signal('sig-1')), isTrue);
  });

  test('insertIfNew returns false and inserts nothing on a duplicate id (spec: dedup)', () async {
    expect(await dao.insertIfNew(_signal('sig-1')), isTrue);
    expect(await dao.insertIfNew(_signal('sig-1')), isFalse);
    expect(await dao.countAll(), 1);
  });

  test('query filters by status correctly (active vs resolved)', () async {
    await dao.insertIfNew(_signal('active-1', status: SignalStatus.active));
    await dao.insertIfNew(_signal('resolved-1', status: SignalStatus.resolved));

    final active = await dao.query(status: SignalStatus.active);
    final resolved = await dao.query(status: SignalStatus.resolved);
    expect(active.map((s) => s.id), ['active-1']);
    expect(resolved.map((s) => s.id), ['resolved-1']);
  });

  test('update persists a resolution change', () async {
    await dao.insertIfNew(_signal('sig-2'));
    final fetched = await dao.getById('sig-2');
    final resolved = fetched!.copyWith(
      status: SignalStatus.resolved,
      resultType: SignalResultType.win,
      resultTimestamp: DateTime.utc(2024, 1, 2),
      resultPrice: 1.1050,
    );
    await dao.update(resolved);

    final reloaded = await dao.getById('sig-2');
    expect(reloaded!.status, SignalStatus.resolved);
    expect(reloaded.resultType, SignalResultType.win);
    expect(reloaded.resultPrice, 1.1050);
  });
}
