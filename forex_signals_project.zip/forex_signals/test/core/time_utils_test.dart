import 'package:flutter_test/flutter_test.dart';
import 'package:forex_signals/core/time_utils.dart';

void main() {
  group('toStorageString / fromStorageString', () {
    test('round-trips a UTC instant exactly', () {
      final dt = DateTime.utc(2026, 9, 28, 15, 15, 30);
      final roundTripped = fromStorageString(toStorageString(dt));
      expect(roundTripped, dt);
    });

    test('rejects a non-UTC DateTime to catch local-time leaks at the source', () {
      final local = DateTime(2026, 9, 28, 15, 15); // local, not UTC
      expect(() => toStorageString(local), throwsArgumentError);
    });
  });

  group('floorToCandle (timeframe conversion / bucketing)', () {
    test('floors to the correct 15-minute bucket start', () {
      final t = DateTime.utc(2026, 9, 28, 15, 22, 45);
      expect(floorToCandle(t, 15), DateTime.utc(2026, 9, 28, 15, 15));
    });

    test('floors to the correct 1-hour bucket start', () {
      final t = DateTime.utc(2026, 9, 28, 15, 59);
      expect(floorToCandle(t, 60), DateTime.utc(2026, 9, 28, 15, 0));
    });

    test('floors to the correct 4-hour bucket start', () {
      final t = DateTime.utc(2026, 9, 28, 13, 10);
      expect(floorToCandle(t, 240), DateTime.utc(2026, 9, 28, 12, 0));
    });

    test('an exact bucket boundary floors to itself', () {
      final t = DateTime.utc(2026, 9, 28, 16, 0);
      expect(floorToCandle(t, 15), t);
    });
  });

  group('formatDuration', () {
    test('formats minutes-only durations', () {
      expect(formatDuration(const Duration(minutes: 42)), '42m');
    });

    test('formats hours and minutes', () {
      expect(formatDuration(const Duration(hours: 2, minutes: 14)), '2h 14m');
    });

    test('formats days and hours', () {
      expect(formatDuration(const Duration(days: 1, hours: 5)), '1d 5h');
    });
  });
}
