import 'package:flutter_test/flutter_test.dart';
import 'package:forex_signals/core/enums.dart';
import 'package:forex_signals/models/backtest_result.dart';

BacktestTrade _trade(SignalResultType result, {double? exit, double entry = 100}) => BacktestTrade(
      direction: SignalDirection.buy,
      entryTime: DateTime.utc(2024, 1, 1),
      entryPrice: entry,
      targetPrice: entry + 1,
      stopLossPrice: entry - 1,
      result: result,
      exitTime: exit == null ? null : DateTime.utc(2024, 1, 2),
      exitPrice: exit,
    );

void main() {
  test('win rate is computed only from decided (win+loss) trades, excluding unresolved', () {
    final result = BacktestResult(
      strategyId: 's',
      pairCode: 'EURUSD',
      timeframeLabel: '1H',
      startDate: DateTime.utc(2024, 1, 1),
      endDate: DateTime.utc(2024, 2, 1),
      trades: [
        _trade(SignalResultType.win, exit: 101),
        _trade(SignalResultType.win, exit: 101),
        _trade(SignalResultType.win, exit: 101),
        _trade(SignalResultType.loss, exit: 99),
        _trade(SignalResultType.unresolved), // must not count toward the percentage
      ],
      computedAt: DateTime.utc(2024, 2, 1),
    );

    expect(result.totalTrades, 5);
    expect(result.winningTrades, 3);
    expect(result.losingTrades, 1);
    expect(result.unresolvedTrades, 1);
    expect(result.winRate, closeTo(75.0, 1e-9)); // 3 / (3+1)
  });

  test('winRate is null (not zero) when there are no decided trades', () {
    final result = BacktestResult(
      strategyId: 's',
      pairCode: 'EURUSD',
      timeframeLabel: '1H',
      startDate: DateTime.utc(2024, 1, 1),
      endDate: DateTime.utc(2024, 2, 1),
      trades: [_trade(SignalResultType.unresolved)],
      computedAt: DateTime.utc(2024, 2, 1),
    );
    expect(result.winRate, isNull);
  });

  test('profit factor is gross profit over gross loss', () {
    final result = BacktestResult(
      strategyId: 's',
      pairCode: 'EURUSD',
      timeframeLabel: '1H',
      startDate: DateTime.utc(2024, 1, 1),
      endDate: DateTime.utc(2024, 2, 1),
      trades: [
        _trade(SignalResultType.win, entry: 100, exit: 102), // +2
        _trade(SignalResultType.win, entry: 100, exit: 104), // +4
        _trade(SignalResultType.loss, entry: 100, exit: 97), // -3 (abs 3)
      ],
      computedAt: DateTime.utc(2024, 2, 1),
    );
    // gross profit = 6, gross loss = 3 -> profit factor 2.0
    expect(result.profitFactor, closeTo(2.0, 1e-9));
  });

  test('profitFactor is null when there are no losing trades to divide by', () {
    final result = BacktestResult(
      strategyId: 's',
      pairCode: 'EURUSD',
      timeframeLabel: '1H',
      startDate: DateTime.utc(2024, 1, 1),
      endDate: DateTime.utc(2024, 2, 1),
      trades: [_trade(SignalResultType.win, entry: 100, exit: 101)],
      computedAt: DateTime.utc(2024, 2, 1),
    );
    expect(result.profitFactor, isNull);
  });

  test('maxDrawdown tracks the largest peak-to-trough dip in the trade sequence', () {
    final result = BacktestResult(
      strategyId: 's',
      pairCode: 'EURUSD',
      timeframeLabel: '1H',
      startDate: DateTime.utc(2024, 1, 1),
      endDate: DateTime.utc(2024, 2, 1),
      trades: [
        _trade(SignalResultType.win, entry: 100, exit: 105), // equity +5 (peak 5)
        _trade(SignalResultType.loss, entry: 100, exit: 97), // -3   (equity 2, dd=3)
        _trade(SignalResultType.loss, entry: 100, exit: 96), // -4   (equity -2, dd=7)
        _trade(SignalResultType.win, entry: 100, exit: 103), // +3   (equity 1)
      ],
      computedAt: DateTime.utc(2024, 2, 1),
    );
    expect(result.maxDrawdown, closeTo(7.0, 1e-9));
  });
}
