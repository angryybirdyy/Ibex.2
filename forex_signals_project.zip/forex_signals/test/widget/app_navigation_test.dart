// UI tests (spec section 34) for bottom navigation, the Strategies screen's
// toggles and info button, and the Signals screen's Current/History tabs
// and detail view.
//
// These mount the real `RootShell` and real screens, but with a small
// test-only composition root instead of production `main()`/`app.dart` —
// standard Flutter testing practice — so no real network, secure storage,
// or background-service platform channel is ever touched:
//  - `ConnectivityService.debugIsOnlineOverride` stands in for the
//    `connectivity_plus` platform channel (see that class's doc comment).
//  - The Settings screen (the one screen that touches
//    `flutter_secure_storage`/`package_info_plus`) is deliberately not
//    navigated into here.
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';

import 'package:forex_signals/core/enums.dart';
import 'package:forex_signals/database/app_database.dart';
import 'package:forex_signals/database/backtest_dao.dart';
import 'package:forex_signals/database/candle_dao.dart';
import 'package:forex_signals/database/signal_dao.dart';
import 'package:forex_signals/database/strategy_settings_dao.dart';
import 'package:forex_signals/database/sync_state_dao.dart';
import 'package:forex_signals/data/market_data_repository.dart';
import 'package:forex_signals/data/demo_data_provider.dart';
import 'package:forex_signals/models/app_settings.dart';
import 'package:forex_signals/models/signal.dart';
import 'package:forex_signals/screens/root_shell.dart';
import 'package:forex_signals/services/connectivity_service.dart';
import 'package:forex_signals/services/service_status_controller.dart';
import 'package:forex_signals/signals/signal_engine.dart';
import 'package:forex_signals/state/app_services.dart';
import 'package:forex_signals/state/settings_provider.dart';
import 'package:forex_signals/state/signals_provider.dart';
import 'package:forex_signals/state/strategy_settings_provider.dart';

import '../test_utils/db_test_utils.dart';

Future<AppServices> _buildTestAppServices() async {
  final db = await openInMemoryTestDatabase();
  final candleDao = CandleDao(db);
  final signalDao = SignalDao(db);
  final backtestDao = BacktestDao(db);
  final strategySettingsDao = StrategySettingsDao(db);
  final syncStateDao = SyncStateDao(db);
  final repository = MarketDataRepository(
    candleDao: candleDao,
    syncStateDao: syncStateDao,
    providerGetter: () => DemoDataProvider(),
  );
  const settings = AppSettings();
  final engine = SignalEngine(
    getSeries: (pair, tf, {limit = 300}) => repository.getSeries(pair, tf, limit: limit),
    syncPairTimeframe: (pair, tf, {outputSize = 300}) => repository.syncPairTimeframe(pair, tf, outputSize: outputSize),
    candleDao: candleDao,
    signalDao: signalDao,
    backtestDao: backtestDao,
    strategySettingsDao: strategySettingsDao,
    getSettings: () => settings,
  );

  // Seed one signal directly so the Current tab / detail view has something
  // real to display without needing a live cycle run in the test.
  await signalDao.insertIfNew(Signal(
    id: 'test-signal-1',
    pairCode: 'EURUSD',
    timeframeLabel: '15M',
    strategyId: 'rsi_overbought_oversold',
    direction: SignalDirection.buy,
    candleTimestamp: DateTime.utc(2026, 9, 28, 15, 15),
    entryPrice: 1.0850,
    createdAt: DateTime.utc(2026, 9, 28, 15, 16),
    historicalWinRate: 61.5,
    historicalSampleSize: 120,
    explanation: 'Test seeded signal.',
  ));

  return AppServices.forTesting(
    appDatabase: db,
    candleDao: candleDao,
    signalDao: signalDao,
    backtestDao: backtestDao,
    strategySettingsDao: strategySettingsDao,
    syncStateDao: syncStateDao,
    repository: repository,
    signalEngine: engine,
    initialSettings: settings,
  );
}

Widget _wrapWithProviders(AppServices appServices, Widget child) {
  return MultiProvider(
    providers: [
      Provider<AppServices>.value(value: appServices),
      ChangeNotifierProvider(create: (_) => SettingsProvider(appServices)),
      ChangeNotifierProvider(create: (_) => StrategySettingsProvider(appServices.strategySettingsDao)..load()),
      ChangeNotifierProvider(create: (_) => SignalsProvider(appServices)),
      ChangeNotifierProvider(create: (_) => ServiceStatusController()),
    ],
    child: MaterialApp(home: child),
  );
}

/// Taps a bottom-nav tab by label. `IndexedStack` keeps every tab's widgets
/// (including other tabs' own AppBar titles that happen to share text with
/// a nav label, e.g. "EUR/USD") alive simultaneously, so matching by label
/// text alone is ambiguous — this scopes the match to the nav bar itself.
Future<void> _tapTab(WidgetTester tester, String label) async {
  final finder = find.descendant(of: find.byType(BottomNavigationBar), matching: find.text(label));
  await tester.tap(finder);
  await tester.pumpAndSettle();
}

void main() {
  setUpAll(initTestDatabaseFactory);
  setUp(() => ConnectivityService.debugIsOnlineOverride = () => false);
  tearDown(() => ConnectivityService.debugIsOnlineOverride = null);

  testWidgets('bottom navigation switches between all four tabs', (tester) async {
    final appServices = await _buildTestAppServices();
    await tester.pumpWidget(_wrapWithProviders(appServices, const RootShell()));
    await tester.pumpAndSettle();

    expect(find.text('USD/JPY'), findsWidgets); // AppBar title + nav label
    await _tapTab(tester, 'EUR/USD');
    expect(find.text('EUR/USD'), findsWidgets);

    await _tapTab(tester, 'Signals');
    expect(find.text('CURRENT'), findsOneWidget);
    expect(find.text('HISTORY'), findsOneWidget);

    await _tapTab(tester, 'Strategies');
    expect(find.text('SMA Crossover'), findsOneWidget);
  });

  testWidgets('Strategies screen lists all 24 strategies and toggles chart visibility', (tester) async {
    // ListView only builds rows within the viewport, so the test surface is
    // made tall enough to lay out all 24 rows at once rather than scrolling
    // and accumulating counts — simpler and just as real a check.
    tester.view.physicalSize = const Size(800, 3200);
    tester.view.devicePixelRatio = 1.0;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    final appServices = await _buildTestAppServices();
    await tester.pumpWidget(_wrapWithProviders(appServices, const RootShell()));
    await tester.pumpAndSettle();
    await _tapTab(tester, 'Strategies');

    expect(find.byType(Switch), findsNWidgets(24));

    final firstSwitch = find.byType(Switch).first;
    final before = tester.widget<Switch>(firstSwitch).value;
    await tester.tap(firstSwitch);
    await tester.pumpAndSettle();
    final after = tester.widget<Switch>(find.byType(Switch).first).value;
    expect(after, isNot(before));
  });

  testWidgets('Strategy info button opens the detail page with the expected sections', (tester) async {
    final appServices = await _buildTestAppServices();
    await tester.pumpWidget(_wrapWithProviders(appServices, const RootShell()));
    await tester.pumpAndSettle();
    await _tapTab(tester, 'Strategies');

    // The AppBar also has an "About strategies" info icon — scope to the
    // first strategy row specifically so this taps *that* row's info
    // button, not the general one.
    final firstRowInfoButton =
        find.descendant(of: find.byType(ListTile).first, matching: find.byIcon(Icons.info_outline));
    await tester.tap(firstRowInfoButton);
    await tester.pumpAndSettle();

    expect(find.text('Buy conditions'), findsOneWidget);
    expect(find.text('Sell conditions'), findsOneWidget);
    expect(find.text('How the historical win rate is calculated'), findsOneWidget);
  });

  testWidgets('Signals screen Current tab shows the seeded signal and opens its detail view', (tester) async {
    final appServices = await _buildTestAppServices();
    await tester.pumpWidget(_wrapWithProviders(appServices, const RootShell()));
    await tester.pumpAndSettle();
    await _tapTab(tester, 'Signals');

    expect(find.text('BUY'), findsOneWidget);
    expect(find.textContaining('EURUSD'), findsWidgets);

    await tester.tap(find.text('BUY').first);
    await tester.pumpAndSettle();
    expect(find.text('Signal reasoning'), findsOneWidget);
  });

  testWidgets('History tab is reachable and shows an empty state before anything resolves', (tester) async {
    final appServices = await _buildTestAppServices();
    await tester.pumpWidget(_wrapWithProviders(appServices, const RootShell()));
    await tester.pumpAndSettle();
    await _tapTab(tester, 'Signals');
    await tester.tap(find.text('HISTORY'));
    await tester.pumpAndSettle();

    expect(find.text('No signal history yet.'), findsOneWidget);
  });
}
